/**
 * 
 */
package com.sailotech.mailbox.util;

import org.springframework.stereotype.Component;

/**
 * @author dhanunjaya.potteti
 *
 */
@Component
public class MailConstants {
	public static String folder = "INBOX";
	public static final String FILE_TYPE_ZIP = "zip";
	public static final String FILE_TYPE_RAR ="rar";
	public static final String Files_MIS="PDF,PNG,JPEG,TIFF,JPG";
	
}
