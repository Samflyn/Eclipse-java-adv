{
  "groups" : [{
    "id" : 1,
    "text": "status1"
  },
  {
    "id" : 2,
    "text": "customer"
  },
  {
    "id" : 3,
    "text": "vip"
  },
  {
    "id" : 4,
    "text": "admin"
  }]
}
//API List
http://192.168.0.254:9090/dis/getAllInvoices/052018 
dis/saveinvoice
/getInvoice/{headerId}
/loginUser 
http://192.168.0.192:9090/dis
/getInvoice/{headerId} 
/getAllInvoices/{tenantId}/{fp} 
/getTenant/{tenantId}





/sendToErp/1 
/sendToApprove/28