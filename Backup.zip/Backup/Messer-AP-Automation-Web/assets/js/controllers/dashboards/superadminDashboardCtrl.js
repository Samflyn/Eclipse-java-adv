app.controller('superadminCtrl', ["$scope", "$rootScope", "$http", "$cookies", function ($scope, $rootScope, $http, $cookies) {

}]);