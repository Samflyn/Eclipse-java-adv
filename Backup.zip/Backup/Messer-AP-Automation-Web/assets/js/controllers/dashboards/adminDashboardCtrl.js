app.controller('adminDashboardCtrl', ["$scope", "$rootScope", "$http", "$cookies", function ($scope, $rootScope, $http, $cookies) {

}]);