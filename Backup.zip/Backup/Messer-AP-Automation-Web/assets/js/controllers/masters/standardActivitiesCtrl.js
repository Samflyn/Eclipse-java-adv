'use strict';
/**
 * controllers for UI Bootstrap components
 */

app.controller('StandardActivitiesCtrl', ['$q', '$cookies', '$compile', '$filter', 'DTOptionsBuilder', 'MasterServices', 'DTColumnBuilder', '$scope', '$http', '$window', '$rootScope', function ($q, $cookies, $compile, $filter, DTOptionsBuilder, MasterServices, DTColumnBuilder, $scope, $http, $window, $rootScope) {
    $scope.data = {};
    var vm = this;
    vm.singleRecord = {};
    $scope.dtInstance = {};
    var serialNo = 1;
    //$scope.roleName = $cookies.get('roleName');
    $scope.form = {
        submit: function (form) {
            var firstError = null;
            if (form.$invalid) {
                var field = null;
                for (field in form) {
                    if (field[0] != '$') {
                        if (firstError === null && !form[field].$valid) {
                            firstError = form[field].$name;
                        }
                        if (form[field].$pristine) {
                            form[field].$dirty = true;
                        }
                    }
                }
                angular.element('.ng-invalid[name=' + firstError + ']').focus();
                return;
            } else {
                $("#saveMsg").html("");
                MasterServices.saveStandardActiviti($scope.data).then(function (response) {
                    $scope.clear();
                    $("#saveMsg").show().html('<div class="alert alert-success"<strong>' + response.data.message + '</strong> </div>').fadeOut(5000);
                    vm.reloadData();
                }).catch(function (response) {
                    $("#saveMsg").show().html('<div class="alert alert-danger"<strong>' + response.data.errorMessage + '</strong> </div>').fadeOut(5000);
                });
                form.$setPristine(true);
            }
        }
    };


    $scope.clear = function () {
        $scope.data = {};
    }

    vm.dtOptions = DTOptionsBuilder.fromFnPromise(function () {
        var defer = $q.defer();
        MasterServices.getAllStandardActivities().then(function (result) {
            defer.resolve(result.data);
        });
        return defer.promise;
    }).withPaginationType('full_numbers').withOption('createdRow',
        createdRow);
    function createdRow(row, data, dataIndex) {
        $compile(angular.element(row).contents())($scope);
    }

    vm.dtColumns = [
        DTColumnBuilder.newColumn('null').withTitle('S.No').renderWith(serialNoHtml),
        DTColumnBuilder.newColumn('standardActivities').withTitle('Standard Activities'),
        DTColumnBuilder.newColumn('description').withTitle('Description'),
        DTColumnBuilder.newColumn('activityType').withTitle('Activity Type'),
        DTColumnBuilder.newColumn('unit').withTitle('Unit'),
        DTColumnBuilder.newColumn('null').withTitle('Actions').notSortable().renderWith(actionsHtml)
    ];

    function serialNoHtml() {
        return serialNo++;
    }

    function actionsHtml(data, type, full, meta) {
        vm.singleRecord[full.id] = full;
        return '<span class="form-group"><button  type="button" class="fa fa-pencil-square-o btn btn-dark-green btn-xs editItem popup_link popup_link"  autocomplete="off" title="Edit" ng-click="standardActivitiesCtrl.editUser(standardActivitiesCtrl.singleRecord[' + full.id + '])"></button></span> <span class="form-group" ng-if=' + 'role=="SUPER_ADMIN"' + '><button class="fa fa-trash btn btn-danger btn-xs editItem popup_link popup_link" type="button" autocomplete="off" title="Delete" id="delete" ng-click="standardActivitiesCtrl.deleteById(standardActivitiesCtrl.singleRecord[' + full.id + '])"></button></span>';
    }
    vm.editUser = function (singleObj) {
        $scope.data = singleObj;
        //  $scope.data['pic'] = singleObj.pic;
    }

    vm.deleteById = function (singleObj) {
        swal({
            title: "",
            text: "Are you sure want to delete",
            showCancelButton: true,
            confirmButtonColor: "#8B0000",
            confirmButtonText: "Yes",
            closeOnConfirm: true
        }, function (isConfirm) {
            if (isConfirm) {
                $http({
                    method: 'DELETE',
                    url: $rootScope.ctx + '/deleteStandardActivities/' + singleObj.id
                }).then(function onSuccess(response) {
                    vm.reloadData();
                    $("#saveMsg")
                        .show()
                        .html('<div class="alert alert-success"<strong>' + 'Deleted successfully' + '</strong> </div>')
                        .fadeOut(5000);
                }, function (err) {
                    $("#saveMsg")
                        .show()
                        .html('<div class="alert alert-success"<strong>Failed</strong> </div>')
                        .fadeOut(5000);
                })
            }
        });
    }
    vm.reloadData = function () {
        serialNo = 1;
        $scope.dtInstance.reloadData(function () {
            var defer = $q.defer();
            MasterServices.getAllStandardActivities().then(
                function (result) {
                    defer.resolve(result.data);
                });
            return defer.promise;
        }, true);
    }
}]);