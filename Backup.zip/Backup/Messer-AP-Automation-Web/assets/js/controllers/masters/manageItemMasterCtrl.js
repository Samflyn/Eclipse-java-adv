'use strict';
/**
 * controllers for UI Bootstrap components
 */


app.controller('manageItemMasterCtrl', ['MasterServices', '$cookies', '$localStorage', '$q', '$compile', 'DTOptionsBuilder', 'DTColumnBuilder', '$scope', '$http', '$window', '$rootScope', '$parse', function (MasterServices, $cookies, $localStorage, $q, $compile, DTOptionsBuilder, DTColumnBuilder, $scope, $http, $window, $rootScope) {

	$scope.data = {};
	$scope.data.exceldata = [];
	$scope.itemList = [];
	var vm = this;
	vm.singleRecord = {};
	$scope.dtInstance = {};
	$scope.companyId = $rootScope.user.companyDto.companyId;
	$scope.excel;
	var serialNo = 1;

	vm.singleRecord = {};
	$scope.params = {};
	//  vm.reloadData = reloadData;




	vm.dtOptions = DTOptionsBuilder
		.newOptions()
		.withDataProp('data')
		.withOption('processing', true)
		.withOption('serverSide', true)
		.withOption('ajax', {
			url: $rootScope.ctx + '/getItems?companyId=' + $scope.companyId,
			headers: { 'loginDetails': JSON.stringify($scope.loginDetails) },
			type: 'GET',
			beforeSend: function (xhr) {
				xhr.setRequestHeader('Authorization', 'Bearer ' + $localStorage.token);
			},
			dataSrc: 'data',
			data: function (d) {
				$scope.params.start = 0;
				$scope.params.length = 10;
				$scope.params.value = d.search.value ? d.search.value : '';
				d.search = $scope.params;
				tableIndex = d.start
				return d;
			},
			reload: function () {
				tableIndex = 0;
				this.reload = true;
				return this;
			},
			complete: function (res) {
				tableIndex = 0;
				$scope.tableData = res.responseJSON.data;
			}
		})
		.withDisplayLength($scope.limit)
		.withPaginationType('full_numbers')
		.withOption('createdRow', createdRow)
		.withOption('lengthMenu', [[5, 10, 25, 50, 100], [5, 10, 25, 50, 100]])


	vm.displayTable = true;
	vm.dtColumns =
		[
			DTColumnBuilder.newColumn('null').withTitle('SNO').renderWith(indexVal),
			DTColumnBuilder.newColumn('itemCode').withTitle('Item Code'),
			DTColumnBuilder.newColumn('itemDesc').withTitle('Item Desc'),
			DTColumnBuilder.newColumn('null').withTitle('Actions').notSortable()
				.renderWith(actionsHtml)
		];

	var tableIndex = "0";

	function indexVal() {
		return ++tableIndex;
	}

	function createdRow(row, data, dataIndex) {
		$compile(angular.element(row).contents())($scope);
	}

	function actionsHtml(data, type, full, meta) {
		vm.singleRecord[full.itemId] = full;
		return '<span class="form-group"><button  type="button"  class="fa fa-pencil-square-o btn btn-dark-green btn-xs editItem popup_link popup_link"  autocomplete="off" title="Edit" ng-click="ItemMasterCtrl.edit(ItemMasterCtrl.singleRecord[' + full.itemId + '])"></button></span>  <span class="form-group" ng-if=' + 'role=="SUPER_ADMIN"' + '><button type="button"  class="fa fa-trash btn btn-danger btn-xs editItem popup_link popup_link" autocomplete="off" title="Delete" id="delete" ng-click="ItemMasterCtrl.deleteItem(ItemMasterCtrl.singleRecord[' + full.itemId + '])"></button></span>';
	}
	vm.edit = function (singleObj) {
		vm.seletedRawRecord = singleObj;
		$scope.data = singleObj;
	}

	//to delete data
	vm.deleteItem = function (singleObj) {
		var id = singleObj.itemId;
		swal({
			title: "Deleting Record",
			text: "Are you sure you want to delete this Item",
			type: "warning",
			showCancelButton: true,
			confirmButtonColor: "#007AFF",
			confirmButtonText: "Yes",
			closeOnConfirm: true
		}, function (isConfirm) {
			if (isConfirm) {
				$http({
					url: $rootScope.ctx + '/deleteItem/' + singleObj.itemId,
					method: "DELETE",
					// params:{"itemId":id},
					headers: { 'Content-Type': 'application/json' }

				}).then(function onSuccess(response) {
					// setResponse("onSuccess",response);
					$scope.msg = response.data;
					$("#saveMsg")
						.show()
						.html('<div class="alert alert-success"<strong>' + response.data + '</strong> </div>')
						.fadeOut(5000);
					$scope.isDirty = false;
					$scope.clear();
					vm.reloadData();

				}).catch(function onError(response) {
					$scope.clear();
					vm.reloadData();
					console.log("onError", response);
					$("#saveMsg")
						.show()
						.html('<div class="alert alert-danger"<strong>delete failed</strong> </div>')
						.fadeOut(5000);

				});

			}
		});
	}

	$scope.uploadItems = function () {
		$scope.data.itemMasterDTOs1 = [];
		$scope.data.exceldata = $scope.data1;
		if ($scope.data.exceldata.length == 0) {
			$("#saveMsg").show().html('<div class="alert alert-danger"<strong>' + "File is empty" + '</strong> </div>').fadeOut(5000);
		}
		else {
			angular.forEach($scope.data.exceldata, function (value, key) {
				$scope.dtos = {};
				$scope.dtos = $scope.itemList.filter(function (item) {
					return item.itemName == value.itemName;
				});
				if ($scope.dtos.length > 0) {
					$scope.dtos[0].itemDesc = value.itemDesc;
					$scope.dtos[0].itemType = value.itemType;
					$scope.dtos[0].hsnCode = value.hsnCode;
					$scope.dtos[0].rate = value.rate;
					$scope.data.itemMasterDTOs1.push($scope.dtos[0]);

				}
				else {
					$scope.data.itemMasterDTOs1.push(value);
				}

			});

			MasterServices.excelItemMaster($scope.data.itemMasterDTOs1).then(function (response) {
				vm.reloadData();
				$scope.clear();
				$("#saveMsg").show().html('<div class="alert alert-success"<strong>' + response.data.message + '</strong> </div>').fadeOut(5000);
			}).catch(function (response) {
				$("#saveMsg").show().html('<div class="alert alert-danger"<strong>' + response.data.errorMessage + '</strong> </div>').fadeOut(5000);
			});
		}


	}


	$rootScope.$on('FILE_UPLOADED', function (event, originalEvent) {
		alasql('SELECT [Item Name] AS [itemName],[Item Description ] AS [itemDesc],[Item Type] AS [itemType],[HSN/SAC] AS [hsnCode] ,[Tax Rate] AS [rate] FROM FILE(?,{headers:true,sheetid:"Item"})', [originalEvent], function (data) {
			console.log("Data from file=", data);
			$scope.data1 = data;
		});
	});


	$scope.form = {
		submit: function (form) {
			var firstError = null;
			if (form.$invalid) {
				var field = null;
				for (field in form) {
					if (field[0] != '$') {
						if (firstError === null && !form[field].$valid) {
							firstError = form[field].$name;
						}

						if (form[field].$pristine) {
							form[field].$dirty = true;
						}
					}
				}
				angular.element('.ng-invalid[name=' + firstError + ']').focus();
				console.log("The form cannot be submitted because it contains validation errors!", "Errors are marked with a red, dashed border!");
				return;
			} else {
				MasterServices.saveItemMaster($scope.data).then(function (response) {
					$("#saveMsg").show().html('<div class="alert alert-success"<strong>' + response.data.message + '</strong> </div>').fadeOut(5000);
					vm.reloadData();
					$scope.clear();
				}).catch(function (response) {
					console.log(response.data.errorMessage)
					$("#saveMsg").show().html('<div class="alert alert-danger"<strong>' + response.data.errorMessage + '</strong> </div>');
				});
				form.$setPristine(true);
			}

		}
	};

	vm.reloadData = function () {
		serialNo = 1;
		$scope.dtInstance.reloadData();
	}

	$scope.clear = function () {
		$scope.data = {};
	}

}]);

app.directive('nngFileUpload', ['$rootScope', function ($rootScope) {
	return {
		restrict: 'A',
		scope: {},
		link: function (scope, elm, attrs) {
			//elm should be input field else find input field(elm.find("input[type='file']"))
			elm.on('change', function (event) {
				$rootScope.$emit("FILE_UPLOADED", event.originalEvent);
			});
		}
	}
}]);
