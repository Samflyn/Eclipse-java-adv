'use strict';
/**
 * controllers for UI Bootstrap components
 */

app.controller('manageItemMappingCtrl', ["DTOptionsBuilder", "DTColumnBuilder", "$localStorage", "$q", "MasterServices", "$compile", "$scope", "$rootScope", "$http", "$cookies", "$timeout", "$filter", function (DTOptionsBuilder, DTColumnBuilder, $localStorage, $q, MasterServices, $compile, $scope, $rootScope, $http, $cookies, $timeout, $filter) {

	$scope.data = {};
	$scope.data.itemMasterDto = {};
	$scope.data.itemMappingDto = {};
	$scope.data.itemMappingDto1 = [];
	var vm = this;
	vm.singleobj = {};
	$scope.dtInstance = {};
	$scope.companyId = $rootScope.user.companyDto.companyId;
	vm.singleRecord = {};
	$scope.params = {};

	vm.dtOptions = DTOptionsBuilder
		.newOptions()
		.withDataProp('data')
		.withOption('processing', true)
		.withOption('serverSide', true)
		.withOption('ajax', {
			url: $rootScope.ctx + '/getItemMapping?companyId=' + $scope.companyId,
			headers: { 'loginDetails': JSON.stringify($scope.loginDetails) },
			type: 'GET',
			beforeSend: function (xhr) {
				xhr.setRequestHeader('Authorization', 'Bearer ' + $localStorage.token);
			},
			dataSrc: 'data',
			data: function (d) {
				$scope.params.start = 0;
				$scope.params.length = 10;
				$scope.params.value = d.search.value ? d.search.value : '';
				d.search = $scope.params;
				tableIndex = d.start
				return d;
			},
			reload: function () {
				tableIndex = 0;
				this.reload = true;
				return this;
			},
			complete: function (res) {
				tableIndex = 0;
				$scope.tableData = res.responseJSON.data;
			}
		})
		.withDisplayLength($scope.limit)
		.withPaginationType('full_numbers')
		.withOption('createdRow', createdRow)
		.withOption('lengthMenu', [[5, 10, 25, 50, 100], [5, 10, 25, 50, 100]]);


	vm.displayTable = true;
	vm.dtColumns =
		[
			DTColumnBuilder.newColumn('null').withTitle('SNO').renderWith(indexVal),
			DTColumnBuilder.newColumn('itemMasterDto.itemCode').withTitle('LN Item Code'),
			DTColumnBuilder.newColumn('itemMappingCode').withTitle('Supplier Item Code'),
			DTColumnBuilder.newColumn('itemMappingDesc').withTitle('Supplier Item Description'),
			DTColumnBuilder.newColumn('null').withTitle('Actions').notSortable()
				.renderWith(actionsHtml)
		];

	var tableIndex = "0";

	function indexVal() {
		return ++tableIndex;
	}

	function createdRow(row, data, dataIndex) {
		$compile(angular.element(row).contents())($scope);
	}

	function actionsHtml(data, type, full) {
		vm.singleobj[full.itemMappingId] = full;
		return '<span class="form-group"><button  type="button" class="fa fa-pencil-square-o btn btn-dark-green btn-xs editItem popup_link popup_link"  autocomplete="off" title="Edit" ng-click="ItemMappingCtrl.edit(ItemMappingCtrl.singleobj[' + full.itemMappingId + '])"></button></span> <span class="form-group" ng-if=' + 'role=="SUPER_ADMIN"' + '><button class="fa fa-trash btn btn-danger btn-xs editItem popup_link popup_link" type="button" autocomplete="off" title="Delete" id="delete" ng-click="ItemMappingCtrl.deleteRow(ItemMappingCtrl.singleobj[' + full.itemMappingId + '])"></button></span>';
	}

	vm.edit = function (singleobj) {
		$scope.data = singleobj;
	}

	vm.deleteRow = function (singleobj) {
		swal({
			title: "Deleting Record",
			text: "Are you sure want to  delete this Item Mapping",
			type: "warning",
			showCancelButton: true,
			confirmButtonColor: "#007AFF",
			confirmButtonText: "Yes",
			closeOnConfirm: true
		}, function (isConfirm) {
			if (isConfirm) {
				$http({
					url: $rootScope.ctx + '/deleteItemMapping/' + singleobj.itemMappingId,
					method: "DELETE",
					headers: { 'Content-Type': 'application/json' }

				}).then(function onSuccess(response) {
					$("#saveMsg")
						.show()
						.html('<div class="alert alert-success"<strong>Item Mapping deleted successfully</strong> </div>')
						.fadeOut(5000);
					$scope.isDirty = false;
					vm.reloadData();
					$scope.clear();
				}).catch(function onError(response) {
					vm.reloadData();
					$scope.clear();
					$("#saveMsg").show().html('<div class="alert alert-danger"<strong>Item Mapping delete failed</strong> </div>');
				});
			}
		});
	}

	$scope.form = {
		submit: function (form) {
			var firstError = null;
			if (form.$invalid) {
				var field = null;
				for (field in form) {
					if (field[0] != '$') {
						if (firstError === null && !form[field].$valid) {
							firstError = form[field].$name;
						}
						if (form[field].$pristine) {
							form[field].$dirty = true;
						}
					}
				}
				angular.element('.ng-invalid[name=' + firstError + ']').focus();
				return;
			} else {
				MasterServices.saveItemMapping($scope.data).then(function (response) {
					vm.reloadData();
					$scope.clear();
					$("#saveMsg").show().html('<div class="alert alert-success"<strong>' + response.data.message + '</strong> </div>');
				}).catch(function (response) {
					$("#saveMsg").show().html('<div class="alert alert-danger"<strong>' + response.data.errorMessage + '</strong> </div>');
				});
				form.$setPristine(true);
			}

		}
	};
	$scope.uploadItemMapping = function () {
		$scope.isexists = {};
		$scope.errormesage = [];
		$scope.data.itemMasterDto = $rootScope.data1;
		if ($scope.data.itemMasterDto.length == 0) {
			$("#saveMsg").show().html('<div class="alert alert-danger"<strong>' + "File is empty" + '</strong> </div>').fadeOut(5000);
		}
		else {
			angular.forEach($scope.data.itemMasterDto, function (value, key) {
				$scope.itemmaster = $filter('filter')($scope.itemList, { itemName: value.itemMasterDto })[0];
				if ($scope.itemmaster) {
					$scope.data.itemMappingDto1.push({ itemMasterDto: $scope.itemmaster, itemMappingCode: value.itemMappingCode });
				}
				else {
					$scope.errormesage.push(value.itemMasterDto.toString());
				}
			});

			if ($scope.errormesage.length > 0) {
				swal({
					title: "Item Codes",
					text: $scope.errormesage.toString() + ' ' + 'does not exists in Item master ,Still you want to save remaining records',
					type: "warning",
					showCancelButton: true,
					confirmButtonColor: "#007AFF",
					confirmButtonText: "Yes",
					closeOnConfirm: true
				}, function (isConfirm) {
					if (isConfirm) {
						MasterServices.saveExcelItemMapping($scope.data.itemMappingDto1).then(function (response) {
							vm.reloadData();
							$scope.clear();
							$("#saveMsg").show().html('<div class="alert alert-success"<strong>' + response.data.message + '</strong> </div>');
						}).catch(function (response) {
							$("#saveMsg").show().html('<div class="alert alert-danger"<strong>' + response.data.errorMessage + '</strong> </div>');
						});
					}
				});
			} else {
				MasterServices.saveExcelItemMapping($scope.data.itemMappingDto1).then(function (response) {
					vm.reloadData();
					$scope.clear();
					$("#saveMsg").show().html('<div class="alert alert-success"<strong>' + response.data.message + '</strong> </div>');
				}).catch(function (response) {
					$("#saveMsg").show().html('<div class="alert alert-danger"<strong>' + response.data.errorMessage + '</strong> </div>');
				});
			}
		}

	}
	$rootScope.$on('FILE_UPLOADED', function (event, originalEvent) {
		alasql('SELECT [Item Name (Client)] AS [itemMasterDto], [Vendor Item Name] AS [itemMappingCode] FROM FILE(?,{headers:true,sheetid:"ItemMapping"})', [originalEvent], function (data) {
			console.log("Data from file=", data);
			$rootScope.data1 = data;
		});
	});

	$scope.clear = function () {
		$scope.data = {};
		$scope.companyId = $rootScope.user.companyDto.companyId;
	}
}]);
app.directive('nngFileUpload', ['$rootScope', function ($rootScope) {
	return {
		restrict: 'A',
		scope: {},
		link: function (scope, elm, attrs) {
			//elm should be input field else find input field(elm.find("input[type='file']"))
			elm.on('change', function (event) {
				$rootScope.$emit("FILE_UPLOADED", event.originalEvent);
			});
		}
	}
}]);
