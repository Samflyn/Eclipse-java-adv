'use strict';
/**
 * controllers for UI Bootstrap components
 */
app.controller('manageVendorCtrl', ['DTOptionsBuilder', 'MasterServices', 'DTColumnBuilder', '$scope', '$http', '$q', '$compile', '$rootScope',
	function (DTOptionsBuilder, MasterServices, DTColumnBuilder, $scope, $http, $q, $compile, $rootScope) {
		$scope.supplier = {};
		$scope.supplier.companyDto = {};
		$scope.supplier.roleMasterDto = {};
		$scope.supplier.countryMasterDto = {};
		$scope.supplier.companyDto.companyId = 3;
		var vm = this;
		vm.singleRecord = {};
		$scope.dtInstance = {};
		var serial = 1;

		$scope.form = {
			submit: function (form) {
				var firstError = null;
				if (form.$invalid) {
					var field = null;
					for (field in form) {
						if (field[0] !== '$') {
							if (firstError === null && !form[field].$valid) {
								firstError = form[field].$name;
							}
							if (form[field].$pristine) {
								form[field].$dirty = true;
							}
						}
					}
					angular.element('.ng-invalid[name=' + firstError + ']').focus();
					return;
				} else {
					MasterServices.saveSupplier($scope.supplier).then(function (response) {
						$scope.isDirty = false;
						$("#saveMsg").show().html('<div class="alert alert-success"<strong>' + response.data.message + '</strong> </div>').fadeOut(5000);
						$scope.clear();
						vm.reloadSupplierData();
					}).catch(function (response) {
						$("#saveMsg").show().html('<div class="alert alert-danger"<strong>' + response + '</strong> </div>').fadeOut(5000);
					});
					form.$setPristine(true);
				}
			}
		};


		$scope.clear = function () {
			$("#pic").replaceWith($("#pic").val('').clone(true));
			$scope.supplier = {};
		}

		vm.dtOptions = DTOptionsBuilder.fromFnPromise(function () {
			var defer = $q.defer();
			MasterServices.getAllSuppliers().then(function (result) {
				defer.resolve(result.data);
			});
			return defer.promise;
		}).withPaginationType('full_numbers').withOption('createdRow', createdRow);
		function createdRow(row, data, dataIndex) {
			$compile(angular.element(row).contents())($scope);
		}

		vm.dtColumns = [
			DTColumnBuilder.newColumn('null').withTitle('S.No').renderWith(serialNoHtml),
			DTColumnBuilder.newColumn('supplierCode').withTitle('Supplier Code'),
			DTColumnBuilder.newColumn('supplierName').withTitle('Supplier Name'),
			DTColumnBuilder.newColumn('supplierEmailId').withTitle('Email'),
			DTColumnBuilder.newColumn('countryMasterDto.countryName').withTitle('Country Name'),
			DTColumnBuilder.newColumn('null').withTitle('Actions').notSortable().renderWith(actionsHtml)
		];

		function serialNoHtml() {
			return serial++;
		}

		function actionsHtml(data, type, full, meta) {
			vm.singleRecord[full.supplierId] = full;
			return '<span class="form-group"><button  type="button" class="fa fa-pencil-square-o btn btn-dark-green btn-xs editItem popup_link popup_link"  autocomplete="off" title="Edit" ng-click="vendorCtrl.editServicedata(vendorCtrl.singleRecord[' + full.supplierId + '])"></button></span> <span class="form-group" ng-if=' + 'role=="SUPER_ADMIN"' + '><button class="fa fa-trash btn btn-danger btn-xs editItem popup_link popup_link" type="button" autocomplete="off" title="Delete" id="delete" ng-click="vendorCtrl.deleteSupplierbyid(vendorCtrl.singleRecord[' + full.supplierId + '])"></button></span>';
		}

		vm.editServicedata = function (singleObj) {
			$scope.supplier.supplierId = singleObj.supplierId;
			$scope.supplier.supplierName = singleObj.supplierName;
			$scope.supplier.supplierRegisteredId = singleObj.supplierRegisteredId;
			$scope.supplier.supplierAddress = singleObj.supplierAddress;
			$scope.supplier.supplierPincode = singleObj.supplierPincode;
			$scope.supplier.landline = singleObj.landline;
			$scope.supplier.fax = singleObj.fax;
			$scope.supplier.supplierStateId = singleObj.supplierStateId;
			$scope.supplier.countryMasterDto = singleObj.countryMasterDto;
			$scope.supplier.supplierPhoneNo = singleObj.supplierPhoneNo;
			$scope.supplier.supplierEmailId = singleObj.supplierEmailId;
			$scope.supplier.supplierEmailId1 = singleObj.supplierEmailId1;
			$scope.supplier.companyDto = singleObj.companyDto;
			$scope.supplier.supplierCode = singleObj.supplierCode;
			$scope.supplier.contactPerson = singleObj.contactPerson;
			$scope.supplier.supplierPhoneNo1 = singleObj.supplierPhoneNo1;
			$scope.supplier.rootDirectory = singleObj.rootDirectory;
			$scope.supplier.ibanNo = singleObj.ibanNo;
			$scope.supplier.supplierAccountNo = singleObj.supplierAccountNo;
		}

		vm.deleteSupplierbyid = function (singleObj) {
			swal({
				title: "",
				text: "Are you sure want to delete",
				showCancelButton: true,
				confirmButtonColor: "#8B0000",
				confirmButtonText: "Yes",
				closeOnConfirm: true
			}, function (isConfirm) {
				if (isConfirm) {
					$http({
						method: 'DELETE',
						url: $rootScope.ctx + '/deleteSupplier/' + singleObj.supplierId
					}).then(function onSuccess(response) {
						vm.reloadSupplierData();
						$("#saveMsg").show().html('<div class="alert alert-success"<strong>' + 'deleted successfully' + '</strong> </div>').fadeOut(3000);
					}, function (err) {
						$("#saveMsg").show().html('<div class="alert alert-success"<strong>Failed</strong> </div>').fadeOut(3000);
					})
				}
			});
		}

		vm.reloadSupplierData = function () {
			serial = 1;
			$scope.dtInstance.reloadData(function () {
				var defer = $q.defer();
				MasterServices.getAllSuppliers().then(function (result) {
					defer.resolve(result.data);
				});
				return defer.promise;
			}, true);
		};

		MasterServices.getAllStates().then(function (result) {
			$scope.state = result.data;
		});

		MasterServices.getAllCountries().then(function (result) {
			$scope.countries = result.data;
		});

		MasterServices.getAllCompanies().then(function (result) {
			$scope.company = result.data;
		});
	}]);
