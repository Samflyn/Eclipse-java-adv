
app.controller('costInvoiceQueueCtrl', ["$scope", "$rootScope", "$http", "$filter", "$cookies", "$filter", "$state", "$compile", "DTOptionsBuilder", "DTColumnBuilder", "$timeout", "$localStorage", "$window", function ($scope, $rootScope, $http, $filter, $cookies, $filter, $state, $compile, DTOptionsBuilder, DTColumnBuilder, $timeout, $localStorage, $window) {
	var vm = this;
	$scope.dtInstance = {};
	$scope.workFlowStatus;
	switch ($rootScope.user.roleMasterDto.roleId) {
		case 3:
			$scope.workFlowStatus = 1;
			break;
		case 4:
			$scope.workFlowStatus = 8;
			break;
		case 5:
			$scope.workFlowStatus = 11;
			break;
		default:

	}
	var tableIndex = "0";
	vm.singleRecord = {};
	$scope.params = {};
	vm.reloadData = reloadData;

	vm.dtOptions = DTOptionsBuilder
		.newOptions()
		.withDataProp('data')
		.withOption('processing', true)
		.withOption('serverSide', true)
		.withOption('ajax', {
			url: $rootScope.ctx + '/getAllInvoices',
			type: 'GET',
			beforeSend: function (xhr) {
				xhr.setRequestHeader('Authorization', 'Bearer ' + $localStorage.token);
			},
			dataSrc: 'data',
			data: function (d) {
				d.transactionType = 'CI';
				d.workflowStatus = $scope.workFlowStatus;
				$scope.params.start = 0;
				$scope.params.length = 10;
				$scope.params.value = d.search.value ? d.search.value : '';
				d.search = $scope.params;
				tableIndex = d.start
				return d;
			},
			reload: function () {
				tableIndex = 0;
				this.reload = true;
				return this;
			},
			complete: function (res) {
				tableIndex = 0;
				$scope.tableData = res.responseJSON.data;
			}
		})
		.withDisplayLength($scope.limit)
		.withPaginationType('full_numbers')
		.withOption('createdRow', createdRow)
		.withOption('lengthMenu', [[10, 25, 50, -1], [10, 25, 50, "All"]])

	vm.dtColumns = [
		DTColumnBuilder.newColumn(null).withTitle('S.No').notSortable().renderWith(indexVal),
		DTColumnBuilder.newColumn('supplierName').withTitle('Supplier Name'),
		DTColumnBuilder.newColumn('invoiceDate').withTitle('Invoice Date'),
		DTColumnBuilder.newColumn('invoiceNo').withTitle('Invoice Number'),
		DTColumnBuilder.newColumn('serviceDate').withTitle('Service Date'),
		DTColumnBuilder.newColumn('vehiclePlateNo').withTitle('Vehicle Plate Number'),
		DTColumnBuilder.newColumn('workFlowStatus').withTitle('Status').renderWith(status),
		DTColumnBuilder.newColumn(null).withTitle('Action').notSortable().renderWith(actionsHtml).withOption('width', '100px')
	];

	$scope.costAuthorityFilter = function (idVal) {
		var authority = $rootScope.user.authorities.filter(i => i.id == idVal)[0];
		if (authority && authority.id) {
			return true;
		}
		return false;
	}


	function indexVal() {
		return ++tableIndex;
	}

	function changeDateFormat(data, type, full, meta) {
		return full.invoiceDate = moment(full.invoiceDate, 'YYYY-MM-DD').format('DD/MM/YYYY');
	}

	function status(data, type, full, meta) {
		let workFlowStatusVal;
		switch (full.workFlowStatus) {
			case 1:
				workFlowStatusVal = '<a href="#" class="btn btn-primary" data-toggle="tooltip" title="'+full.errorDesc+'">PARTIAL_EXTRACTED</a>';
				break;
			case 2:
				workFlowStatusVal = 'SAVED';
				break;
			case 3:
				workFlowStatusVal = 'REGISTERED';
				break;
			case 4:
				workFlowStatusVal = 'GRN_PENDING';
				break;
			case 5:
				workFlowStatusVal = 'GRN_AVAILABLE';
				break;
			case 6:
				workFlowStatusVal = 'MATCHED';
				break;
			case 7:
				workFlowStatusVal = 'MISMATCHED';
				break;
			case 8:
				workFlowStatusVal = 'PD_APPROVAL_PENDING';
				break;
			case 9:
				workFlowStatusVal = 'PD_APPROVED';
				break;
			case 10:
				workFlowStatusVal = 'CAM_NOT_AVAILABLE';
				break;
			case 11:
				workFlowStatusVal = 'CAM_APPROVAL_PENDING';
				break;
			case 12:
				workFlowStatusVal = 'CAM_APPROVED';
				break;
			case 13:
				workFlowStatusVal = 'LN_APPROVED';
				break;
			case 14:
				workFlowStatusVal = 'PAYMENT';
				break;
			default:

		}
		return workFlowStatusVal;
	}

	$scope.deleteInvoice = function (headerId, workFlowStatus) {
		swal({
			title: "",
			text: "Are you sure want to delete",
			showCancelButton: true,
			confirmButtonColor: "#8B0000",
			confirmButtonText: "Yes",
			closeOnConfirm: true
		}, function (isConfirm) {
			if (isConfirm) {
				$http({
					method: 'DELETE',
					url: $rootScope.ctx + '/deleteInvoice/' + headerId
				}).then(function onSuccess(response) {
					$("#saveMsg")
						.show()
						.html('<div class="alert alert-success"<strong>' + response.data.message + '</strong> </div>')
						.fadeOut(3000);
					reloadData(workFlowStatus);
				}, function (err) {
					$("#saveMsg").show().html('<div class="alert alert-success"<strong>Failed</strong> </div>')
						.fadeOut(3000);
				})
			}
		});
	}

	function createdRow(row, data, dataIndex) {
		$compile(angular.element(row).contents())($scope);
	}

	function actionsHtml(data, type, full, meta) {
		return '<button type="button"  class="btn btn-primary margin-right-5" ng-click="loadInvoice(' + full.headerId + ')">' + '<i class="fa fa-pencil-square-o"></i>' + '</button>' +
			'<button type="button" class="btn btn-primary margin-right-5" ng-click="viewInvoice(' + full.headerId + ')">' + '<i class="fa fa-eye"></i>' + '</button>' +
			'<button type="button"   class="btn btn-danger" ng-click="deleteInvoice(' + full.headerId + ',' + full.workFlowStatus + ')">' + '<i class="fa fa-trash"></i> </button>';
	}

	$scope.viewInvoice = function (headerId) {
		$state.go('app.costInvoiceView', { 'headerId': headerId });
	}

	$scope.loadInvoice = function (headerId) {
		$state.go('app.editCost', { 'headerId': headerId });
	}
	//getting to fill ship To details
	$scope.getTenant = function () {
		$http({
			method: 'GET',
			url: $rootScope.ctx + '/getTenant/' + $cookies.get('tenantId'),
			headers: { 'loginDetails': JSON.stringify($scope.loginDetails) }
		}).then(function (response) {
			$scope.data.registeredName = response.data.tenantName;
			$scope.data.registeredId = response.data.registredId;
			$scope.data.registeredAddress = response.data.registredAddress;
			console.log(response.data)
		}, function (error) {
			console.log(error, 'can not get company.');
		});
	}

	function reloadData(status) {
		$scope.workFlowStatus = status;
		$scope.dtInstance.reloadData();
	}

	$scope.clear = function () {
		$scope.data = {};
		$scope.myForm.$submitted = false;
	}

}]);
