'use strict';

app.controller('viewCostInvoiceCtrl', ["$scope", "$rootScope", "$http", "$filter", "$stateParams", "ViewInvoiceService", "$timeout", "$cookies", "SendToErpService", function ($scope, $rootScope, $http, $filter, $stateParams, ViewInvoiceService, $timeout, $cookies, SendToErpService) {
	$scope.companydetails = {};
	$scope.dimensionData = [{ "id": "1", type: "Division" }, { "id": "2", type: "Item Group" }, { "id": "3", type: "Employee" }, { "id": "4", type: "Country" }, { "id": "5", type: "Business Partner" }, { "id": "6", type: "Period" }, { "id": "7", type: "Provision" }, { "id": "8", type: "Van/Sales Order" }]
	$scope.editobj = {};
	ViewInvoiceService.viewInvoice().then(function (response) {
		$scope.data = response.data.data;
		showWorkFlowStatus($scope.data.workFlowStatus);
	}, function (error) {
		console.log(error, 'no data.');
	});

	$scope.sendToErp = function () {
		for (var i = 0; i < $scope.data.items.length; i++) {
			if ($scope.data.items[i].dimensionsTypeMappingsdto) {
				$scope.editobj = $filter('filter')($scope.dimensionData, { type: $scope.data.items[i].dimensionType }, true)[0];
				$scope.data.items[i].dimensionType = $scope.editobj.id;
			}
		}
		console.log($scope.data);
		SendToErpService.sendCostToErpObj($scope.data, $scope.loginDetails).then(function (response) {
			$("#saveMsg").show().html('<div class="alert alert-success"<strong>' + response.data.message + '</strong> </div>');
		}, function (error) {
			console.log(error, 'no data.');
		});
	}

	$scope.submitCostInvoiceForApproval = function () {
		$http({
			method: 'POST',
			url: $rootScope.ctx + '/submitCostInvoiceForApproval',
			params: { "headerId": $scope.data.headerId },
			headers: { 'Content-Type': 'application/json', 'loginDetails': JSON.stringify($scope.loginDetails) }
		}).then(function (response) {
			console.log("(response.data", response.data);
			if (response.data.workFlowStatus == 5) {
				$("#saveMsg").show().html('<div class="alert alert-success"<strong>Cost Invoice Approved Sucessfully</strong> </div>');
			} else {
				$("#saveMsg").show().html('<div class="alert alert-danger"<strong>' + response.data.message + '</strong> </div>');
			}

		}).catch(function (response) {

		});
	}

	$scope.registedWithERP = function () {
		$http({
			method: 'POST',
			url: $rootScope.ctx + '/submitCostInvoiceForApproval',
			params: { "headerId": $scope.data.headerId },
			headers: { 'Content-Type': 'application/json' }
		}).then(function (response) {
			console.log("(response.data", response.data);
			if (response.data.workFlowStatus == 5) {
				$("#saveMsg").show().html('<div class="alert alert-success"<strong>Cost Invoice Approved Sucessfully</strong> </div>');
			} else {
				$("#saveMsg").show().html('<div class="alert alert-danger"<strong>' + response.data.message + '</strong> </div>');
			}

		}).catch(function (response) {

		});
	}

	$scope.sendForReject = function () {
		SendToErpService.sendForReject($scope.data.headerId, $scope.data.rejectReason, "CI").then(function (response) {
			$("#saveMsg").show().html('<div class="alert alert-success"<strong><b>' + response.data + '</b></strong> </div>');
		}, function (error) {
			console.log(error, 'no data.');
		});
	}

	$scope.getAllCountries = function () {
		$http({
			method: 'GET',
			url: $rootScope.ctx + '/getAllCountries'
		}).then(function (response) {
			$scope.country = response.data;
		}, function (error) {
			console.log(error, 'can not get getAllCountries.');
		});
	}
	$scope.getAllStates = function () {
		$http({
			method: 'GET',
			url: $rootScope.ctx + '/getAllStates'
		}).then(function (response) {
			$scope.state = response.data;
		}, function (error) {
			console.log(error, 'can not get getDashboardCounts.');
		});
	}

	function showWorkFlowStatus(workFlowStatus) {
		let workFlowStatusVal;
		switch (workFlowStatus) {
			case 1:
				workFlowStatusVal = '<span class="alert blinkSuccess">SAVED</span>';
				break;
			case 2:
				workFlowStatusVal = '<span class="alert blinkSuccess">REGISTERED</span>';
				break;
			case 3:
				workFlowStatusVal = '<span class="alert blinkSuccess">GRN_PENDING</span>';
				break;
			case 4:
				workFlowStatusVal = '<span class="alert blinkSuccess">GRN_AVAILABLE</span>';
				break;
			case 5:
				workFlowStatusVal = '<span class="alert blinkSuccess">MATCHED</span>';
				break;
			case 6:
				workFlowStatusVal = '<span class="alert blinkDanger">MISMATCHED</span>';
				break;
			case 7:
				workFlowStatusVal = '<span class="alert blinkInfo">PD_APPROVAL_PENDING</span>';
				break;
			case 8:
				workFlowStatusVal = '<span class="alert blinkInfo">PD_APPROVED</span>';
				break;
			case 9:
				workFlowStatusVal = '<span class="alert blinkInfo">LN_APPROVED</span>';
				break;
			case 10:
				workFlowStatusVal = '<span class="alert blinkInfo">PAYMENT</span>';
				break;
			default:

		}
		$("#invoiceStatus").show().html(workFlowStatusVal);
	}

	$scope.logisVisible = false;
	$scope.logShowHide = function () {
		//If DIV is visible it will be hidden and vice versa.
		$scope.logisVisible = $scope.logisVisible ? false : true;
		$scope.showLog();
	}

	$scope.showLog = function () {
		if ($scope.data.headerId) {
			$http({
				method: 'GET',
				url: $rootScope.ctx + '/showAuditLog/' + $scope.data.headerId + '/' + 'CI',
				data: $scope.data,
				headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': $('meta[name="_csrf"]').attr('content') }
			}).then(function (response) {
				console.log(response.data);

				angular.forEach(response.data, function (item) {

					var oldata = '';
					if (item.items[0]) {
						for (var i = 0; i < item.items[0].length; i++) {
							var nldata = '';
							var nlparseData = JSON.parse(JSON.stringify(item.items[0][i]));

							for (var key in nlparseData) {
								if (nldata) {
									nldata += ', ';
								}
								nldata += key + '=' + nlparseData[key];
							}
							item.items[0][i] = nldata;
						}
					}
					if (item.items[1]) {
						for (var i = 0; i < item.items[1].length; i++) {
							var oldata = '';
							var olparseData = JSON.parse(JSON.stringify(item.items[1][i]));

							for (var key in olparseData) {
								if (oldata) {
									oldata += ', ';
								}
								oldata += key + '=' + olparseData[key];
							}
							item.items[1][i] = oldata;
						}
					}
					var ndata = '';
					var odata = '';
					var nparseData = JSON.parse(item.newDate);
					for (var key in nparseData) {
						if (ndata) {
							ndata += ', ';
						}
						ndata += key + '=' + nparseData[key];
					}
					item.newDate = ndata;
					var oparseData = JSON.parse(item.oldData);
					for (var key in oparseData) {
						if (odata) {
							odata += ', ';
						}
						odata += key + '=' + oparseData[key];
					}
					item.oldData = odata;
				});
				$scope.log = response.data;
				console.log(response.data)
				$scope.log = response.data;
			}, function (error) {
				console.log("error occured while saving. not saved");
			});
		}
	}
	$scope.getAllStates();
	$scope.getAllCountries();

}]);




