'use strict';
app.controller('GeneratedQueueCtrl', ["$scope", "$rootScope", "DTOptionsBuilder", "DTColumnBuilder", "$http", "$filter", "$compile", "$state", "$cookies", '$localStorage', "InvoiceQueueService", function ($scope, $rootScope, DTOptionsBuilder, DTColumnBuilder, $http, $filter, $compile, $state, $cookies, $localStorage, InvoiceQueueService) {
    var vm = this;
    $scope.dtInstance = {};
    $scope.authorities = $rootScope.user.authorities;
    $scope.workFlowStatus;
    switch ($rootScope.user.roleMasterDto.roleId) {
        case 3:
            $scope.workFlowStatus = 1;
            break;
        case 4:
            $scope.workFlowStatus = 8;
            break;
        case 5:
            $scope.workFlowStatus = 11;
            break;
        default:

    }
    var tableIndex = "0";
    vm.singleRecord = {};
    $scope.params = {};
    vm.reloadData = reloadData;

    // Data Table
    vm.dtOptions = DTOptionsBuilder
        .newOptions()
        .withDataProp('data')
        .withOption('processing', true)
        .withOption('serverSide', true)
        .withOption('ajax', {
            url: $rootScope.ctx + '/getAllInvoices',
            type: 'GET',
            beforeSend: function (xhr) {
                xhr.setRequestHeader('Authorization', 'Bearer ' + $localStorage.token);
            },
            dataSrc: 'data',
            data: function (d) {
                d.transactionType = 'PI';
                d.workflowStatus = $scope.workFlowStatus;
                $scope.params.start = 0;
                $scope.params.length = 10;
                $scope.params.value = d.search.value ? d.search.value : '';
                d.search = $scope.params;
                tableIndex = d.start
                return d;
            },
            reload: function () {
                tableIndex = 0;
                this.reload = true;
                return this;
            },
            complete: function (res) {
                tableIndex = 0;
                $scope.tableData = res.responseJSON.data;
            }
        })
        .withDisplayLength($scope.limit)
        .withPaginationType('full_numbers')
        .withOption('createdRow', createdRow)
        .withOption('lengthMenu', [[10, 25, 50, -1], [10, 25, 50, "All"]])


    vm.dtColumns = [
        DTColumnBuilder.newColumn(null).withTitle('S.No').notSortable().renderWith(indexVal),
        DTColumnBuilder.newColumn('supplierName').withTitle('Supplier Name'),
        DTColumnBuilder.newColumn('invoiceDate').withTitle('Invoice Date'),
        DTColumnBuilder.newColumn('invoiceNo').withTitle('Invoice Number'),
        DTColumnBuilder.newColumn('poNumber').withTitle('PO Number'),
        DTColumnBuilder.newColumn('workFlowStatus').withTitle('Status').renderWith(status),
        DTColumnBuilder.newColumn(null).withTitle('Action').notSortable().renderWith(actionsHtml).withOption('width', '100px')
    ];

    function indexVal() {
        return ++tableIndex;
    }

    function createdRow(row, data, dataIndex) {
        $compile(angular.element(row).contents())($scope);
    }

    $scope.getManagerDetails = function () {
        $http({
            method: 'get',
            url: $rootScope.ctx + '/getManagerDetails/' + $cookies.get('userId'),
            async: false,
        }).then(function (response) {
            $scope.isManager = response.data.isManager;
            $scope.hasManager = response.data.hasManager;
            console.log($scope.isManager)
        }, function (error) {
            console.log(error, 'can not get states.');
        });
    }

    $scope.authorityFilter = function (id) {
        var authority = $rootScope.user.authorities.filter(i => i.id == id)[0];
        if (authority && authority.id) {
            return true;
        } else {
            return false;
        }
    }

    function status(data, type, full, meta) {
        let workFlowStatusVal;
        switch (full.workFlowStatus) {
            case 1:
                workFlowStatusVal = 'PARTIAL_EXTRACTED';
                break;
            case 2:
                workFlowStatusVal = 'SAVED';
                break;
            case 3:
                workFlowStatusVal = 'REGISTERED';
                break;
            case 4:
                workFlowStatusVal = 'GRN_PENDING';
                break;
            case 5:
                workFlowStatusVal = 'GRN_AVAILABLE';
                break;
            case 6:
                workFlowStatusVal = 'MATCHED';
                break;
            case 7:
                workFlowStatusVal = 'MISMATCHED';
                break;
            case 8:
                workFlowStatusVal = 'PD_APPROVAL_PENDING';
                break;
            case 9:
                workFlowStatusVal = 'PD_APPROVED';
                break;
            case 10:
                workFlowStatusVal = 'CAM_NOT_AVAILABLE';
                break;
            case 11:
                workFlowStatusVal = 'CAM_APPROVAL_PENDING';
                break;
            case 12:
                workFlowStatusVal = 'CAM_APPROVED';
                break;
            case 13:
                workFlowStatusVal = 'LN_APPROVED';
                break;
            case 14:
                workFlowStatusVal = 'PAYMENT';
                break;
            default:

        }
        return workFlowStatusVal;
    }
    //To get the serial No in Data Table 
    function indexVal() {
        return ++tableIndex;
    }
    function actionsHtml(data, type, full, meta) {
        var invoiceAction = '';
        // if (full.workFlowStatus != 2 || full.workFlowStatus != 0) {

        // }
        invoiceAction += '<button type="button"  class="btn btn-primary margin-right-5" ng-click="loadInvoice(' + full.headerId + ')">' + '<i class="fa fa-pencil-square-o"></i>' + '</button>';
        invoiceAction += '<button type="button"  class="btn btn-primary margin-right-5" ng-click="viewInvoice(' + full.headerId + ')">' + '<i class="fa fa-eye"></i>' + '</button>';
        invoiceAction += '<button type="button"  class="btn btn-danger" ng-click="deleteInvoice(' + full.headerId + ',' + full.workFlowStatus + ')">' + '<i class="fa fa-trash"></i> </button>';
        vm.singleRecord[full.headerId] = full;
        return invoiceAction;
    }

    $scope.viewInvoice = function (headerId) {
        $state.go('app.view', { headerId: headerId });
    }

    $scope.loadInvoice = function (headerId) {
        $state.go('app.edit', { headerId: headerId });
    }
    $scope.deleteInvoice = function (headerId, workFlowStatus) {
        swal({
            title: "",
            text: "Are you sure want to delete",
            showCancelButton: true,
            confirmButtonColor: "#8B0000",
            confirmButtonText: "Yes",
            closeOnConfirm: true
        }, function (isConfirm) {
            if (isConfirm) {
                $http({
                    method: 'DELETE',
                    url: $rootScope.ctx + '/deleteInvoice/' + headerId
                }).then(function onSuccess(response) {
                    $("#saveMsg")
                        .show()
                        .html('<div class="alert alert-success"<strong>' + response.data.message + '</strong> </div>')
                        .fadeOut(3000);
                    reloadData(workFlowStatus);
                }, function (err) {
                    $("#saveMsg").show().html('<div class="alert alert-success"<strong>Failed</strong> </div>')
                        .fadeOut(3000);
                })
            }
        });
    }
    function reloadData(status) {
        $scope.workFlowStatus = status;
        $scope.dtInstance.reloadData();
    }

    $scope.onload = function () {
        $scope.getManagerDetails();
    }
    $scope.onload();
}]);
