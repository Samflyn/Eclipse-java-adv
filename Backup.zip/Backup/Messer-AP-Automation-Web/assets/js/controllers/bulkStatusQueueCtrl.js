app.controller('failedBulkStatusQueueCtrl', ["$scope", "$rootScope", "$http", "$q", "$cookies", "$filter", "$compile", "DTOptionsBuilder", "DTColumnBuilder", "viewBulkStatusQueueService", "$timeout", "$stateParams", "$window", function ($scope, $rootScope, $http, $q, $cookies, $filter, $compile, DTOptionsBuilder, DTColumnBuilder, viewBulkStatusQueueService, $timeout, $stateParams, $window) {
	$scope.data = {};
	$scope.params = {};
	var vm = this;
	vm.singleRecord = {};
	$scope.dtInstance = {};
	var tableIndex = "0";

	vm.dtOptions = DTOptionsBuilder.fromFnPromise(function () {
		var defer = $q.defer();
		$http.get($rootScope.ctx + '/getAllFailedInvoices').then(function (result) {
			defer.resolve(result.data);
		});
		return defer.promise;
	}).withPaginationType('full_numbers').withOption('createdRow', createdRow);
	function createdRow(row, data, dataIndex) {
		$compile(angular.element(row).contents())($scope);
	};

	vm.dtColumns = [
		DTColumnBuilder.newColumn('null').withTitle('S.No').notSortable().renderWith(serialNoHtml),
		DTColumnBuilder.newColumn('filePath').withTitle('File Path'),
		DTColumnBuilder.newColumn('processedDate').withTitle('Processed Date'),
		DTColumnBuilder.newColumn(null).withTitle('').notSortable()
			.renderWith(actionsHtml).withOption('width', '70px')
	];

	function createdRow(row, data, dataIndex) {
		$compile(angular.element(row).contents())($scope);
	}

	function serialNoHtml() {
		return ++tableIndex;
	}

	function toappend(data, type, full, meta) {
		return full.fileSize + " KB";
	}

	function actionsHtml(data, type, full, meta) {
		return '<button data-toggle="tooltip" data-placement="bottom" title="Reason to Fail" class="btn btn-primary" ng-click="editDetails(showCase.uqc[' + full.id + '])" >' +
			'   <i class="fa fa-eye"></i>' +
			'</button> <button data-placement="bottom" title="Retry" class="btn btn-warning" ng-click=\'retryOCR(' + JSON.stringify(full) + ')\' >' +
			'  <i class="fa fa-repeat"></i>' +
			'</button> ';
	}
	$scope.$on('failed-reload', function (e, args) {
		$scope.dtInstance.reloadData();
	})

	$scope.editDetails = function (obj) {
		$scope.reason = obj.reason;
		$('#myModal').modal();
	}

	$scope.clear = function () {
		$scope.data = {};
		$scope.myForm.$submitted = false;
	}

}]);



