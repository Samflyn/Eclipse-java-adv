'use strict';
/**
 * controllers for all pages
 */

app.controller('chooseGSTIN', ["$scope", "$rootScope", "$http", "$uibModal", "$log", "$cookies", function ($scope, $rootScope, $http, $uibModal, $log, $cookies) {

    

}]);

