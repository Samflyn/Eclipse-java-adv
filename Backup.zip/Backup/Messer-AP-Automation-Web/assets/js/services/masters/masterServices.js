(function () {
    'use strict';
    app.service('MasterServices', MasterServices);
    MasterServices.$inject = ['$http', '$rootScope', '$q'];

    function MasterServices($http, $rootScope, $q) {
        var obj = {
            createWareHouse: createWareHouse,
            createdivision: createdivision,
            createCostCenter: createCostCenter,
            saveStandardActiviti: save,
            getCostCenter: getCostCenter,
            getDivisions: getDivisions,
            getAllWareHouse: getAllWareHouse,
            createSundryCost: createSundryCost,
            getSundryCosts: getSundryCosts,
            deletesundrycost: deletesundrycost,
            getLedgers: getLedgers,
            getCostDimensionsMasters: getCostDimensionsMasters,
            getUserByDept: getUserByDept,
            getDepartments: getDepartments,
            getAllSuppliers: getAllSuppliers,

            saveUser: saveUser,
            getCAMUsers: getCAMUsers,
            getAllCustomers: getAllCustomers,
            getAllDepartments: getAllDepartments,
            getAllCompanies: getAllCompanies,
            getAllCountries: getAllCountries,
            getAllRoles: getAllRoles,
            getAllStates: getAllStates,
            getAllManagers: getAllManagers,
            getAllDimensions: getAllDimensions,
            getAllCostComponent: getAllCostComponent,
            saveSupplier: saveSupplier,
            getAllSuppliers: getAllSuppliers,
            saveDepartment: saveDepartment,
            saveDimensionType: saveDimensionType,
            saveLedgerAccount: saveLedgerAccount,
            saveLedgerAccountMapping: saveLedgerAccountMapping,
            saveCostComponent: saveCostComponent,
            saveStandardElements: saveStandardElements,
            getAllStandardElements: getAllStandardElements,
            getAllStandardActivities: getAllStandardActivities,
            saveItemMaster: saveItemMaster,
            excelItemMaster: excelItemMaster,
            getItems: getItems,
            getItemMaster: getItemMaster,
            getItemMapping: getItemMapping,
            saveItemMapping: saveItemMapping,
            saveExcelItemMapping: saveExcelItemMapping,
            getUqcList: getUqcList,
            saveuqc: saveuqc,
            excelSaveUqc: excelSaveUqc,
            saveUqcMapping: saveUqcMapping,
            saveExcelUqcMapping: saveExcelUqcMapping,
            getUqcMapping: getUqcMapping,
            saveCompany: saveCompany,
            saveCountry: saveCountry,
            saveRole: saveRole,
            saveErrorMaster: saveErrorMaster,
            getErrorMasters: getErrorMasters
        }

        function createWareHouse(data) {
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: $rootScope.ctx + '/createWareHouse',
                data: data,
            }).then(function (response) {
                deferred.resolve(response);
            }).catch(function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }

        function createdivision(data) {
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: $rootScope.ctx + '/createdivision',
                data: data,
            }).then(function (response) {
                deferred.resolve(response);
            }).catch(function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }

        function createCostCenter(data) {
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: $rootScope.ctx + '/createCostCenter',
                data: data,
            }).then(function (response) {
                deferred.resolve(response);
            }).catch(function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }

        function save(data) {
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: $rootScope.ctx + '/saveStandardActiviti',
                data: data,
            }).then(function (response) {
                deferred.resolve(response);
            }).catch(function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }

        function getCostCenter() {
            var deferred = $q.defer();
            $http({
                method: 'Get',
                url: $rootScope.ctx + '/getAllCostCenters',
            }).then(function (response) {
                deferred.resolve(response);
            }).catch(function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }

        function getDimensions() {
            var deferred = $q.defer();
            $http({
                method: 'Get',
                url: $rootScope.ctx + '/getDimensions',
            }).then(function (response) {
                deferred.resolve(response);
            }).catch(function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }

        function getDivisions() {
            var deferred = $q.defer();
            $http({
                method: 'Get',
                url: $rootScope.ctx + '/getDivisions',

            }).then(function (response) {
                deferred.resolve(response);
            }).catch(function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }

        function getAllWareHouse() {
            var deferred = $q.defer();
            $http({
                method: 'Get',
                url: $rootScope.ctx + '/getAllWareHouse',

            }).then(function (response) {
                deferred.resolve(response);
            }).catch(function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }
        function deleteCostCenter(data) {
            var deferred = $q.defer();
            $http({
                method: 'DELETE',
                url: $rootScope.ctx + '/deleteCostCenter' + data,

            }).then(function (response) {
                deferred.resolve(response);
            }).catch(function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }

        function getSundryCosts() {
            var deferred = $q.defer();
            $http({
                method: 'Get',
                url: $rootScope.ctx + '/getSundryCosts',

            }).then(function (response) {
                deferred.resolve(response);
            }).catch(function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }
        function deletesundrycost(data) {
            var deferred = $q.defer();
            $http({
                method: 'DELETE',
                url: $rootScope.ctx + '/deletesundrycost/' + data,

            }).then(function (response) {
                deferred.resolve(response);
            }).catch(function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }

        function createSundryCost(data) {
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: $rootScope.ctx + '/createSundryCost',
                data: data,
            }).then(function (response) {
                deferred.resolve(response);
            }).catch(function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }

        function getUsersByDepartMent() {
            var deferred = $q.defer();
            $http({
                method: 'Get',
                url: $rootScope.ctx + '/getDivisions',

            }).then(function (response) {
                deferred.resolve(response);
            }).catch(function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }

        function getLedgers() {
            var deferred = $q.defer();
            $http({
                method: 'Get',
                url: $rootScope.ctx + '/getAllLedgerAccounts',
            }).then(function (response) {
                deferred.resolve(response);
            }).catch(function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }

        function getCostDimensionsMasters() {
            var deferred = $q.defer();
            $http({
                method: 'Get',
                url: $rootScope.ctx + '/getCostDimensionsMaster',
            }).then(function (response) {
                deferred.resolve(response);
            }).catch(function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }

        function getUserByDept(data) {
            var deferred = $q.defer();
            $http({
                method: 'Get',
                url: $rootScope.ctx + '/users/getUserByDept' + data,
                param: { 'deptId': data },
            }).then(function (response) {
                deferred.resolve(response.data);
            }).catch(function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }

        function getDepartments() {
            var deferred = $q.defer();
            $http({
                method: 'Get',
                url: $rootScope.ctx + '/getAllDepartments',
            }).then(function (response) {
                deferred.resolve(response);
            }).catch(function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }
        function getAllSuppliers(data) {
            var deferred = $q.defer();
            $http({
                method: 'Get',
                url: $rootScope.ctx + '/getAllSuppliers'
            }).then(function (response) {
                deferred.resolve(response);
            }).catch(function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }
        function saveUser(data) {
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: $rootScope.ctx + '/user/create',
                data: data,
                headers: { 'Content-Type': 'application/json' }
            }).then(function (response) {
                deferred.resolve(response);
            }).catch(function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }
        //get Cam users
        function getCAMUsers() {
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: $rootScope.ctx + '/user/getCAMUsers',
                headers: { 'Content-Type': 'application/json' }
            }).then(function (response) {
                deferred.resolve(response);
            }).catch(function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }
        //get Customers
        function getAllCustomers() {
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: $rootScope.ctx + '/company/getAll',
            }).then(function (response) {
                deferred.resolve(response);
            }).catch(function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }
        //get Departments
        function getAllDepartments() {
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: $rootScope.ctx + '/getAllDepartments',
            }).then(function (response) {
                deferred.resolve(response);
            }).catch(function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }
        //get Managers
        function getAllManagers(data) {
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: $rootScope.ctx + '/user/getAll?userId=' + data,
                params: { "userId": $rootScope.user.userId }
            }).then(function (response) {
                deferred.resolve(response);
            }).catch(function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }


        //get states
        function getAllStates() {
            var deferred = $q.defer();
            $http({
                method: 'get',
                url: $rootScope.ctx + '/getAllStates',
            }).then(function (response) {
                deferred.resolve(response);
            }).catch(function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }

        //get countries
        function getAllCountries() {
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: $rootScope.ctx + '/getAllCountries',
            }).then(function (response) {
                deferred.resolve(response);
            }).catch(function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }
        //get companies
        function getAllCompanies() {
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: $rootScope.ctx + '/getAllCompanies',
            }).then(function (response) {
                deferred.resolve(response);
            }).catch(function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }
        //get roles
        function getAllRoles() {
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: $rootScope.ctx + '/getAllUserRoles',
            }).then(function (response) {
                deferred.resolve(response);
            }).catch(function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }

        //get dimensions
        function getAllDimensions() {
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: $rootScope.ctx + '/getAllDimensions',
            }).then(function (response) {
                deferred.resolve(response);
            }).catch(function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }

        function getAllCostComponent() {
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: $rootScope.ctx + '/getAllCostComponent',
            }).then(function (response) {
                deferred.resolve(response);
            }).catch(function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }

        function saveSupplier(data) {
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: $rootScope.ctx + '/saveSupplier',
                headers: { 'Content-Type': 'application/json' },
                data: data
            }).then(function (response) {
                deferred.resolve(response);
            }).catch(function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }

        function saveDepartment(data) {
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: $rootScope.ctx + '/department/create',
                data: data,
                headers: { 'Content-Type': 'application/json' }
            }).then(function (response) {
                deferred.resolve(response);
            }).catch(function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }

        function saveDimensionType(data) {
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: $rootScope.ctx + '/dimensionType/create',
                data: data,
                headers: { 'Content-Type': 'application/json' }
            }).then(function (response) {
                deferred.resolve(response);
            }).catch(function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }

        function saveLedgerAccount(data) {
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: $rootScope.ctx + '/ledgerAccount/create',
                data: data,
                headers: { 'Content-Type': 'application/json' }
            }).then(function (response) {
                deferred.resolve(response);
            }).catch(function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }

        function saveLedgerAccountMapping(data) {
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: $rootScope.ctx + '/ledgerAccount/create',
                data: data,
                headers: { 'Content-Type': 'application/json' }
            }).then(function (response) {
                deferred.resolve(response);
            }).catch(function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }

        function saveCostComponent(data) {
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: $rootScope.ctx + '/saveCostComponent',
                data: data,
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': $http.defaults.headers.common.Authorization
                }
            }).then(function (response) {
                deferred.resolve(response);
            }).catch(function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }

        function saveStandardElements(data) {
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: $rootScope.ctx + '/saveStandardElements',
                data: data,
            }).then(function (response) {
                deferred.resolve(response);
            }).catch(function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }

        function getAllStandardElements() {
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: $rootScope.ctx + '/getAllStandardElements',
            }).then(function (response) {
                deferred.resolve(response);
            }).catch(function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }

        function getAllStandardActivities() {
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: $rootScope.ctx + '/getAllStandardActivities',
            }).then(function (response) {
                deferred.resolve(response);
            }).catch(function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }

        function saveItemMaster(data) {
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: $rootScope.ctx + '/saveItemMaster',
                data: data,
                headers: { 'Content-Type': 'application/json' }
            }).then(function (response) {
                deferred.resolve(response);
            }).catch(function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }

        function excelItemMaster(data) {
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: $rootScope.ctx + '/saveExcelItems',
                data: data,
                headers: { 'Content-Type': 'application/json' }
            }).then(function (response) {
                deferred.resolve(response);
            }).catch(function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }

        function getItems(companyId) {
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: $rootScope.ctx + '/getItems?companyId=' + companyId,
            }).then(function (response) {
                deferred.resolve(response);
            }).catch(function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }

        function saveItemMapping(data) {
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: $rootScope.ctx + '/saveItemMapping',
                data: data,
                headers: { 'Content-Type': 'application/json' }
            }).then(function (response) {
                deferred.resolve(response);
            }).catch(function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }

        function saveExcelItemMapping(data) {
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: $rootScope.ctx + '/saveExcelItemMapping',
                data: data,
                headers: { 'Content-Type': 'application/json' }
            }).then(function (response) {
                deferred.resolve(response);
            }).catch(function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }

        function getItemMaster() {
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: $rootScope.ctx + '/getItemMaster',
            }).then(function (response) {
                deferred.resolve(response);
            }).catch(function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }

        function getItemMapping(companyId) {
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: $rootScope.ctx + '/getItemMapping?companyId=' + companyId,
            }).then(function (response) {
                deferred.resolve(response);
            }).catch(function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }

        function saveuqc(data, loginDetails) {
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: $rootScope.ctx + '/saveuqc',
                data: data,
                headers: { 'Content-Type': 'application/json', 'loginDetails': JSON.stringify(loginDetails) }
            }).then(function (response) {
                deferred.resolve(response);
            }).catch(function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }

        function excelSaveUqc(data, loginDetails) {
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: $rootScope.ctx + '/saveExcelUqc',
                data: data,
                headers: { 'Content-Type': 'application/json', 'loginDetails': JSON.stringify(loginDetails) }
            }).then(function (response) {
                deferred.resolve(response);
            }).catch(function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }

        function getUqcList(companyId) {
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: $rootScope.ctx + '/getUqcList?companyId=' + companyId,
            }).then(function (response) {
                deferred.resolve(response);
            }).catch(function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }

        function saveUqcMapping(data) {
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: $rootScope.ctx + '/saveUqcMapping',
                data: data,
                headers: { 'Content-Type': 'application/json' }
            }).then(function (response) {
                deferred.resolve(response);
            }).catch(function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }

        function saveExcelUqcMapping(data) {
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: $rootScope.ctx + '/saveExcelUqcMapping',
                data: data,
                headers: { 'Content-Type': 'application/json' }
            }).then(function (response) {
                deferred.resolve(response);
            }).catch(function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }

        function getUqcMapping(companyId) {
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: $rootScope.ctx + '/getUqcMapping?companyId=' + companyId,
            }).then(function (response) {
                deferred.resolve(response);
            }).catch(function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }

        function saveCompany(data) {
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: $rootScope.ctx + '/company/create',
                data: data,
            }).then(function (response) {
                deferred.resolve(response);
            }).catch(function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }

        function saveRole(data, loginDetails) {
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: $rootScope.ctx + '/saveUserRoles',
                data: data,
                headers: { 'Content-Type': 'application/json', 'loginDetails': JSON.stringify(loginDetails) }
            }).then(function (response) {
                deferred.resolve(response);
            }).catch(function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }

        function saveCountry(data, loginDetails) {
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: $rootScope.ctx + '/saveCountry',
                data: data,
                headers: { 'Content-Type': 'application/json', 'loginDetails': JSON.stringify(loginDetails) }
            }).then(function (response) {
                deferred.resolve(response);
            }).catch(function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }

        function saveState(data, loginDetails) {
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: $rootScope.ctx + '/savestate',
                data: data,
                headers: { 'Content-Type': 'application/json', 'loginDetails': JSON.stringify(loginDetails) }
            }).then(function (response) {
                deferred.resolve(response);
            }).catch(function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }

        function saveErrorMaster(data, loginDetails) {
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: $rootScope.ctx + '/saveErrorMaster',
                data: data,
                headers: { 'Content-Type': 'application/json', 'loginDetails': JSON.stringify(loginDetails) }
            }).then(function (response) {
                deferred.resolve(response);
            }).catch(function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }

        //get Error Masters
        function getErrorMasters() {
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: $rootScope.ctx + '/getErrorMasters',
            }).then(function (response) {
                deferred.resolve(response);
            }).catch(function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }

        return obj;
    }
}());