1:  Please put the files on a Server or on a Local Development Web Server to preview.

Then to access the preview, type in the address bar of the browser:

http://localhost/AngularJs-Admin/STANDARD/
http://localhost/AngularJs-Admin/RTL/



2: Use Grunt and Bower

install node.js
go to the AngularJs-Admin root into the command line

>npm install -g grunt-cli
>npm install
>grunt bower-install-simple
>npm start


> grunt build:standardversion
to build the 'standardversion' folder

> grunt build:rtlversion
to build the 'rtlversion' folder
