package com.sailotech.mcap.util;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.util.StringUtils;
import org.springframework.web.servlet.view.document.AbstractXlsxView;

import com.sailotech.mcap.dto.WorkFlowStatus;
import com.sailotech.mcap.entity.InvoiceHeader;
import com.sailotech.mcap.entity.InvoiceLines;

public class InvoiceExcelReport extends AbstractXlsxView {



	@Override
	protected void buildExcelDocument(Map<String, Object> model, Workbook workbook, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		response.setHeader("Content-Disposition", "attachment; filename=\"InvoiceReport.xls\"");

		@SuppressWarnings("unchecked")
		List<InvoiceHeader> headers = (List<InvoiceHeader>) model.get("results");
		
			Sheet sheet = workbook.createSheet("Invoice Report");
			Row headingRow = sheet.createRow(0);
		/*if("Vendor".equals(loginDetails.getRoleName())){
			for (int i = 0; i < SVMPConstants.VENDOR_INVOICE_HEADERS.length; i++) {
				headingRow.createCell(i).setCellValue(SVMPConstants.VENDOR_INVOICE_HEADERS[i]);
			}
			}else{*/
				for (int i = 0; i < MesserApAutomationConstants.INVOICE_HEADERS.length; i++) {
					headingRow.createCell(i).setCellValue(MesserApAutomationConstants.CUSTOMER_INVOICE_HEADERS[i]);
				}	
		//	}
		int rowCount = 1;
		for (InvoiceHeader invoiceheader : headers) {
			for (InvoiceLines invoiceLines : invoiceheader.getItems()) {
				Row row = sheet.createRow(rowCount++);
				excelForHeaders(invoiceheader, invoiceLines, row);
			}
		}
		 System.out.println("End of method");
	}

	public void excelForHeaders(InvoiceHeader invoiceheader, InvoiceLines invoiceLines, Row row) {
		if (!StringUtils.isEmpty(invoiceheader.getSupplierName())) {
			row.createCell(0).setCellValue(invoiceheader.getHeaderId());
		}
		if (!StringUtils.isEmpty(invoiceheader.getSupplierIdentifier())) {
			row.createCell(1).setCellValue(invoiceheader.getSupplierIdentifier());
		}
		if (!StringUtils.isEmpty(invoiceheader.getInvoiceNo())) {
			row.createCell(2).setCellValue(invoiceheader.getInvoiceNo());
		}
		if (!StringUtils.isEmpty(invoiceheader.getInvoiceDate().toString())) {
			row.createCell(3).setCellValue(invoiceheader.getInvoiceDate().toString());
		}
		if (!StringUtils.isEmpty(invoiceheader.getPoNumber())) {
			row.createCell(4).setCellValue(invoiceheader.getPoNumber());
		}
		if (!StringUtils.isEmpty(invoiceheader.getDeliveryDate())) {
			row.createCell(5).setCellValue(invoiceheader.getDeliveryDate().toString());
		}
		if (!StringUtils.isEmpty(invoiceLines.getItemDesc())) {
			row.createCell(6).setCellValue(invoiceLines.getItemDesc());
		}
		if (!StringUtils.isEmpty(invoiceLines.getItemRate())) {
			row.createCell(7).setCellValue(invoiceLines.getItemRate());
		}
		if (!StringUtils.isEmpty(invoiceLines.getLineValue())) {
			row.createCell(8).setCellValue(invoiceLines.getLineValue());
		}
		if (!StringUtils.isEmpty(invoiceheader.getInvoiceAmountNt())) {
			row.createCell(9).setCellValue(invoiceheader.getInvoiceAmountNt().toString());
		}
		if (!StringUtils.isEmpty(invoiceheader.getWorkFlowStatus())) {
			row.createCell(10).setCellValue(WorkFlowStatus.getNameByValue(invoiceheader.getWorkFlowStatus()));
		}
	}

}
