package com.sailotech.mcap.dto;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

@Data
@JsonIgnoreProperties
public class FailedInvoicesDto implements Serializable {

	private static final long serialVersionUID = 5317209769244252832L;

	private String filePath;

	private Integer companyId;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy/MM/dd")
	private Date processedDate;

	private String reason;

}
