package com.sailotech.mcap.master.service;

import java.util.List;

import com.sailotech.mcap.dto.WareHouseDto;
import com.sailotech.mcap.exception.MesserApAutomationException;

public interface WareHouseService {
	
	void save(WareHouseDto wareHouseDto) throws MesserApAutomationException;

	List<WareHouseDto> getAllWareHouse();

	String deleteByWareHouseId(Integer id);
	
	

}
