/**
 * 
 */
package com.sailotech.mcap.util;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Component;

/**
 * @author nagavamsipriya.tirum
 *
 */
@Component
public class AngularDataTablesParamUtility {
	public AngularDataTableParamModel getParam(HttpServletRequest request) {
		AngularDataTableParamModel param = new AngularDataTableParamModel();
		param.setsSearch(request.getParameter("search[value]")) ;
		param.setsColumns(request.getParameter("columns"));
		param.setiDisplayStart(Integer.parseInt(request.getParameter("start")));
		param.setiDisplayLength(Integer.parseInt(request.getParameter("length"))) ;
		param.setiSortColumnIndex(Integer.parseInt(request.getParameter("order[0][column]")));
		param.setsSortDirection(request.getParameter("order[0][dir]"));
		return param;
	}

}

