package com.sailotech.mcap.master.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.sailotech.mcap.dto.DepartmentDto;

@Service
public interface DepartmentService {

	public String saveDepartment(DepartmentDto departmentDto);

	public List<DepartmentDto> getAllDepartments();

	public String deleteDepartment(Integer deptId);

}
