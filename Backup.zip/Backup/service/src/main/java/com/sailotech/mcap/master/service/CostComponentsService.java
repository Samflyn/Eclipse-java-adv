package com.sailotech.mcap.master.service;

import com.sailotech.mcap.dto.CostComponentsDto;

public interface CostComponentsService {
	
	public String save(CostComponentsDto costComponent);

	public String getAll();
	
	public String delete(Integer id);

}
