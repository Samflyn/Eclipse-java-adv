package com.sailotech.mcap.master.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sailotech.mcap.dto.StandardActivitiesDto;
import com.sailotech.mcap.entity.StandardActivities;
import com.sailotech.mcap.entity.StandardElements;
import com.sailotech.mcap.master.repository.StandardActivitiesRepository;
import com.sailotech.mcap.master.service.StandardActivitiesService;
import com.sailotech.mcap.util.MesserApAutomationConstants;
import com.sailotech.mcap.util.MesserApAutomationUtil;

@Service
public class StandardActivitiesServiceImpl implements StandardActivitiesService {
	
	@Autowired 
	private StandardActivitiesRepository standardActivitiesRepository;
	
	@Autowired
	MesserApAutomationUtil messerApAutomationUtil;

	@Override
	public String save(StandardActivitiesDto standardActivitiesDto) {
		StandardActivities standardActivities = messerApAutomationUtil.copyBeanProperties(standardActivitiesDto, StandardActivities.class);
		if (standardActivities.getId() != null) {
			standardActivities.setUpdate();
		} else {
			standardActivities.setSave();;
		}
		StandardActivities save = standardActivitiesRepository.save(standardActivities);
		Map<String, String> dataMap = new HashMap<>();
		dataMap.put(MesserApAutomationConstants.MESSAGE, "Standard Activities details created successfully");
		dataMap.put(MesserApAutomationConstants.STATUS, MesserApAutomationConstants.SUCCESS_STATUS);
		dataMap.put("standardElementsDto",messerApAutomationUtil.convertPojoToJson(messerApAutomationUtil.copyBeanProperties(save, StandardActivitiesDto.class)));
		return messerApAutomationUtil.convertPojoToJson(dataMap);
	}

	@Override
	public String getAll() {
		List<StandardActivities> standardActivities = (List<StandardActivities>) standardActivitiesRepository.findAll();
		List<StandardActivitiesDto> standardActivitiesDto = new ArrayList<>();
		for (StandardActivities standardActivitie : standardActivities) {
			StandardActivitiesDto dto = new StandardActivitiesDto();
			BeanUtils.copyProperties(standardActivitie, dto);
			standardActivitiesDto.add(dto);
		}
		return messerApAutomationUtil.convertPojoToJson(standardActivitiesDto);
	}

	@Override
	public String delete(Integer id) {
		standardActivitiesRepository.deleteById(id);
		Map<String, String> dataMap = new HashMap<>();
		dataMap.put(MesserApAutomationConstants.MESSAGE, "Standard Activities  deleted successfully");
		dataMap.put(MesserApAutomationConstants.STATUS, MesserApAutomationConstants.SUCCESS_STATUS);
		return messerApAutomationUtil.convertPojoToJson(dataMap);
	}

}
