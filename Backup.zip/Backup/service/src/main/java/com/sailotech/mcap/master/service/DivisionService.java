package com.sailotech.mcap.master.service;

import java.util.List;

import com.sailotech.mcap.dto.DivisionDto;
import com.sailotech.mcap.exception.MesserApAutomationException;

public interface DivisionService {

	void save(DivisionDto divisionDto) throws MesserApAutomationException;

	public List<DivisionDto> getAllDivisions();

	String deleteByDivisionId(Integer id);

}
