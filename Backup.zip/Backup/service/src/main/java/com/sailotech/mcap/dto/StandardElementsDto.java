package com.sailotech.mcap.dto;

import java.io.Serializable;

import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;


@Component
@Getter
@Setter
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class StandardElementsDto extends BaseDto implements Serializable{

	private static final long serialVersionUID = -2140635894729318819L;

	private Integer id;
	
	private String standardElements;
	
	private String description;
	
	private String unit;
	

}

