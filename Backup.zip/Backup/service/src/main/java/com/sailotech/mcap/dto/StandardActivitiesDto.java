package com.sailotech.mcap.dto;

import java.io.Serializable;

import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

@Component
@Setter
@Getter
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class StandardActivitiesDto extends BaseDto implements Serializable{

	private static final long serialVersionUID = -7498492157718392276L;
	
	private Integer id;
	
	private String standardActivities;
	
	private String description;
	
	private String activityType;;
	
	private String unit;

}
