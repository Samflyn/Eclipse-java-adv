package com.sailotech.mcap.exception;

import com.sailotech.mcap.dto.EventResponse;

public class MesserApAutomationException extends Exception {

	private static final long serialVersionUID = 1L;

	private final EventResponse errorResponse;

	public MesserApAutomationException(String errorCode, String errorMessage) {
		errorResponse = new EventResponse();
		errorResponse.setStatus(false);
		errorResponse.setStatusCode(errorCode);
		errorResponse.setMessage(errorMessage);
	}

	public EventResponse getErrorResponse() {
		return errorResponse;
	}

}
