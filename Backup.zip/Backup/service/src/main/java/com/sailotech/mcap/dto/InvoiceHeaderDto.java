package com.sailotech.mcap.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * @author Nagendra
 *
 * @version 1.0
 *
 */
@Component
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
@JsonIgnoreProperties(ignoreUnknown = true)
@Setter
@Getter
@EqualsAndHashCode(of = "headerId", callSuper = false)
public class InvoiceHeaderDto extends BaseDto implements Serializable {

	private static final long serialVersionUID = -4420170849360736852L;

	private Integer headerId;

	private Integer userId;

	private Integer deptId;

	private Integer companyId;

	private String invoiceNo;

	private String oinum;

	private String poNumber;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	private Date serviceDate;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	private Date invoiceDate;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	private Date deliveryDate;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	private Date createdOn;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	private Date lastUpdatedOn;

	private Double invoiceAmountGross;

	private Double invoiceAmountNt;

	private Integer workFlowStatus;

	private String channelType;

	private String errorDesc;

	private String rejectReason;

	private String ibanNo;

	private String accountNo;

	private String companyName;

	private String companyAddress;

	private String supplierName;

	private String supplierAddress;

	private String supplierIdentifier;

	private String vehiclePlateNo;

	private String costCenterCode;

	private String costAccountMgr;

	private String vatId;

	private Integer nPages;

	private String transactionType;

	private String filePath;

	private Long fileSize;

	private String invoiceId;

	private String sourceCompany;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	private Date postingDate;

	private String financialBatch;

	private String lnStatus;
	private String currency;
	private String noteType;
	private String typeOfInvoice;
	
	private List<InvoiceLinesDto> items;
	
	//below are required for only ERP Request
	private String supplierTxnType;
	

}
