package com.sailotech.mcap.master.service;

import java.util.List;

import com.sailotech.mcap.dto.UserDto;
import com.sailotech.mcap.exception.DataValidationException;
import com.sailotech.mcap.exception.MesserApAutomationException;

public interface UserService {

	public boolean validateUserLoginId(String userLoginId) throws MesserApAutomationException;

	public List<UserDto> getAllUsers(Integer userId);

	public void deleteByUserId(Integer userId) throws MesserApAutomationException;

	boolean validateEmailId(String emailId) throws MesserApAutomationException;

	void saveUser(UserDto userDto) throws DataValidationException, MesserApAutomationException;

	public UserDto getUserByUserId(Integer userLoginId);

	public List<UserDto> getUsersByCompanyId(Integer companyId);

	public List<UserDto> getUsersByRole(String roleName);

	public List<UserDto> getUserBydept(Integer deptId) throws MesserApAutomationException;

	public void resetPassword(Integer userId) throws MesserApAutomationException;


}
