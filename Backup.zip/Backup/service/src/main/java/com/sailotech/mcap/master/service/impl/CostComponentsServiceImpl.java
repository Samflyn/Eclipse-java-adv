package com.sailotech.mcap.master.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sailotech.mcap.dto.CostComponentsDto;
import com.sailotech.mcap.entity.CostComponent;
import com.sailotech.mcap.master.repository.CostComponentsRepository;
import com.sailotech.mcap.master.service.CostComponentsService;
import com.sailotech.mcap.util.MesserApAutomationConstants;
import com.sailotech.mcap.util.MesserApAutomationUtil;

@Service
public class CostComponentsServiceImpl implements CostComponentsService{
	
	@Autowired
	private CostComponentsRepository costComponentsRepository;

	@Autowired
	MesserApAutomationUtil messerApAutomationUtil;

	@Override
	public String save(CostComponentsDto costComponentdto) {
		
		CostComponent costComponent = messerApAutomationUtil.copyBeanProperties(costComponentdto, CostComponent.class);
		if (costComponent.getId() != null) {
			costComponent.setUpdate();;
		} else {
			costComponent.setSave();
		}
		CostComponent save = costComponentsRepository.save(costComponent);
		Map<String, String> dataMap = new HashMap<>();
		dataMap.put(MesserApAutomationConstants.MESSAGE, "Cost Company details created successfully");
		dataMap.put(MesserApAutomationConstants.STATUS, MesserApAutomationConstants.SUCCESS_STATUS);
		dataMap.put("costComponentsDto",messerApAutomationUtil.convertPojoToJson(messerApAutomationUtil.copyBeanProperties(save, CostComponentsDto.class)));
		return messerApAutomationUtil.convertPojoToJson(dataMap);
		
	}

	@Override
	public String getAll() {
		
		List<CostComponent> costcomponent = (List<CostComponent>) costComponentsRepository.findAll();
		List<CostComponentsDto> componetDto = new ArrayList<>();
		for (CostComponent costComponet : costcomponent) {
			CostComponentsDto dto = new CostComponentsDto();
			BeanUtils.copyProperties(costComponet, dto);
			componetDto.add(dto);
		}
		return messerApAutomationUtil.convertPojoToJson(componetDto);
	}

	
	@Override
	public String delete(Integer id) {
		 costComponentsRepository.deleteById(id);
		Map<String, String> dataMap = new HashMap<>();
		dataMap.put(MesserApAutomationConstants.MESSAGE, "Cost Component  deleted successfully");
		dataMap.put(MesserApAutomationConstants.STATUS, MesserApAutomationConstants.SUCCESS_STATUS);
		return messerApAutomationUtil.convertPojoToJson(dataMap);
	}
	
	
	
	
	
	

}
