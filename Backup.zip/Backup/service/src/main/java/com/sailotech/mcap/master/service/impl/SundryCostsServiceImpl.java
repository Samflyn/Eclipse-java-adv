package com.sailotech.mcap.master.service.impl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sailotech.mcap.dto.SundryCostsDto;
import com.sailotech.mcap.entity.SundryCosts;
import com.sailotech.mcap.exception.MesserApAutomationException;
import com.sailotech.mcap.master.repository.SundryCostsRepository;
import com.sailotech.mcap.master.service.SundryCostsService;
import com.sailotech.mcap.util.MesserApAutomationConstants;
import com.sailotech.mcap.util.MesserApAutomationUtil;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class SundryCostsServiceImpl implements SundryCostsService {

	@Autowired
	private MesserApAutomationUtil mcapUtil;

	@Autowired
	private SundryCostsRepository sundryCostsRepository;

	private SundryCosts sundryCosts;

		@Override
	public void save(SundryCostsDto sundryCostsDto) throws MesserApAutomationException {
		try {

			sundryCosts = mcapUtil.copyBeanProperties(sundryCostsDto, SundryCosts.class);
			if (sundryCosts.getId() != null)
				sundryCosts.setUpdate();
			else
				sundryCosts.setSave();
			sundryCostsRepository.save(sundryCosts);

		} catch (Exception e) {
			if (e instanceof SQLException) {

				log.info("Failed while creating {}", e.getCause());
				throw new MesserApAutomationException(MesserApAutomationConstants.DATABASE_EXP,
						MesserApAutomationConstants.DATABASE_EXECPTION_MSG);
			} else if (e instanceof IllegalArgumentException) {
				log.info("Failed while convertng data {}", e.getMessage());
				throw new MesserApAutomationException(MesserApAutomationConstants.UNDEFIEND_EXP,
						MesserApAutomationConstants.UNDEFIEND_MSG);
			}

		}
	}

		@Override
		public String getAll() {
			List<SundryCosts> sundryCosts = (List<SundryCosts>) sundryCostsRepository.findAll();
			List<SundryCostsDto> sundryCostsDto = new ArrayList<>();
			for (SundryCosts sundryCost : sundryCosts) {
				SundryCostsDto dto = new SundryCostsDto();
				BeanUtils.copyProperties(sundryCost, dto);
				sundryCostsDto.add(dto);
			}
			return mcapUtil.convertPojoToJson(sundryCostsDto);
		}
		
		@Override
		public String deleteSundryCosts(Integer id) {
			sundryCostsRepository.deleteById(id);
			Map<String, String> dataMap = new HashMap<>();
			dataMap.put(MesserApAutomationConstants.MESSAGE, "Deleted successfully");
			dataMap.put(MesserApAutomationConstants.STATUS, MesserApAutomationConstants.SUCCESS_STATUS);
			return mcapUtil.convertPojoToJson(dataMap);
		}

}
