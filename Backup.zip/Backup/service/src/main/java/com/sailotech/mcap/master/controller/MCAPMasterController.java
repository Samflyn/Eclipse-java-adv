package com.sailotech.mcap.master.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.sailotech.mcap.dto.CostCenterDto;
import com.sailotech.mcap.dto.CostComponentsDto;
import com.sailotech.mcap.dto.CountryMasterDto;
import com.sailotech.mcap.dto.DepartmentDto;
import com.sailotech.mcap.dto.DimensionTypeMasterDto;
import com.sailotech.mcap.dto.DivisionDto;
import com.sailotech.mcap.dto.EmailConfigurationDto;
import com.sailotech.mcap.dto.ErrorMasterDto;
import com.sailotech.mcap.dto.EventResponse;
import com.sailotech.mcap.dto.ItemMappingDto;
import com.sailotech.mcap.dto.ItemMasterDto;
import com.sailotech.mcap.dto.LedgerAccountConfigurationDto;
import com.sailotech.mcap.dto.RoleMasterDto;
import com.sailotech.mcap.dto.StandardActivitiesDto;
import com.sailotech.mcap.dto.StandardElementsDto;
import com.sailotech.mcap.dto.StateMasterDto;
import com.sailotech.mcap.dto.SundryCostsDto;
import com.sailotech.mcap.dto.SupplierMasterDto;
import com.sailotech.mcap.dto.UQCMappingDto;
import com.sailotech.mcap.dto.UQCMasterDto;
import com.sailotech.mcap.dto.UserDto;
import com.sailotech.mcap.dto.WareHouseDto;
import com.sailotech.mcap.entity.Company;
import com.sailotech.mcap.exception.DataValidationException;
import com.sailotech.mcap.exception.MesserApAutomationException;
import com.sailotech.mcap.master.service.CompanyService;
import com.sailotech.mcap.master.service.CostCenterService;
import com.sailotech.mcap.master.service.CostComponentsService;
import com.sailotech.mcap.master.service.CountryMasterService;
import com.sailotech.mcap.master.service.DepartmentService;
import com.sailotech.mcap.master.service.DimensionService;
import com.sailotech.mcap.master.service.DivisionService;
import com.sailotech.mcap.master.service.EmailService;
import com.sailotech.mcap.master.service.ErrorMasterService;
import com.sailotech.mcap.master.service.ItemMappingService;
import com.sailotech.mcap.master.service.ItemMasterService;
import com.sailotech.mcap.master.service.LedgerAccountService;
import com.sailotech.mcap.master.service.RoleMasterService;
import com.sailotech.mcap.master.service.StandardActivitiesService;
import com.sailotech.mcap.master.service.StandardElementsService;
import com.sailotech.mcap.master.service.StateMasterService;
import com.sailotech.mcap.master.service.SundryCostsService;
import com.sailotech.mcap.master.service.SupplierMasterService;
import com.sailotech.mcap.master.service.UqcMappingService;
import com.sailotech.mcap.master.service.UqcMasterService;
import com.sailotech.mcap.master.service.UserService;
import com.sailotech.mcap.master.service.WareHouseService;
import com.sailotech.mcap.service.InvoiceProcessService;
import com.sailotech.mcap.util.MesserApAutomationConstants;
import com.sailotech.mcap.util.MesserApAutomationUtil;

/**
 * @author nagendra.babu
 */

@RestController
public class MCAPMasterController {

	private static final Logger LOGGER = LoggerFactory.getLogger(MCAPMasterController.class);

	@Autowired
	UserService userService;

	@Autowired
	RoleMasterService roleMasterService;

	@Autowired
	CountryMasterService countryMasterService;

	@Autowired
	StateMasterService stateMasterService;

	@Autowired
	ItemMasterService gstItemMasterService;

	@Autowired
	UqcMasterService uqcMasterService;

	@Autowired
	InvoiceProcessService invoiceProcessService;

	@Autowired
	MesserApAutomationUtil messerApAutomationUtil;

	@Autowired
	UqcMappingService uqcMappingService;

	@Autowired
	ItemMappingService itemMappingService;

	@Autowired
	ErrorMasterService errorMasterService;

	@Autowired
	LedgerAccountService ledgerAccountService;

	@Autowired
	DimensionService dimensionService;

	@Autowired
	EmailService emailService;

	@Autowired
	DepartmentService departmentService;

	@Autowired
	CompanyService companyService;

	@Autowired
	CostComponentsService costComponentsService;

	@Autowired
	StandardActivitiesService standardActiviesService;

	@Autowired
	StandardElementsService standardElementsService;

	@Autowired
	SupplierMasterService supplierMasterService;

	@Autowired
	CostCenterService costCenterService;

	@Autowired
	DivisionService divisionService;

	@Autowired
	WareHouseService wareHouseService;

	@Autowired
	SundryCostsService sundryCostsService;

	@PostMapping(value = "/saveItemMaster")
	public Map<String, String> saveItemMaster(@RequestBody ItemMasterDto gstItemMasterDto, HttpServletRequest request,
			HttpSession session) throws DataValidationException {
		LOGGER.info("Entered into InvoiceProcessController saveItemMaster {}", gstItemMasterDto);
		gstItemMasterService.saveItemMaster(gstItemMasterDto);
		Map<String, String> dataMap = new HashMap<>();
		dataMap.put(MesserApAutomationConstants.MESSAGE, "Item saved successfully");
		dataMap.put(MesserApAutomationConstants.STATUS, MesserApAutomationConstants.SUCCESS_STATUS);
		return dataMap;
	}

	@PostMapping("/saveExcelItems")
	@ResponseBody
	public String processItemsExcel(@RequestBody List<ItemMasterDto> itemMasterDto, HttpServletRequest request)
			throws DataValidationException {
		List<ItemMasterDto> listOfItems = itemMasterDto;
		for (ItemMasterDto loi : listOfItems) {
			gstItemMasterService.saveItemMaster(loi);
		}
		Map<String, String> dataMap = new HashMap<>();
		dataMap.put(MesserApAutomationConstants.MESSAGE, "Items uploaded successfully");
		dataMap.put(MesserApAutomationConstants.STATUS, MesserApAutomationConstants.SUCCESS_STATUS);
		return messerApAutomationUtil.convertPojoToJson(dataMap);
	}

	@PostMapping("/saveExcelItemMapping")
	@ResponseBody
	public String saveExcelItemMapping(@RequestBody List<ItemMappingDto> itemMappingDto, HttpServletRequest request)
			throws DataValidationException {
		List<ItemMappingDto> listOfitems = itemMappingDto;
		for (ItemMappingDto loi : listOfitems) {
			itemMappingService.saveItemMapping(loi);
		}
		Map<String, String> dataMap = new HashMap<>();
		dataMap.put(MesserApAutomationConstants.MESSAGE, "Item Mapping saved successfully");
		dataMap.put(MesserApAutomationConstants.STATUS, MesserApAutomationConstants.SUCCESS_STATUS);
		return messerApAutomationUtil.convertPojoToJson(dataMap);
	}

	@PostMapping("/saveUserRoles")
	@ResponseBody
	public String saveUserRoles(@RequestBody RoleMasterDto roleMasterDto, HttpServletRequest request,
			HttpSession session) throws DataValidationException {
		LOGGER.info("Entered into MCAPMasterController saveUserRoles {} ", roleMasterDto);
		roleMasterService.saveUserRoles(roleMasterDto);
		Map<String, String> dataMap = new HashMap<>();
		dataMap.put(MesserApAutomationConstants.MESSAGE, "Roles saved successfully");
		dataMap.put(MesserApAutomationConstants.STATUS, MesserApAutomationConstants.SUCCESS_STATUS);
		return messerApAutomationUtil.convertPojoToJson(dataMap);

	}

	@GetMapping(value = "/getAllUserRoles")
	@ResponseBody
	public String getAllUserRoles() {
		LOGGER.info("Entered into MCAPMasterController getAllUserRoles{} ", "getting Roles");
		return roleMasterService.getAllUserRoles();
	}

	@DeleteMapping(value = "/deleteRole/{roleId}")
	public String deleteUserRole(@PathVariable("roleId") Integer roleId) {
		LOGGER.info("Entered into MCAPMasterController deleteTenant with roleId  {} ", roleId);
		roleMasterService.deleteByRoleId(roleId);
		return messerApAutomationUtil.convertPojoToJson("Role deleted successfully");
	}

	@PostMapping("/saveCountry")
	@ResponseBody
	public String saveCountryDetails(@RequestBody CountryMasterDto countryMasterDto, HttpServletRequest request,
			HttpSession session) throws DataValidationException {
		LOGGER.info("Entered into MCAPMasterController saveCountryDetails {} ", countryMasterDto);
		countryMasterService.saveCountryDetails(countryMasterDto);
		Map<String, String> dataMap = new HashMap<>();
		dataMap.put(MesserApAutomationConstants.MESSAGE, "Country saved successfully");
		dataMap.put(MesserApAutomationConstants.STATUS, MesserApAutomationConstants.SUCCESS_STATUS);
		return messerApAutomationUtil.convertPojoToJson(dataMap);
	}

	@GetMapping(value = "/getAllCountries")
	@ResponseBody
	public String getAllCountries() {
		LOGGER.info("Entered into MCAPMasterController getAllCountries{} ", "getting countries");
		return countryMasterService.getAllCountryDetails();
	}

	@DeleteMapping(value = "/deleteCounty/{countryId}")
	public String deleteCounty(@PathVariable("countryId") Integer countryId) {
		LOGGER.info("Entered into MCAPMasterController deleteTenant with countryId  {} ", countryId);
		countryMasterService.deleteByCountryId(countryId);
		return messerApAutomationUtil.convertPojoToJson("Country deleted successfully");
	}

	@PostMapping(value = "/savestate")
	public String saveState(@RequestBody StateMasterDto stateMasterDto, HttpServletRequest request,
			HttpSession session) {
		LOGGER.info("Entered into MCAPMasterController saveState {} ", stateMasterDto);
		stateMasterService.saveState(stateMasterDto);
		Map<String, String> dataMap = new HashMap<>();
		dataMap.put(MesserApAutomationConstants.MESSAGE, "State saved successfully");
		dataMap.put(MesserApAutomationConstants.STATUS, MesserApAutomationConstants.SUCCESS_STATUS);
		return messerApAutomationUtil.convertPojoToJson(dataMap);
	}

	@GetMapping(value = "/getAllStates")
	@ResponseBody
	public String getAllStates() {
		LOGGER.info("Entered into MCAPMasterController getAllStates ");
		return stateMasterService.getAllStates();
	}

	@DeleteMapping(value = "/deleteState/{stateId}")
	public String deleteState(@PathVariable("stateId") Integer stateId) {
		LOGGER.info("Entered into MCAPMasterController deleteTenant with stateId  {} ", stateId);
		stateMasterService.deleteByStateId(stateId);
		return messerApAutomationUtil.convertPojoToJson("State deleted successfully");
	}

	@GetMapping(value = "/getItemMaster")
	@ResponseBody
	public String getItemMaster() {
		LOGGER.info("Entered into MCAPMasterController getItemMaster ");
		return gstItemMasterService.getItemMaster();
	}

	@DeleteMapping(value = "/deleteItem/{itemId}")
	@ResponseBody
	public String deleteItem(@PathVariable("itemId") Integer itemId) {
		LOGGER.info("Entered into MCAPMasterController deleteItem ");
		String message = gstItemMasterService.deletePartner(itemId);
		return messerApAutomationUtil.convertPojoToJson(message);
	}

	@GetMapping(value = "/getItems")
	public Map<String, Object> getItems(@RequestParam("companyId") Integer companyId, HttpServletRequest request)
			throws MesserApAutomationException {
		LOGGER.info("fetching all Items based on company{} ", companyId);
		return gstItemMasterService.getAllItemsByCompanyId(companyId, request);
	}

	@PostMapping(value = "/saveuqc")
	public String saveuqc(@RequestBody UQCMasterDto uQCMasterDto, HttpServletRequest request, HttpSession session)
			throws DataValidationException {
		LOGGER.info("Entered into MCAPMasterController saveuqc {} ", uQCMasterDto);
		uqcMasterService.saveUqc(uQCMasterDto);
		Map<String, String> dataMap = new HashMap<>();
		dataMap.put(MesserApAutomationConstants.MESSAGE, "UQC saved successfully");
		dataMap.put(MesserApAutomationConstants.STATUS, MesserApAutomationConstants.SUCCESS_STATUS);
		return messerApAutomationUtil.convertPojoToJson(dataMap);
	}

	@GetMapping(value = "/getUqcList")
	public String getUqcListByTenant(@RequestParam("companyId") Integer companyId) {
		LOGGER.info("Entered into MCAPMasterController getUqcList with companyId {} ", companyId);
		return uqcMasterService.getUqcListByCompanyId(companyId);
	}

	@GetMapping(value = "/getSupplierUqcList")
	public String getSupplierUqcList() {
		LOGGER.info("Entered into MCAPMasterController getSupplierUqcList");
		return uqcMasterService.getSupplierUqcList();
	}

	@GetMapping(value = "/getCustomerUqcList")
	public String getCustomerUqcList() {
		LOGGER.info("Entered into MCAPMasterController getCustomerUqcList");
		return uqcMasterService.getCustomerUqcList();
	}

	@DeleteMapping(value = "/deleteUqc/{uqcMasterId}")
	public String deleteUqc(@PathVariable("uqcMasterId") Integer uqcMasterId) {
		LOGGER.info("Entered into MCAPMasterController deleteUqc with uqcMasterId  {} ", uqcMasterId);
		uqcMasterService.deleteUqcById(uqcMasterId);
		return messerApAutomationUtil.convertPojoToJson("Uqc deleted successfully");
	}

	@PostMapping(value = "/saveUqcMapping")
	public String saveUqcMapping(@RequestBody UQCMappingDto uqcMappingDto, HttpServletRequest request,
			HttpSession session) throws DataValidationException {
		LOGGER.info("Entered into MCAPMasterController saveUqcMapping {} ", uqcMappingDto);
		uqcMappingService.saveUqcMapping(uqcMappingDto);
		Map<String, String> dataMap = new HashMap<>();
		dataMap.put(MesserApAutomationConstants.MESSAGE, "UQC Mapping saved successfully");
		dataMap.put(MesserApAutomationConstants.STATUS, MesserApAutomationConstants.SUCCESS_STATUS);
		return messerApAutomationUtil.convertPojoToJson(dataMap);
	}

	@PostMapping("/saveExcelUqc")
	@ResponseBody
	public String processExcelUqc(@RequestBody List<UQCMasterDto> uQCMasterDto, HttpServletRequest request)
			throws DataValidationException {
		List<UQCMasterDto> listOfUqc = uQCMasterDto;
		for (UQCMasterDto lou : listOfUqc) {
			uqcMasterService.saveUqc(lou);
		}
		Map<String, String> dataMap = new HashMap<>();
		dataMap.put(MesserApAutomationConstants.MESSAGE, "UQC uploaded successfully");
		dataMap.put(MesserApAutomationConstants.STATUS, MesserApAutomationConstants.SUCCESS_STATUS);
		return messerApAutomationUtil.convertPojoToJson(dataMap);

	}

	@PostMapping("/saveExcelUqcMapping")
	@ResponseBody
	public String processUqcMappingExcel(@RequestBody List<UQCMappingDto> uQCMappingDto, HttpServletRequest request)
			throws DataValidationException {
		List<UQCMappingDto> listOfuqc = uQCMappingDto;
		for (UQCMappingDto loc : listOfuqc) {
			uqcMappingService.saveUqcMapping(loc);
		}
		Map<String, String> dataMap = new HashMap<>();
		dataMap.put(MesserApAutomationConstants.MESSAGE, "UQC Mappings uploaded successfully");
		dataMap.put(MesserApAutomationConstants.STATUS, MesserApAutomationConstants.SUCCESS_STATUS);
		return messerApAutomationUtil.convertPojoToJson(dataMap);
	}

	@GetMapping(value = "/getUqcMapping")
	@ResponseBody
	public String getUqcMapping(@RequestParam("companyId") Integer companyId) {
		LOGGER.info("Entered into MCAPMasterController getUqcMapping{}", companyId);
		return uqcMappingService.getUqcMapping(companyId);
	}

	@DeleteMapping(value = "/deleteUqcMapping/{uqcMappingId}")
	public String deleteUqcMapping(@PathVariable("uqcMappingId") Integer uqcMappingId) {
		LOGGER.info("Entered into MCAPMasterController deletePemission with deleteUqcMapping {} ", uqcMappingId);
		uqcMappingService.deleteUqcMapping(uqcMappingId);
		return messerApAutomationUtil.convertPojoToJson("UQC Mapping deleted successfully");
	}

	@PostMapping(value = "/saveItemMapping")
	public String saveItemMapping(@RequestBody ItemMappingDto itemMappingDto, HttpServletRequest request,
			HttpSession session) throws DataValidationException {
		LOGGER.info("Entered into MCAPMasterController saveItemMapping {} ", itemMappingDto);
		itemMappingService.saveItemMapping(itemMappingDto);
		Map<String, String> dataMap = new HashMap<>();
		dataMap.put(MesserApAutomationConstants.MESSAGE, "Item Mapping saved successfully");
		dataMap.put(MesserApAutomationConstants.STATUS, MesserApAutomationConstants.SUCCESS_STATUS);
		return messerApAutomationUtil.convertPojoToJson(dataMap);
	}

	@GetMapping(value = "/getItemMapping")
	public Map<String, Object> getItemMappings(@RequestParam("companyId") Integer companyId, HttpServletRequest request)
			throws MesserApAutomationException {
		LOGGER.info("fetching all Items Mappings based on company{} ", companyId);
		return itemMappingService.getAllItemMappingByCompanyId(companyId, request);
	}

	@DeleteMapping(value = "/deleteItemMapping/{itemMappingId}")
	public String deleteItemMapping(@PathVariable("itemMappingId") Integer itemMappingId) {
		LOGGER.info("Entered into MCAPMasterController deletePemission with deleteItemMapping {} ", itemMappingId);
		itemMappingService.deleteItemMapping(itemMappingId);
		return messerApAutomationUtil.convertPojoToJson("Item Mapping deleted successfully");
	}

	@PostMapping(value = "/saveErrorMaster")
	public String saveErrorMaster(@RequestBody ErrorMasterDto errorMasterDto, HttpServletRequest request,
			HttpSession session) {
		LOGGER.info("Entered into MCAPMasterController saveErrorMaster {} ", errorMasterDto);
		errorMasterService.saveItemMapping(errorMasterDto);
		Map<String, String> dataMap = new HashMap<>();
		dataMap.put(MesserApAutomationConstants.MESSAGE, "Error Message  saved successfully");
		dataMap.put(MesserApAutomationConstants.STATUS, MesserApAutomationConstants.SUCCESS_STATUS);
		return messerApAutomationUtil.convertPojoToJson(dataMap);
	}

	@GetMapping(value = "/getErrorMasters")
	@ResponseBody
	public String getErrorMasters() {
		LOGGER.info("Entered into MCAPMasterController getErrorMasters ");
		return errorMasterService.getErrorMasters();
	}

	@DeleteMapping(value = "/deleteErrorMaster/{errorId}")
	public String deleteErrorMaster(@PathVariable("errorId") Integer errorId) {
		LOGGER.info("Entered into MCAPMasterController deletePemission with deleteErrorMaster {} ", errorId);
		errorMasterService.deleteErrorMaster(errorId);
		return messerApAutomationUtil.convertPojoToJson("Item Mapping deleted successfully");
	}

	@GetMapping(value = "/getDimensions")
	public String getDimensions() {
		LOGGER.info("Entered into MCAPMasterController getDimensions ");
		return dimensionService.getAllDimensions();
	}

	@GetMapping(value = "/getLedgerAccount")
	public String getLedgerAccount(@RequestParam("companyId") Integer companyId) {
		LOGGER.info("Entered into MCAPMasterController getLedgerAccount by company {} ", companyId);
		return ledgerAccountService.getLedgerAccountByCompanyId(companyId);
	}

	@PostMapping(value = "/saveMailConfigs")
	public String saveMailConfigs(@RequestBody EmailConfigurationDto mailConfigurationsMasterDto,
			HttpServletRequest request) {
		LOGGER.info("Entered into EmailServiceController {} ", mailConfigurationsMasterDto);
		return emailService.saveMailConfigs(mailConfigurationsMasterDto);
	}

	@GetMapping(value = "/getAllEmailConfigs")
	public String getAllEmailConfigs() {
		LOGGER.info("Entered into EmailServiceController getAllEmailConfigs ");
		return emailService.getAllEmailConfigs();
	}

	@DeleteMapping(value = "/deleteEmailConfig/{mailConfigId}")
	public String deleteEmailConfigMapping(@PathVariable("mailConfigId") Integer mailConfigId) {
		LOGGER.info("Entered into EmailServiceController deletePemission with deleteEmailConfigMapping {} ",
				mailConfigId);
		emailService.deleteUqcMapping(mailConfigId);
		return messerApAutomationUtil.convertPojoToJson("Email Config deleted successfully");
	}

	@PostMapping(value = "/department/create")
	public String saveDepartment(@RequestBody DepartmentDto departmentDto, HttpServletRequest request) {
		LOGGER.info("Entered into DepartmentController {} ", departmentDto);
		return departmentService.saveDepartment(departmentDto);
	}

	@GetMapping(value = "/getAllDepartments")
	public List<DepartmentDto> getAllDepartments() {
		LOGGER.info("Entered into DepartmentServiceController getAllDepartments ");
		return departmentService.getAllDepartments();
	}

	@DeleteMapping("/deleteDepartment/{deptId}")
	public String deleteDepartment(@PathVariable("deptId") Integer deptId) {
		LOGGER.info("Entered into DepartmentServiceController deleteDepartment ");
		return departmentService.deleteDepartment(deptId);
	}

	@PostMapping(value = "/dimensionType/create")
	public String savedimensionType(@RequestBody DimensionTypeMasterDto dimensionTypeMasterDto,
			HttpServletRequest request) {
		LOGGER.info("Entered into DimensionTypeController {} ", dimensionTypeMasterDto);
		return dimensionService.saveDimension(dimensionTypeMasterDto);
	}

	@GetMapping(value = "/getAllDimensions")
	public String getAllDimensions() {
		LOGGER.info("Entered into DimensionServiceController getAllDimensions ");
		return dimensionService.getAllDimensions();
	}

	@DeleteMapping("/deleteDimension/{dimensionType}")
	public String deleteDimension(@PathVariable("dimensionType") Integer dimensionType) {
		LOGGER.info("Entered into DepartmentServiceController deleteDepartment ");
		return dimensionService.deleteDimension(dimensionType);
	}

	@PostMapping(value = "/ledgerAccount/create")
	public String saveLedgerAccount(@RequestBody LedgerAccountConfigurationDto LedgerAccountConfigurationDto,
			HttpServletRequest request) {
		LOGGER.info("Entered into LedgerAccountController {} ", LedgerAccountConfigurationDto);
		return ledgerAccountService.saveLedgerAccount(LedgerAccountConfigurationDto);
	}

	@DeleteMapping(value = "/deleteLedgerAccountMapping/{ledgerAccountDto}")
	public String deleteLedgerAccountMapping(@PathVariable("ledgerAccountDto") String ledgerAccountDto,
			HttpServletRequest request) {
		LOGGER.info("Entered into LedgerAccountMappingController {} ", ledgerAccountDto);
		return ledgerAccountService.deleteLedgerAccountMapping(ledgerAccountDto);
	}

	@GetMapping(value = "/getAllLedgerAccounts")
	public String getAllLedgerAccounts() throws MesserApAutomationException {
		LOGGER.info("Entered into LedgerAccountServiceController getAllLedgerAccounts ");
		return ledgerAccountService.getAllLedgerAccounts();
	}

	@DeleteMapping("/deleteLedgerAccount/{ledgerAccount}")
	public String deleteLedgerAccount(@PathVariable("ledgerAccount") String ledgerAccount) {
		LOGGER.info("Entered into LedgerAccountServiceController deleteLedgerAccount ");
		return ledgerAccountService.deleteLedgerAccount(ledgerAccount);
	}

	@GetMapping(value = "/getAllCompanies")
	@ResponseBody
	public List<Company> getAllCompanies() {
		LOGGER.info("Entered into MCAPMasterController getAllCompanies{} ", "getting companies");
		return companyService.getAllCompanyDetails();
	}

	/* Save cost Component */
	@PostMapping(value = "/saveCostComponent")
	public String saveCostComponent(@RequestBody CostComponentsDto costComponentsDto) throws DataValidationException {
		LOGGER.info("Entered into costComponents Controller saveCostComponent {}", costComponentsDto);
		return costComponentsService.save(costComponentsDto);
	}

	/* get All Cost Components */
	@GetMapping(value = "/getAllCostComponent")
	public String getAllCostComponents() {
		LOGGER.info("Entered intocostComponents Controller getAllCostComponent ");
		return costComponentsService.getAll();
	}

	/* Delete cost component by id */
	@DeleteMapping("/deleteCostComponent/{id}")
	public String deleteCostComponents(@PathVariable("id") Integer id) {
		LOGGER.info("Entered into costComponents Controller deleteCostComponent ");
		return costComponentsService.delete(id);
	}

	/* Save StandardActivities */
	@PostMapping(value = "/saveStandardActiviti")
	public String saveStandardActivities(@RequestBody StandardActivitiesDto standardActivitiesDto)
			throws DataValidationException {
		LOGGER.info("Entered into standardActivities Controller saveStandardActiviti {}", standardActivitiesDto);
		return standardActiviesService.save(standardActivitiesDto);
	}

	/* get All standardActivities */
	@GetMapping(value = "/getAllStandardActivities")
	public String getAllStandardActivi() {
		LOGGER.info("Entered standardActivities Controller getAllStandardActivities ");
		return standardActiviesService.getAll();
	}

	/* Delete standardActivities by id */
	@DeleteMapping("/deleteStandardActivities/{id}")
	public String deleteStandardActivi(@PathVariable("id") Integer id) {
		LOGGER.info("Entered into costComponents Controller standardActivities ");
		return standardActiviesService.delete(id);
	}

	/* Save StandardElements */
	@PostMapping(value = "/saveStandardElements")
	public String saveStandardElements(@RequestBody StandardElementsDto standardElementsDto)
			throws DataValidationException {
		LOGGER.info("Entered into StandardElements Controller saveStandardElements {}", standardElementsDto);
		return standardElementsService.save(standardElementsDto);
	}

	/* get All StandardElements */
	@GetMapping(value = "/getAllStandardElements")
	public String getAllStandardElements() {
		LOGGER.info("Entered StandardElements Controller getAllStandardElements ");
		return standardElementsService.getAll();
	}

	/* Delete StandardElements by id */
	@DeleteMapping("/deleteStandardElements/{id}")
	public String deleteStandardElements(@PathVariable("id") Integer id) {
		LOGGER.info("Entered into StandardElement Controller delete supplier");
		return standardElementsService.delete(id);
	}

	@GetMapping(value = "/getAllSuppliers")
	public String getAllSuppliers() {
		LOGGER.info("Entered Suppplier Controller getAllSupplier ");
		return supplierMasterService.getAllSuppliers();
	}

	// saveSupplier
	@PostMapping(value = "/saveSupplier")
	public String saveSupplier(@RequestBody SupplierMasterDto supplierMasterDto) throws DataValidationException {
		LOGGER.info("Entered into Suppplier Controller saveSupplier {}", supplierMasterDto);
		return supplierMasterService.save(supplierMasterDto);
	}

	/* Delete Suppliers */
	@DeleteMapping("/deleteSupplier/{id}")
	public String deleteSuppliers(@PathVariable("id") Integer id) {
		LOGGER.info("Entered into Suppplier Controller delete supplier");
		return supplierMasterService.deleteBySupplierId(id);
	}

	@PostMapping(value = "/createCostCenter")
	public EventResponse createCostCenter(@RequestBody CostCenterDto costCenter) throws MesserApAutomationException {
		LOGGER.info("create costCenter{}");
		String message = "";

		costCenterService.save(costCenter);
		if (costCenter.getId() != null) {
			message = costCenter.getName() + " Updated successfully";
		} else {
			message = costCenter.getName() + " Ceated successfully";
		}
		return messerApAutomationUtil.prepareSuccessResponse(MesserApAutomationConstants.SUCCESS_CD, message);
	}

	@PostMapping(value = "/createdivision")
	public EventResponse createDivision(@RequestBody DivisionDto divisionDto) throws MesserApAutomationException {
		LOGGER.info("create division{} ", divisionDto);
		String message = "";

		divisionService.save(divisionDto);
		if (divisionDto.getId() != null) {
			message = divisionDto.getName() + " Updated successfully";
		} else {
			message = divisionDto.getName() + " Ceated successfully";
		}
		return messerApAutomationUtil.prepareSuccessResponse(MesserApAutomationConstants.SUCCESS_CD, message);
	}

	@PostMapping(value = "/createWareHouse")
	public EventResponse createWareHouse(@RequestBody WareHouseDto wareHouseDto) throws MesserApAutomationException {
		LOGGER.info("create wareHouse{} ");
		String message = "";

		wareHouseService.save(wareHouseDto);
		if (wareHouseDto.getId() != null) {
			message = wareHouseDto.getName() + " Updated successfully";
		} else {
			message = wareHouseDto.getName() + " Ceated successfully";
		}
		return messerApAutomationUtil.prepareSuccessResponse(MesserApAutomationConstants.SUCCESS_CD, message);
	}

	@PostMapping(value = "/createSundryCost")
	public EventResponse createSundryCosts(@RequestBody SundryCostsDto sundryCostsDto)
			throws MesserApAutomationException {
		LOGGER.info("create createSundryCosts{} ");
		String message = "";

		sundryCostsService.save(sundryCostsDto);
		if (sundryCostsDto.getId() != null) {
			message = sundryCostsDto.getSundryCosts() + " Updated successfully";
		} else {
			message = sundryCostsDto.getSundryCosts() + " Ceated successfully";
		}
		return messerApAutomationUtil.prepareSuccessResponse(MesserApAutomationConstants.SUCCESS_CD, message);
	}

	@GetMapping(value = "/getSundryCosts")
	public String getSundryCosts() {
		LOGGER.info("Entered SundryCosts Controller,{}");
		return sundryCostsService.getAll();
	}

	@DeleteMapping("/deletesundrycost/{id}")
	public String deleteSundryCost(@PathVariable("id") Integer id) {
		LOGGER.info("Entered into SundryCosts Controller delete sundryCost");
		return sundryCostsService.deleteSundryCosts(id);
	}

	@GetMapping(value = "/getAllCostCenters")
	public List<CostCenterDto> getAllCostCenters() {
		LOGGER.info("Entered cost center Controller get cost centers,{}");
		return costCenterService.getAllCostCenterDetails();
	}

	@GetMapping(value = "/getAllWareHouse")
	public List<WareHouseDto> getAllWareHouse() {
		LOGGER.info("Entered ware house Controller get wareHouse,{}");
		return wareHouseService.getAllWareHouse();
	}

	@GetMapping(value = "/getDivisions")
	public List<DivisionDto> getDivisions() {
		LOGGER.info("Entered division Controller get divisions,{}");
		return divisionService.getAllDivisions();
	}

	/* Delete CostCenter */
	@DeleteMapping("/deleteCostCenter/{id}")
	public String deleteCostCenter(@PathVariable("id") Integer id) {
		LOGGER.info("Entered into CostCenter Controller delete CostCenter");
		return costCenterService.deleteCostCenter(id);
	}

	/* Delete Suppliers */
	@DeleteMapping("/deleteDivisions/{id}")
	public String deleteDivisions(@PathVariable("id") Integer id) {
		LOGGER.info("Entered into Divisions Controller divisions");
		return divisionService.deleteByDivisionId(id);
	}

	/* Delete Suppliers */
	@DeleteMapping("/deleteWareHouse/{id}")
	public String deleteWareHouse(@PathVariable("id") Integer id) {
		LOGGER.info("Entered into WareHouse Controller delete wareHouse");
		return wareHouseService.deleteByWareHouseId(id);
	}

	@GetMapping(value = "/getCostDimensionsMaster")
	public Map<String, Object> getCostAccountDimensionsMaster() {
		LOGGER.info("Entered into LedgerAccountServiceController getAllLedgerAccounts ");
		List<DivisionDto> divisions = divisionService.getAllDivisions();
		List<DepartmentDto> departments = departmentService.getAllDepartments();
		List<UserDto> usersByRole = userService.getUsersByRole("PORTAL_USER");
		List<CostCenterDto> costCenterDetails = costCenterService.getAllCostCenterDetails();
		List<WareHouseDto> wareHouses = wareHouseService.getAllWareHouse();
		Map<String, Object> dataMap = new HashMap<>();
		dataMap.put("divisions", divisions);
		dataMap.put("departments", departments);
		dataMap.put("employees", usersByRole);
		dataMap.put("costCenters", costCenterDetails);
		dataMap.put("wareHouses", wareHouses);
		return dataMap;
	}

	@GetMapping(value = "/getUserInfo")
	@ResponseBody
	public UserDto getUserInfo(@RequestParam Integer userId) {
		LOGGER.info("Entered into MCapMasterController getUserInfo  {} ", "getting userInfo");

		return userService.getUserByUserId(userId);
	}

}
