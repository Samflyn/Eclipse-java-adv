package com.sailotech.mcap.master.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.sailotech.mcap.entity.SupplierMaster;

@Repository
public interface SupplierMasterRepository extends CrudRepository<SupplierMaster, Integer> {

	SupplierMaster findBySupplierName(String supplierName);

}
