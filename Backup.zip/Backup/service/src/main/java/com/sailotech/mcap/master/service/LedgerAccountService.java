package com.sailotech.mcap.master.service;

import org.springframework.stereotype.Service;

import com.sailotech.mcap.dto.LedgerAccountConfigurationDto;
import com.sailotech.mcap.exception.MesserApAutomationException;

@Service
public interface LedgerAccountService {

	String getLedgerAccountByCompanyId(Integer companyId);

	String getAllLedgerAccounts() throws MesserApAutomationException;

	String saveLedgerAccount(LedgerAccountConfigurationDto ledgerAccountConfigurationDto);

	String deleteLedgerAccount(String ledgerAccount);

	String deleteLedgerAccountMapping(String ledgerAccountConfigurationDto);

}
