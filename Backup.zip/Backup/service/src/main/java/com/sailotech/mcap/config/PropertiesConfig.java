/**
 * 
 */
package com.sailotech.mcap.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import lombok.Data;

/**
 * @author dhanunjaya.potteti
 *
 */
@Configuration
@PropertySource("classpath:application.properties")
@Data
public class PropertiesConfig {
	@Value("${ln.service}")
	private String lnService;
	@Value("${ln.service.podetails}")
	private String poDetailsUrl;
	
	@Value("${mobilor.user.name}")
	private String lnUserName;
	@Value("${mobilor.user.pwd}")
	private String lnUserPwd;
	@Value("${ln.service.company}")
	private String company;
	@Value("${ln.service.create.pinvoice}")
	private String createPInvocie;
	
}
