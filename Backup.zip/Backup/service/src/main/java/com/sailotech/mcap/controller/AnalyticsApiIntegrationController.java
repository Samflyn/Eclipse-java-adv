package com.sailotech.mcap.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sailotech.mcap.dto.EventResponse;
import com.sailotech.mcap.dto.FailedInvoicesDto;
import com.sailotech.mcap.dto.InvoiceHeaderDto;
import com.sailotech.mcap.entity.FailedInvoices;
import com.sailotech.mcap.exception.MesserApAutomationException;
import com.sailotech.mcap.repository.FailedInvoiceRepository;
import com.sailotech.mcap.service.InvoiceProcessService;
import com.sailotech.mcap.util.MesserApAutomationConstants;
import com.sailotech.mcap.util.MesserApAutomationUtil;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/api/ocr")
@Slf4j
public class AnalyticsApiIntegrationController {

	@Autowired
	InvoiceProcessService invoiceProcessService;

	@Autowired
	FailedInvoiceRepository failedInvoiceRepository;

	@Autowired
	MesserApAutomationUtil mcApUtil;

	@PostMapping(value = "/create-invoice", consumes = MediaType.APPLICATION_JSON_VALUE)
	public EventResponse createInvoice(@RequestBody Map<String, List<InvoiceHeaderDto>> dataMap)
			throws MesserApAutomationException {
		log.info("Entered into AnalyticsApiIntegrationController createInvoice");
		if (!dataMap.containsKey("data")) {
			return mcApUtil.prepareErrorResponse(MesserApAutomationConstants.ERROR_CD, "Invoice details are not found");
		}
		List<InvoiceHeaderDto> invoiceHeaderDtoList = dataMap.get("data");
		log.info("Invoice Payload {} ", mcApUtil.convertPojoToJson(invoiceHeaderDtoList));
		if (invoiceHeaderDtoList == null) {
			return mcApUtil.prepareErrorResponse(MesserApAutomationConstants.ERROR_CD, "Invoice details are not found");
		}
		invoiceProcessService.saveBulkInvoice(invoiceHeaderDtoList);
		return mcApUtil.prepareSuccessResponse(MesserApAutomationConstants.SUCCESS_CD, "Invoice created successfully");
	}

	@PostMapping(value = "/log-failed-invoice", consumes = MediaType.APPLICATION_JSON_VALUE)
	public EventResponse logFailedInvoice(@RequestBody Map<String, FailedInvoicesDto> dataMap)
			throws MesserApAutomationException {
		log.info("Entered into AnalyticsApiIntegrationController createInvoice");
		if (!dataMap.containsKey("data")) {
			return mcApUtil.prepareErrorResponse(MesserApAutomationConstants.ERROR_CD, "No data found");
		}
		FailedInvoicesDto failedInvoicesDto = dataMap.get("data");
		FailedInvoices failedInvoices = new FailedInvoices();
		BeanUtils.copyProperties(failedInvoicesDto, failedInvoices);
		failedInvoiceRepository.save(failedInvoices);
		return mcApUtil.prepareSuccessResponse(MesserApAutomationConstants.SUCCESS_CD,
				"Failed Invoice log created successfully");

	}

}
