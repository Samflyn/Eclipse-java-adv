package com.sailotech.mcap.master.service;

import org.springframework.stereotype.Service;

import com.sailotech.mcap.dto.SupplierMasterDto;

@Service
public interface SupplierMasterService {
	

	public String getAllSuppliers();

	public String deleteBySupplierId(Integer stateId);

	public String save(SupplierMasterDto supplierMasterDto);

}
