package com.sailotech.mcap.master.service.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sailotech.mcap.dto.DimensionTypeMasterDto;
import com.sailotech.mcap.entity.DimensionTypeMaster;
import com.sailotech.mcap.master.repository.DimensionTypeMasterRepository;
import com.sailotech.mcap.master.repository.LedgerAccountDimensionMasterRepository;
import com.sailotech.mcap.master.service.DimensionService;
import com.sailotech.mcap.util.MesserApAutomationConstants;
import com.sailotech.mcap.util.MesserApAutomationUtil;

@Service
public class DimensionServiceImpl implements DimensionService {

	@Autowired
	LedgerAccountDimensionMasterRepository ledgerAccountDimensionMasterRepository;

	@Autowired
	DimensionTypeMasterRepository dimensionTypeMasterRepository;

	@Autowired
	MesserApAutomationUtil messerApAutomationUtil;

	@Override
	public String saveDimension(DimensionTypeMasterDto dimensionTypeMasterDto) {
		Integer loggedInUser = messerApAutomationUtil.getUserId();
		DimensionTypeMaster dimensionTypeMaster = new DimensionTypeMaster();
		BeanUtils.copyProperties(dimensionTypeMasterDto, dimensionTypeMaster);
		if (dimensionTypeMasterRepository.findById(dimensionTypeMaster.getDimensionType()).isPresent()) {
			dimensionTypeMaster.setLastUpdatedBy(loggedInUser);
			dimensionTypeMaster.setLastUpdatedOn(Calendar.getInstance().getTime());
		} else {
			dimensionTypeMaster.setCreatedBy(loggedInUser);
			dimensionTypeMaster.setCreatedOn(Calendar.getInstance().getTime());
		}
		dimensionTypeMasterRepository.save(dimensionTypeMaster);
		return messerApAutomationUtil.convertPojoToJson("Dimension Type saved successfully");
	}

	@Override
	public String getAllDimensions() {
		List<DimensionTypeMaster> dimensionConfigurations = (List<DimensionTypeMaster>) dimensionTypeMasterRepository
				.findAll();
		List<DimensionTypeMasterDto> dimensionDtos = new ArrayList<>();
		for (DimensionTypeMaster dimension : dimensionConfigurations) {
			DimensionTypeMasterDto dto = new DimensionTypeMasterDto();
			BeanUtils.copyProperties(dimension, dto);
			dimensionDtos.add(dto);
		}
		return messerApAutomationUtil.convertPojoToJson(dimensionDtos);
	}

	@Override
	public String deleteDimension(Integer dimensionType) {
		dimensionTypeMasterRepository.deleteById(dimensionType);
		Map<String, String> dataMap = new HashMap<>();
		dataMap.put(MesserApAutomationConstants.MESSAGE, "Dimension Type deleted successfully");
		dataMap.put(MesserApAutomationConstants.STATUS, MesserApAutomationConstants.SUCCESS_STATUS);
		return messerApAutomationUtil.convertPojoToJson(dataMap);
	}
}
