package com.sailotech.mcap.master.service;

import com.sailotech.mcap.dto.StandardElementsDto;

public interface StandardElementsService {
	
	public String save(StandardElementsDto standardElementsDto);

	public String getAll();
	
	public String delete(Integer id);

}
