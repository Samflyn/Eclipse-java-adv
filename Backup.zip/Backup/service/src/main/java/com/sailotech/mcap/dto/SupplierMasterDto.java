package com.sailotech.mcap.dto;

import java.io.Serializable;

import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Getter;
import lombok.Setter;

@Component
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
@JsonIgnoreProperties(ignoreUnknown = true)
@Getter
@Setter
public class SupplierMasterDto extends BaseDto implements Serializable{

	
	private static final long serialVersionUID = -6607175062272794010L;
	
	private Integer supplierId	;
	private String supplierName	;
	private String supplierRegisteredId	;
	private String supplierAddress	;
	private Integer supplierPincode	;
	private String landline	;
	private String fax	;
	private Integer supplierStateId;	
	private String supplierPhoneNo	;
	private String supplierEmailId	;
	
	private CompanyDto companyDto;
	private CountryMasterDto countryMasterDto;
	private String supplierCode	;
	private String contactPerson	;
	private String supplierPhoneNo1	;
	private String supplierEmailId1;	
	private String ibanNo	;
	private String supplierAccountNo	;
	private String status	;
	private String rootDirectory;
	private String transactionType;
	

}
