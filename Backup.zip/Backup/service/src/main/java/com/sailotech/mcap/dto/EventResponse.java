/**
 * 
 */
package com.sailotech.mcap.dto;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author dhanunjaya.potteti
 *
 */
@Component
@Data
@EqualsAndHashCode(callSuper = false)
@JsonInclude(Include.NON_NULL)
@JsonPropertyOrder({ "status", "statusCode", "message","data" })
public class EventResponse {
	
	private boolean status;
	private String statusCode;
	private String message;
	private Object data;
	
	

}
