package com.sailotech.mcap.service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;

import com.sailotech.mcap.dto.EventResponse;
import com.sailotech.mcap.dto.InvoiceHeaderDto;
import com.sailotech.mcap.exception.DataValidationException;
import com.sailotech.mcap.exception.MesserApAutomationException;

public interface InvoiceProcessService {

	public InvoiceHeaderDto saveInvoice(InvoiceHeaderDto invoiceHeaderDto);

	EventResponse invoiceRegistration(Integer headerId, Integer workFlowStatus) throws MesserApAutomationException;

	public void updateWorkFlowStatus(Integer headerId, Integer workFlowStatus) throws MesserApAutomationException;

	public Map<String, Object> getInvoicesByTxnAndStatus(Integer companyId, String transactionType,
			Integer workflowStatus, HttpServletRequest request) throws MesserApAutomationException;

	public InvoiceHeaderDto getInvoice(Integer headerId) throws MesserApAutomationException;

	public EventResponse compareInvoice(Integer headerId, Integer value);

	public void deleteByHeaderId(Integer headerId);

	List<InvoiceHeaderDto> getInvoiceReports(String fromDate, String toDate, String transactionType, String invoiceNo,
			Integer workFlowStatus, String poNumber,HttpServletRequest request) throws MesserApAutomationException;

	String getCustomerInvoiceReport(String fromDate, String toDate, String transactionType, String invNo,
			Integer status);

	void saveBulkInvoice(List<InvoiceHeaderDto> invoiceHeaderDtoList);

	public ModelAndView exportCustomerInvoiceReport(String fromDate, String toDate, HttpServletRequest request,
			HttpServletResponse response, String transactionType, String invNo, Integer status) throws DataValidationException;

	

	
	
}
