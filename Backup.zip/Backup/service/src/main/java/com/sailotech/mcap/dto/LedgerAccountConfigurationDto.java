package com.sailotech.mcap.dto;

import java.io.Serializable;
import java.util.List;

import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.sailotech.mcap.entity.LedgerAccountDimensionMaster;

import lombok.Getter;
import lombok.Setter;

@Component
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
@JsonIgnoreProperties(ignoreUnknown = true)
@Getter
@Setter
public class LedgerAccountConfigurationDto implements Serializable {

	private static final long serialVersionUID = 743539683299075152L;

	private String ledgerAccount;

	private Integer companyId;

	private String ledgerAccountDesc;

	private String accountType;

	private List<LedgerAccountDimensionMaster> ledgerDimensions;

}
