package com.sailotech.mcap.master.service.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.sailotech.mcap.dto.ItemMappingDto;
import com.sailotech.mcap.dto.ItemMasterDto;
import com.sailotech.mcap.entity.ItemMapping;
import com.sailotech.mcap.entity.ItemMaster;
import com.sailotech.mcap.exception.DataValidationException;
import com.sailotech.mcap.master.repository.ItemMappingRepository;
import com.sailotech.mcap.master.service.ItemMappingService;
import com.sailotech.mcap.util.AngularDataTableParamModel;
import com.sailotech.mcap.util.AngularDataTablesParamUtility;
import com.sailotech.mcap.util.MesserApAutomationUtil;
import com.sailotech.mcap.util.ProcessedDatatableSearchSpecification;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ItemMappingServiceImpl implements ItemMappingService {

	@Autowired
	ItemMappingRepository itemMappingRepository;

	@Autowired
	MesserApAutomationUtil messerApAutomationUtil;

	@Autowired
	private AngularDataTablesParamUtility angularDataTablesParamUtility;

	@Autowired
	private ProcessedDatatableSearchSpecification processedDatatableSearchSpecification;

	@Override
	public Integer saveItemMapping(ItemMappingDto itemMappingDto) throws DataValidationException {
		Integer loggedInUser = messerApAutomationUtil.getUserId();
		if (itemMappingDto.getItemMappingId() != null) {
			checkUniqueItemMasterOnUpdate(itemMappingDto);
			itemMappingDto.setLastUpdatedBy(loggedInUser);
			itemMappingDto.setLastUpdatedOn(Calendar.getInstance().getTime());
		} else {
			checkUniqueItemMaster(itemMappingDto);
			itemMappingDto.setCreatedBy(loggedInUser);
			itemMappingDto.setCreatedOn(Calendar.getInstance().getTime());
		}
		itemMappingDto.setCompanyId(messerApAutomationUtil.getLoggedInUserCompanyId());

		ItemMapping itemMapping = itemMappingRepository
				.save(messerApAutomationUtil.convertItemMappingDtoToDao(itemMappingDto));
		return itemMapping.getItemMappingId();
	}

	@Override
	public String getItemMapping(Integer tenantId) {
		List<ItemMapping> itemMappingDao = itemMappingRepository.findByCompanyId(tenantId);
		List<ItemMappingDto> itemMappingDtos = new ArrayList<>();
		for (ItemMapping itemMapping : itemMappingDao) {
			ItemMappingDto itemMappingDto = messerApAutomationUtil.convertItemMappingDaoToDto(itemMapping);
			itemMappingDtos.add(itemMappingDto);
		}
		return messerApAutomationUtil.convertPojoToJson(itemMappingDtos);
	}

	private void checkUniqueItemMaster(ItemMappingDto itemMappingDto) throws DataValidationException {
		boolean findByItemMasterExists = itemMappingRepository
				.findByItemMasterExists(itemMappingDto.getItemMasterDto().getItemId());
		if (findByItemMasterExists) {
			throw new DataValidationException("SVMP_DATA_VALIDATION_ERROR",
					"Selected Customer Item Name already mapped");
		}
	}

	private void checkUniqueItemMasterOnUpdate(ItemMappingDto itemMappingDto) throws DataValidationException {
		boolean findByItemMasterExists = itemMappingRepository
				.findByItemMasterExistsOnUpdate(itemMappingDto.getItemMasterDto().getItemId());
		if (findByItemMasterExists) {
			throw new DataValidationException("SVMP_DATA_VALIDATION_ERROR",
					"Selected Customer Item Name already mapped");
		}
	}

	@Override
	public void deleteItemMapping(Integer itemMappingId) {
		itemMappingRepository.deleteById(itemMappingId);
	}

	@Override
	public Map<String, Object> getAllItemMappingByCompanyId(Integer companyId, HttpServletRequest request) {
		Map<String, Object> mapOfHeaders = new HashMap<>();
		AngularDataTableParamModel param = angularDataTablesParamUtility.getParam(request);
		Long totalCount = null;
		List<ItemMapping> itemMappings = new ArrayList<>();
		itemMappings = getItemsBySpecification(companyId, param);
		totalCount = itemMappingRepository.countByCompanyId(companyId);
		List<ItemMappingDto> itemMappingDtos = new ArrayList<ItemMappingDto>();
		for (ItemMapping itemMapping : itemMappings) {
			ItemMappingDto itemMappingDto = messerApAutomationUtil.copyBeanProperties(itemMapping,
					ItemMappingDto.class);
			itemMappingDto.setItemMasterDto(
					messerApAutomationUtil.copyBeanProperties(itemMapping.getItemMaster(), ItemMasterDto.class));
			itemMappingDtos.add(itemMappingDto);
		}
		mapOfHeaders.put("recordsTotal", totalCount);
		if (param.getsSearch() != null && !param.getsSearch().isEmpty()) {
			mapOfHeaders.put("recordsFiltered", itemMappingDtos.size());
		} else {
			mapOfHeaders.put("recordsFiltered", totalCount);
		}
		mapOfHeaders.put("data", itemMappingDtos);
		return mapOfHeaders;
	}

	private List<ItemMapping> getItemsBySpecification(Integer companyId, AngularDataTableParamModel param) {
		List<ItemMapping> itemMappings = new ArrayList<>();
		if (param.getiDisplayLength() == -1) {
			param.setiDisplayLength(Integer.MAX_VALUE);
		}
		int page = param.getiDisplayStart() / param.getiDisplayLength();
		try {

			return itemMappingRepository.findAll(
					processedDatatableSearchSpecification.getItemMappingSpecification(companyId, param.getsSearch()),
					PageRequest.of(page, param.getiDisplayLength())).getContent();

		} catch (Exception e) {
			e.printStackTrace();
			log.info("In Exception getAllItems by Specification ", e.getMessage());
		}
		return null;
	}

}
