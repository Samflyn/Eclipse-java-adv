package com.sailotech.mcap.master.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sailotech.mcap.dto.DepartmentDto;
import com.sailotech.mcap.entity.Department;
import com.sailotech.mcap.master.repository.DepartmentConfigRepository;
import com.sailotech.mcap.master.service.DepartmentService;
import com.sailotech.mcap.util.MesserApAutomationConstants;
import com.sailotech.mcap.util.MesserApAutomationUtil;

@Service
public class DepartmentServiceImpl implements DepartmentService {

	@Autowired
	MesserApAutomationUtil messerApAutomationUtil;

	@Autowired
	DepartmentConfigRepository deptConfigRepo;

	@Override
	public String saveDepartment(DepartmentDto departmentDto) {
		Department department = new Department();
		BeanUtils.copyProperties(departmentDto, department);
		if (department.getDeptId() != null) {
			department.setUpdate();
		} else {
			department.setSave();
		}
		deptConfigRepo.save(department);
		return messerApAutomationUtil.convertPojoToJson("Department saved successfully");
	}

	@Override
	public List<DepartmentDto> getAllDepartments() {
		List<Department> departmentConfigurations = (List<Department>) deptConfigRepo.findAll();
		List<DepartmentDto> deptDtos = new ArrayList<>();
		for (Department department : departmentConfigurations) {
			DepartmentDto dto = new DepartmentDto();
			BeanUtils.copyProperties(department, dto);
			deptDtos.add(dto);
		}
		return deptDtos;
	}

	@Override
	public String deleteDepartment(Integer deptId) {
		deptConfigRepo.deleteById(deptId);
		Map<String, String> dataMap = new HashMap<>();
		dataMap.put(MesserApAutomationConstants.MESSAGE, "Department deleted successfully");
		dataMap.put(MesserApAutomationConstants.STATUS, MesserApAutomationConstants.SUCCESS_STATUS);
		return messerApAutomationUtil.convertPojoToJson(dataMap);
	}

}
