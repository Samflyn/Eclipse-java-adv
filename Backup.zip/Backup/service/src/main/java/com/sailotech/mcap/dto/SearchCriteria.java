package com.sailotech.mcap.dto;



import java.io.Serializable;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class SearchCriteria implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3581140246439777950L;

	private String key;
    private Object value;
    private SearchOperation operation;
    
	public SearchCriteria(String key, Object value, SearchOperation operation) {
		super();
		this.key = key;
		this.value = value;
		this.operation = operation;
	}
    
    
}
