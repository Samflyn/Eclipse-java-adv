package com.sailotech.mcap.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "supplier_master")
@Component
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
@Getter
@Setter
@EqualsAndHashCode(of = "supplierId", callSuper = false)
public class SupplierMaster extends BaseDao implements Serializable{


	private static final long serialVersionUID = -8659846419852745580L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "supplier_id", unique = true, nullable = false)
	private Integer supplierId	;
	
	@Column(name = "supplier_Name")
	private String supplierName	;
	
	@Column(name = "supplier_registered_id")
	private String supplierRegisteredId	;
	
	@Column(name = "supplier_address")
	private String supplierAddress	;
	
	@Column(name = "supplier_pincode")
	private Integer supplierPincode	;
	
	@Column(name = "landline")
	private String landline	;
	
	@Column(name = "fax")
	private String fax;
	
	@Column(name = "supplier_state_id")
	private Integer supplierStateId;
	
	/*@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name = "company_id")
	private Company company;*/

	@ManyToOne(optional = false)
	@JoinColumn(name = "company_id", nullable = false)
	private Company company;

	@OneToOne
	@JoinColumn(name = "supplier_country_id", nullable = true)
	private CountryMaster countryMaster;

	
	@Column(name = "supplier_phone_no")
	private String supplierPhoneNo	;
	
	@Column(name = "supplier_email_id")
	private String supplierEmailId	;
	
		
	@Column(name = "supplier_code")
	private String supplierCode	;
	
	@Column(name = "contact_person")
	private String contactPerson	;
	
	@Column(name = "supplier_Phone_no1")
	private String supplierPhoneNo1	;
	
	@Column(name = "supplier_email_id1")
	private String supplierEmailId1;	
	
	@Column(name = "ibanNo")
	private String ibanNo	;
	
	@Column(name = "supplier_account_no")
	private String supplierAccountNo	;
	
	@Column(name = "status")
	private String status	;
	
	@Column(name = "root_directory")
	private String rootDirectory;
	
	@Column(name = "transaction_type")
	private String transactionType;

}
