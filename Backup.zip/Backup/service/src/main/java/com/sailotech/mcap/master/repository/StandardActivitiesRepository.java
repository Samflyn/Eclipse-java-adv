package com.sailotech.mcap.master.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.sailotech.mcap.entity.StandardActivities;

@Repository
public interface StandardActivitiesRepository extends CrudRepository<StandardActivities, Integer>{

}
