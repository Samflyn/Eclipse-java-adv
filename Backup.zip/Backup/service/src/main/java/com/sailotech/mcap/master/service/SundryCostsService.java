package com.sailotech.mcap.master.service;

import com.sailotech.mcap.dto.SundryCostsDto;
import com.sailotech.mcap.exception.MesserApAutomationException;

public interface SundryCostsService {

	
	

	void save(SundryCostsDto sundryCostsDto) throws MesserApAutomationException;

	String getAll();

	String deleteSundryCosts(Integer id);
}
