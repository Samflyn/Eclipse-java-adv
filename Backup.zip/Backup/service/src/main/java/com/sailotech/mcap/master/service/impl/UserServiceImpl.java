package com.sailotech.mcap.master.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.sailotech.mcap.dto.UserDto;
import com.sailotech.mcap.entity.ErrorMaster;
import com.sailotech.mcap.entity.User;
import com.sailotech.mcap.exception.MesserApAutomationException;
import com.sailotech.mcap.master.service.UserService;
import com.sailotech.mcap.repository.UserRepository;
import com.sailotech.mcap.util.MesserApAutomationCacheManager;
import com.sailotech.mcap.util.MesserApAutomationConstants;
import com.sailotech.mcap.util.MesserApAutomationUtil;

@Service
public class UserServiceImpl implements UserService {

	private static final Logger LOGGER = LoggerFactory.getLogger(UserServiceImpl.class);
	@Autowired
	private UserRepository userRepository;

	@Autowired
	MesserApAutomationUtil messerApAutomationUtil;

	@Autowired
	MesserApAutomationCacheManager mcapCacheManager;

	@Autowired
	PasswordEncoder passwordEncoder;

	@Override

	public void saveUser(UserDto userDto) throws MesserApAutomationException {

		try {
			boolean validateUserLoginId = false;
			boolean validateEmailId = false;
			if (userDto.getUserId() != null) {
				boolean validateUserLoginIdByUserId = validateUserLoginIdByUserId(userDto.getUsername(),
						userDto.getUserId());
				if (validateUserLoginIdByUserId) {
					ErrorMaster errorMaster = mcapCacheManager.findByErrorCode("");
					throw new MesserApAutomationException(errorMaster.getErrorCode(), errorMaster.getErrorDesc());
				}
			} else {
				validateUserLoginId = validateUserLoginId(userDto.getUsername());
				validateEmailId = validateEmailId(userDto.getEmailId());
				if (validateUserLoginId || validateEmailId) {
					LOGGER.info("User Already Exist {}");
					ErrorMaster errorMaster = mcapCacheManager.findByErrorCode("");
					throw new MesserApAutomationException("MS500", "USER Already exist");
				}
				userDto.setPassword(passwordEncoder.encode("1234"));
				userDto.setEnabled(true);
			}
			User user = messerApAutomationUtil.convertUserDtoToDao(userDto);
			userRepository.save(user);
		} catch (Exception e) {
			LOGGER.info("Failed while creating user {}", e.getMessage());
			throw new MesserApAutomationException(MesserApAutomationConstants.UNDEFIEND_EXP,
					MesserApAutomationConstants.UNDEFIEND_MSG);
		}
	}

	@Override
	public boolean validateEmailId(String emailId) throws MesserApAutomationException {
		try {
			User user = userRepository.findByUserEmailId(emailId);
			return user != null ? Boolean.TRUE : Boolean.FALSE;
		} catch (Exception e) {
			LOGGER.info("failed in email validation {}", e.getMessage());
			throw new MesserApAutomationException("MC500", "Please Contact your admin");
		}

	}

	private Boolean validateUserLoginIdByUserId(String userLoginId, Integer userId) {
		User user = userRepository.finduserLoginIdNotInId(userLoginId, userId);
		return user != null ? Boolean.TRUE : Boolean.FALSE;
	}

	@Override
	public boolean validateUserLoginId(String username) throws MesserApAutomationException {
		try {
			User user = userRepository.findByUsername(username.toLowerCase());
			return user != null ? Boolean.TRUE : Boolean.FALSE;
		} catch (Exception e) {
			LOGGER.info("Undefiend Exception {}", e.getMessage());
			throw new MesserApAutomationException("MC500", "Please Contact your Admin");
		}

	}

	@Override
	public List<UserDto> getAllUsers(Integer userId) {
		List<User> users ;
		if(messerApAutomationUtil.getRoleName().equalsIgnoreCase("SUPER_ADMIN")){
		 users = userRepository.getAllUsersLoginIdNotInBySuperAdmin(userId);
		}else
			 users = userRepository.getAllUsersLoginIdNotInByAdmin(userId);
		List<UserDto> userDtos = new ArrayList<>();
		for (User user : users) {
			UserDto userDto = messerApAutomationUtil.convertUserDaoToDto(user);
			userDtos.add(userDto);
		}
		return userDtos;
	}

	@Override
	public void deleteByUserId(Integer userId) throws MesserApAutomationException {
		try {
			userRepository.deleteById(userId);
		} catch (Exception e) {
			LOGGER.info("Failed while deleting User{}", e.getMessage());
			throw new MesserApAutomationException("MC500", "Please Contact your Admin");
		}

	}

	@Override
	public UserDto getUserByUserId(Integer userId) {
		Optional<User> user = userRepository.findById(userId);
		if (user.isPresent()) {
			return messerApAutomationUtil.convertUserDaoToDto(user.get());
		}
		return null;
	}

	@Override
	public List<UserDto> getUsersByCompanyId(Integer companyId) {
		List<User> users = null;
		if (companyId != null) {
			users = userRepository.findByCompanyId(companyId);
		} else {
			users = (List<User>) userRepository.findAll();
		}
		List<UserDto> userDtos = new ArrayList<>();
		for (User user : users) {
			UserDto userDto = messerApAutomationUtil.convertUserDaoToDto(user);
			userDtos.add(userDto);
		}
		return userDtos;
	}

	@Override
	public List<UserDto> getUsersByRole(String roleName) {
		List<User> users = userRepository.getUsersByRole(roleName);
		List<UserDto> userDtos = new ArrayList<>();
		for (User user : users) {
			UserDto userDto = messerApAutomationUtil.convertUserDaoToDto(user);
			userDtos.add(userDto);
		}
		return userDtos;
	}
	
	
	@Override
	public List<UserDto> getUserBydept(Integer deptId) throws MesserApAutomationException {
		List<User> users = null;
		try{
		if (deptId != null) {
			
			users = userRepository.findByDeptId(deptId);
		} 
		}catch (Exception e) {
			LOGGER.info("Failed while getting Users{}",e.getMessage());
			throw new MesserApAutomationException("MC500", "Please Contact your Admin");
		}
		List<UserDto> userDtos = new ArrayList<>();
		for (User user : users) {
			UserDto userDto = messerApAutomationUtil.convertUserDaoToDto(user);
			userDtos.add(userDto);
		}
		
		return userDtos;
	}

	@Override
	public void resetPassword(Integer userId) throws MesserApAutomationException {
		try {
		UserDto userByUserId = getUserByUserId(userId);
		
		userByUserId.setPassword(passwordEncoder.encode("1234"));
		
		
			userRepository.save(messerApAutomationUtil.convertUserDtoToDao(userByUserId));
		} catch (Exception e) {
			LOGGER.info("Failed while creating user {}", e.getMessage());
			throw new MesserApAutomationException(MesserApAutomationConstants.UNDEFIEND_EXP,
					MesserApAutomationConstants.UNDEFIEND_MSG);
		}
	}

}
