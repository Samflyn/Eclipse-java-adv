/**
 * 
 */
package com.sailotech.mcap.util;

import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import lombok.Data;

/**
 * @author nagavamsipriya.tirum
 *
 */


@Component
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class AngularDataTableParamModel {
	/// <summary>
	/// Request sequence number sent by DataTable, same value must be returned
	/// in response
	/// </summary>
	private String sEcho;

	/// <summary>
	/// Text used for filtering
	/// </summary>
	private String sSearch;

	/// <summary>
	/// Number of records that should be shown in table
	/// </summary>
	private int iDisplayLength;

	/// <summary>
	/// First record that should be shown(used for paging)
	/// </summary>
	private int iDisplayStart;

	/// <summary>
	/// Number of columns in table
	/// </summary>
	private int iColumns;

	/// <summary>
	/// Number of columns that are used in sorting
	/// </summary>
	private int iSortingCols;

	/// <summary>
	/// Index of the column that is used for sorting
	/// </summary>
	private int iSortColumnIndex;

	/// <summary>
	/// Sorting direction "asc" or "desc"
	/// </summary>
	private String sSortDirection;

	/// <summary>
	/// Comma separated list of column names
	/// </summary>
	private String sColumns;

	public String getsEcho() {
		return sEcho;
	}

	public void setsEcho(String sEcho) {
		this.sEcho = sEcho;
	}

	public String getsSearch() {
		return sSearch;
	}

	public void setsSearch(String sSearch) {
		this.sSearch = sSearch;
	}

	public int getiDisplayLength() {
		return iDisplayLength;
	}

	public void setiDisplayLength(int iDisplayLength) {
		this.iDisplayLength = iDisplayLength;
	}

	public int getiDisplayStart() {
		return iDisplayStart;
	}

	public void setiDisplayStart(int iDisplayStart) {
		this.iDisplayStart = iDisplayStart;
	}

	public int getiColumns() {
		return iColumns;
	}

	public void setiColumns(int iColumns) {
		this.iColumns = iColumns;
	}

	public int getiSortingCols() {
		return iSortingCols;
	}

	public void setiSortingCols(int iSortingCols) {
		this.iSortingCols = iSortingCols;
	}

	public int getiSortColumnIndex() {
		return iSortColumnIndex;
	}

	public void setiSortColumnIndex(int iSortColumnIndex) {
		this.iSortColumnIndex = iSortColumnIndex;
	}

	public String getsSortDirection() {
		return sSortDirection;
	}

	public void setsSortDirection(String sSortDirection) {
		this.sSortDirection = sSortDirection;
	}

	public String getsColumns() {
		return sColumns;
	}

	public void setsColumns(String sColumns) {
		this.sColumns = sColumns;
	}
}
