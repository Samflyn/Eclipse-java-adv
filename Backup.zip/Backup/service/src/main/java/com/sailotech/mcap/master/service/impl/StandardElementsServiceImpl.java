package com.sailotech.mcap.master.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sailotech.mcap.dto.StandardElementsDto;
import com.sailotech.mcap.entity.StandardElements;
import com.sailotech.mcap.master.repository.StandardElementsRepository;
import com.sailotech.mcap.master.service.StandardElementsService;
import com.sailotech.mcap.util.MesserApAutomationConstants;
import com.sailotech.mcap.util.MesserApAutomationUtil;

@Service
public class StandardElementsServiceImpl implements StandardElementsService{

		
	@Autowired
	private StandardElementsRepository standardElementsRepository;

	@Autowired
	MesserApAutomationUtil messerApAutomationUtil;

	@Override
	public String save(StandardElementsDto standardElementsDto) {
		StandardElements standardElements = messerApAutomationUtil.copyBeanProperties(standardElementsDto, StandardElements.class);
		Map<String, String> dataMap = new HashMap<>();
		if (standardElements.getId() != null) {
			standardElements.setUpdate();
		} else {
			standardElements.setSave();;
		}
		StandardElements save = standardElementsRepository.save(standardElements);
	
		dataMap.put(MesserApAutomationConstants.MESSAGE, "Standard Element created successfully");
		dataMap.put(MesserApAutomationConstants.STATUS, MesserApAutomationConstants.SUCCESS_STATUS);
		dataMap.put("standardElementsDto",messerApAutomationUtil.convertPojoToJson(messerApAutomationUtil.copyBeanProperties(save, StandardElementsDto.class)));
		return messerApAutomationUtil.convertPojoToJson(dataMap);
		
	}

	@Override
	public String getAll() {
		
		List<StandardElements> standardElements = (List<StandardElements>) standardElementsRepository.findAll();
		List<StandardElementsDto> standardElementsDto = new ArrayList<>();
		for (StandardElements standardElement : standardElements) {
			StandardElementsDto dto = new StandardElementsDto();
			BeanUtils.copyProperties(standardElement, dto);
			standardElementsDto.add(dto);
		}
		return messerApAutomationUtil.convertPojoToJson(standardElementsDto);
	}

	
	@Override
	public String delete(Integer id) {
		standardElementsRepository.deleteById(id);
		Map<String, String> dataMap = new HashMap<>();
		dataMap.put(MesserApAutomationConstants.MESSAGE, "Standard Element  deleted successfully");
		dataMap.put(MesserApAutomationConstants.STATUS, MesserApAutomationConstants.SUCCESS_STATUS);
		return messerApAutomationUtil.convertPojoToJson(dataMap);
	}

}
