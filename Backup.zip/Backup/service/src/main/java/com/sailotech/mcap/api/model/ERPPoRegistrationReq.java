/**
 * 
 */
package com.sailotech.mcap.api.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

/**
 * @author dhanunjaya.potteti
 *
 */
@Component
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class ERPPoRegistrationReq implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5546126230702520537L;
	
	@JsonProperty("postingDate")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	private Date postingDate;
	private String supplierTxnType;
	private String supplierName;
	@JsonProperty("invoiceNo")
	private String invoiceNo;
	@JsonProperty("invoiceDate")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	private Date invoiceDate;
	@JsonProperty("invoiceAmountNt")
	private Double invoiceAmountNt;
	@JsonProperty("currency")
	private String currency;
	@JsonProperty("noteType")
	private String noteType;
	@JsonProperty("items")
	private List<POInvoiceItems> items;


}
