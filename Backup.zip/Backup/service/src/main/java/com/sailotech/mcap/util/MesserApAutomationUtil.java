package com.sailotech.mcap.util;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sailotech.mcap.dto.CompanyDto;
import com.sailotech.mcap.dto.CountryMasterDto;
import com.sailotech.mcap.dto.DepartmentDto;
import com.sailotech.mcap.dto.EventResponse;
import com.sailotech.mcap.dto.InvoiceHeaderDto;
import com.sailotech.mcap.dto.InvoiceLinesDto;
import com.sailotech.mcap.dto.ItemMappingDto;
import com.sailotech.mcap.dto.ItemMasterDto;
import com.sailotech.mcap.dto.RoleMasterDto;
import com.sailotech.mcap.dto.SearchCriteria;
import com.sailotech.mcap.dto.StateMasterDto;
import com.sailotech.mcap.dto.SupplierMasterDto;
import com.sailotech.mcap.dto.UQCMappingDto;
import com.sailotech.mcap.dto.UQCMasterDto;
import com.sailotech.mcap.dto.UserDto;
import com.sailotech.mcap.dto.WorkFlowStatus;
import com.sailotech.mcap.entity.Company;
import com.sailotech.mcap.entity.CountryMaster;
import com.sailotech.mcap.entity.Department;
import com.sailotech.mcap.entity.InvoiceHeader;
import com.sailotech.mcap.entity.InvoiceLines;
import com.sailotech.mcap.entity.ItemMapping;
import com.sailotech.mcap.entity.ItemMaster;
import com.sailotech.mcap.entity.RoleMaster;
import com.sailotech.mcap.entity.StateMaster;
import com.sailotech.mcap.entity.SupplierMaster;
import com.sailotech.mcap.entity.UQCMapping;
import com.sailotech.mcap.entity.UQCMaster;
import com.sailotech.mcap.entity.User;
import com.sailotech.mcap.exception.ErrorResponse;
import com.sailotech.mcap.master.repository.ItemMappingRepository;
import com.sailotech.mcap.master.repository.UqcMappingRepository;

@Component
public class MesserApAutomationUtil {

	private static final Logger LOGGER = LoggerFactory.getLogger(MesserApAutomationUtil.class);

	@Autowired
	private ApplicationContext applicationContext;

	@Autowired
	private UqcMappingRepository uqcMappingRepository;

	@Autowired
	private ItemMappingRepository itemMappingRepository;

	@SuppressWarnings("unchecked")
	public <T> T copyBeanProperties(Object source, Class<T> requiredType) {
		Object target = applicationContext.getBean(requiredType);
		BeanUtils.copyProperties(source, target);
		if (requiredType != null && requiredType.isInstance(target)) {
			return (T) target;
		}
		return null;
	}

	public String convertPojoToJson(Object object) {
		ObjectMapper mapper = new ObjectMapper();
		try {
			return mapper.writeValueAsString(object);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return "";
	}

	public String getErrorResponse(String errorMessage, String errorCode) {
		ErrorResponse errorResponse = applicationContext.getBean(ErrorResponse.class);
		errorResponse.setErrorMessage(errorMessage);
		errorResponse.setErrorCode(errorCode);
		return convertPojoToJson(errorResponse);
	}

	public String getSuccessResponse(String message, String statusCode) {
		Map<String, String> dataMap = new HashMap<>();
		dataMap.put(MesserApAutomationConstants.MESSAGE, message);
		dataMap.put(MesserApAutomationConstants.STATUS, statusCode);
		return convertPojoToJson(dataMap);
	}

	public <T> T convertTypeReference(String erpResponse, Class<T> clazz) {
		try {
			return new ObjectMapper().readValue(erpResponse, clazz);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return null;
	}

	public InvoiceHeaderDto convertInvoiceHeaderDaoToDto(InvoiceHeader source) {
		InvoiceHeaderDto target = applicationContext.getBean(InvoiceHeaderDto.class);
		BeanUtils.copyProperties(source, target);
		List<InvoiceLinesDto> invoiceLines = new ArrayList<>();
		for (InvoiceLines lineSource : source.getItems()) {
			InvoiceLinesDto lineTarget = applicationContext.getBean(InvoiceLinesDto.class);
			BeanUtils.copyProperties(lineSource, lineTarget);
			lineTarget.setHeaderId(source.getHeaderId());
			invoiceLines.add(lineTarget);
		}
		target.setItems(invoiceLines);
		return target;
	}

	public static Integer getUserId() {
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		if (principal instanceof User)
			return ((User) principal).getUserId();
		return null;
	}

	public static Integer getCompanyId() {
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		if (principal instanceof User)
			return ((User) principal).getCompany().getCompanyId();
		return null;
	}

	public static String getRoleName() {
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		if (principal instanceof User)
			return ((User) principal).getRoleMaster().getRoleName();
		return null;
	}

	public static Integer getLoggedInUser() {
		User principal = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		if (principal != null) {
			return principal.getUserId();
		}
		return null;
	}

	public Integer getLoggedInUserCompanyId() {
		User principal = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		if (principal != null) {
			return principal.getCompany().getCompanyId();
		}
		return null;
	}

	public InvoiceHeader convertInvoiceHeaderDtoToDao(InvoiceHeaderDto invoiceHeaderDto) {
		InvoiceHeader target = applicationContext.getBean(InvoiceHeader.class);
		BeanUtils.copyProperties(invoiceHeaderDto, target);
		List<InvoiceLines> invoiceLines = new ArrayList<>();
		if (null != invoiceHeaderDto.getItems()) {
			for (InvoiceLinesDto lineSource : invoiceHeaderDto.getItems()) {
				InvoiceLines lineTarget = applicationContext.getBean(InvoiceLines.class);
				BeanUtils.copyProperties(lineSource, lineTarget);
				lineTarget.setHeaderId(invoiceHeaderDto.getHeaderId());
				lineTarget.setCreatedOn(Calendar.getInstance().getTime());
				invoiceLines.add(lineTarget);
			}
		}
		target.setItems(invoiceLines);
		return target;
	}

	public UQCMapping convertUQCMappingDtoToDao(UQCMappingDto uqcMappingDto) {
		UQCMapping target = applicationContext.getBean(UQCMapping.class);
		BeanUtils.copyProperties(uqcMappingDto, target);
		UQCMaster uqcMaster = applicationContext.getBean(UQCMaster.class);
		BeanUtils.copyProperties(uqcMappingDto.getUqcMasterDto(), uqcMaster);
		target.setUqcMaster(uqcMaster);
		return target;
	}

	public EventResponse prepareErrorResponse(String code, String msg) {
		EventResponse event = new EventResponse();
		event.setStatus(false);
		event.setStatusCode(code);
		event.setMessage(msg);
		return event;
	}
	public EventResponse prepareErrorResponse(String code, String msg, Object object) {
		EventResponse event = new EventResponse();
		event.setStatus(false);
		event.setData(object);
		event.setStatusCode(code);
		event.setMessage(msg);
		return event;
	}
	public EventResponse prepareSuccessResponse(String code, String msg, Object object) {
		EventResponse event = new EventResponse();
		event.setStatus(true);
		event.setData(object);
		event.setStatusCode(code);
		event.setMessage(msg);
		return event;
	}

	public EventResponse prepareSuccessResponse(String respCode, String respMsg) {
		EventResponse event = new EventResponse();
		event.setStatus(true);
		event.setStatusCode(respCode);
		event.setMessage(respMsg);
		return event;
	}

	public ItemMapping convertItemMappingDtoToDao(ItemMappingDto source) {

		ItemMapping target = applicationContext.getBean(ItemMapping.class);
		BeanUtils.copyProperties(source, target);
		ItemMaster itemMaster = applicationContext.getBean(ItemMaster.class);
		if (null != source.getItemMasterDto()) {
			BeanUtils.copyProperties(source.getItemMasterDto(), itemMaster);
		}
		target.setItemMaster(itemMaster);
		return target;
	}

	public ItemMappingDto convertItemMappingDaoToDto(ItemMapping source) {
		ItemMappingDto target = applicationContext.getBean(ItemMappingDto.class);
		BeanUtils.copyProperties(source, target);
		ItemMasterDto itemMasterDto = applicationContext.getBean(ItemMasterDto.class);
		if (null != source.getItemMaster()) {
			BeanUtils.copyProperties(source.getItemMaster(), itemMasterDto);
		}
		target.setItemMasterDto(itemMasterDto);
		return target;
	}

	public UQCMappingDto convertuqcMappingDaoToDto(UQCMapping source) {
		UQCMappingDto target = applicationContext.getBean(UQCMappingDto.class);
		BeanUtils.copyProperties(source, target);
		UQCMasterDto uqcMasterDto = applicationContext.getBean(UQCMasterDto.class);
		if (null != source.getUqcMaster()) {
			BeanUtils.copyProperties(source.getUqcMaster(), uqcMasterDto);
		}
		target.setUqcMasterDto(uqcMasterDto);
		return target;
	}

	public User convertUserDtoToDao(UserDto source) {
		User target = applicationContext.getBean(User.class);
		BeanUtils.copyProperties(source, target);

		Company company = applicationContext.getBean(Company.class);
		if (source.getCompanyDto() != null) {
			company.setCompanyId(source.getCompanyDto().getCompanyId());
			target.setCompany(company);
		}
		CountryMaster countrymaster = applicationContext.getBean(CountryMaster.class);
		if (null != source.getCountryMasterDto().getCountryId()) {
			countrymaster.setCountryId(source.getCountryMasterDto().getCountryId());
			target.setCountryMaster(countrymaster);
		}
		StateMaster stateMaster = applicationContext.getBean(StateMaster.class);
		if (source.getStateDto() != null && source.getStateDto().getStateId() != null) {
			stateMaster.setStateId(source.getStateDto().getStateId());
			target.setStateMaster(stateMaster);
		}
		RoleMaster roleMaster = applicationContext.getBean(RoleMaster.class);
		if (null != source.getRoleMasterDto()) {
			BeanUtils.copyProperties(source.getRoleMasterDto(), roleMaster);
			target.setRoleMaster(roleMaster);
		}
		Department dept = applicationContext.getBean(Department.class);
		if (null != source.getDepartmentDto()) {
			BeanUtils.copyProperties(source.getDepartmentDto(), dept);
			target.setDepartment(dept);
		}

		if (target.getUserId() != null) {
			target.setUpdate();
		} else {
			target.setSave();
		}
		return target;
	}

	public UserDto convertUserDaoToDto(User source) {
		UserDto target = applicationContext.getBean(UserDto.class);
		BeanUtils.copyProperties(source, target);
		if (source.getCompany() != null) {
			CompanyDto companyDto = this.copyBeanProperties(source.getCompany(), CompanyDto.class);
			target.setCompanyDto(companyDto);
		}
		if (null != source.getCountryMaster()) {
			CountryMasterDto countryMasterDto = this.copyBeanProperties(source.getCountryMaster(),
					CountryMasterDto.class);
			target.setCountryMasterDto(countryMasterDto);
		}
		if (null != source.getStateMaster()) {
			StateMasterDto stateMasterDto = this.copyBeanProperties(source.getStateMaster(), StateMasterDto.class);
			target.setStateDto(stateMasterDto);
		}
		if (null != source.getRoleMaster()) {
			RoleMasterDto roleMasterDto = this.copyBeanProperties(source.getRoleMaster(), RoleMasterDto.class);
			target.setRoleMasterDto(roleMasterDto);
		}
		if (null != source.getDepartment()) {
			DepartmentDto departmentDto = this.copyBeanProperties(source.getDepartment(), DepartmentDto.class);
			target.setDepartmentDto(departmentDto);
		}
		return target;
	}

	private List<Predicate> bulidPredicate(Root<InvoiceHeader> root, List<SearchCriteria> searchCriterias,
			CriteriaBuilder cb) {

		// create a new predicate list
		List<Predicate> predicates = new ArrayList<>();

		// add add criteria to predicates
		for (SearchCriteria criteria : searchCriterias) {

			switch (criteria.getOperation()) {
			case GREATER_THAN:
				predicates.add(cb.greaterThan(root.get(criteria.getKey()), criteria.getValue().toString()));

				break;
			case EQUAL:
				predicates.add(cb.equal(root.get(criteria.getKey()), criteria.getValue()));

				break;
			default:

			}

		}
		return predicates;
	}

	public Specification<InvoiceHeader> getQuueue(List<SearchCriteria> searchCriterias) {
		return (Root<InvoiceHeader> root, CriteriaQuery<?> cq, CriteriaBuilder cb) ->

		cb.and(bulidPredicate(root, searchCriterias, cb).toArray(new Predicate[] {}));

	}

	public SupplierMasterDto convertsupplierMasterDaoToDto(SupplierMaster source) {

		SupplierMasterDto target = applicationContext.getBean(SupplierMasterDto.class);
		BeanUtils.copyProperties(source, target);

		if (source.getCompany() != null) {
			CompanyDto companyDto = this.copyBeanProperties(source.getCompany(), CompanyDto.class);
			target.setCompanyDto(companyDto);
		}
		if (null != source.getCountryMaster()) {
			CountryMasterDto countryMasterDto = this.copyBeanProperties(source.getCountryMaster(),
					CountryMasterDto.class);
			target.setCountryMasterDto(countryMasterDto);
		}

		return target;

	}

	public SupplierMaster convertsupplierMasterDtoToDao(SupplierMasterDto source) {

		SupplierMaster target = applicationContext.getBean(SupplierMaster.class);
		BeanUtils.copyProperties(source, target);

		Company company = applicationContext.getBean(Company.class);
		if (source.getCompanyDto() != null) {
			company.setCompanyId(source.getCompanyDto().getCompanyId());
			target.setCompany(company);
		}
		CountryMaster countrymaster = applicationContext.getBean(CountryMaster.class);
		if (null != source.getCountryMasterDto().getCountryId()) {
			countrymaster.setCountryId(source.getCountryMasterDto().getCountryId());
			target.setCountryMaster(countrymaster);
		}

		return target;

	}

	public boolean validateInvoice(InvoiceHeaderDto invoiceHeaderDto) {

		List<String> errorMessages = new ArrayList<>();

		// Common validation for Both Cost and PO
		if (StringUtils.isEmpty(invoiceHeaderDto.getSupplierName())) {
			errorMessages.add("Missing Supplier name  ");
		}
		if (StringUtils.isEmpty(invoiceHeaderDto.getSupplierAddress())) {
			errorMessages.add("Missing Supplier address ");
		}
		if (StringUtils.isEmpty(invoiceHeaderDto.getCompanyName())) {
			errorMessages.add("Missing Buyer name ");
		}
		if (StringUtils.isEmpty(invoiceHeaderDto.getCompanyAddress())) {
			errorMessages.add("Missing Buyer address ");
		}
		if (StringUtils.isEmpty(invoiceHeaderDto.getInvoiceNo())) {
			errorMessages.add("Missing Invoice no ");
		}
		if (invoiceHeaderDto.getInvoiceDate() == null) {
			errorMessages.add("Missing InvoiceDate ");
		}
		if (invoiceHeaderDto.getInvoiceAmountNt() == null) {
			errorMessages.add("Missing Invoice Amount Net ");
		}
		if (invoiceHeaderDto.getInvoiceAmountGross() == null) {
			errorMessages.add("Missing Invoice Amount Gross");
		}
		if (invoiceHeaderDto.getIbanNo() == null) {
			errorMessages.add("Missing IBAN No ");
		}
		if (invoiceHeaderDto.getAccountNo() == null) {
			errorMessages.add("Missing Account No ");
		}
		if (invoiceHeaderDto.getVatId() == null) {
			errorMessages.add("Missing VAT Id ");
		}

		invoiceHeaderDto.setNoteType(MesserApAutomationConstants.NOTE_TYPE_C);

		if (StringUtils.isEmpty(invoiceHeaderDto.getPoNumber())) {
			invoiceHeaderDto.setTransactionType(MesserApAutomationConstants.TRANSACTION_TYPE_CI);

			// validation for cost invoice
			if (invoiceHeaderDto.getServiceDate() == null) {
				errorMessages.add("Missing Service Date ");
			}

		} else {
			invoiceHeaderDto.setTransactionType(MesserApAutomationConstants.TRANSACTION_TYPE_PI);

			// validation for PO invoice
			if (invoiceHeaderDto.getDeliveryDate() == null) {
				errorMessages.add("Missing Delivery Date ");
			}
		}

		if (MesserApAutomationConstants.TRANSACTION_TYPE_CN.equals(invoiceHeaderDto.getTypeOfInvoice())) {
			invoiceHeaderDto.setTransactionType(MesserApAutomationConstants.TRANSACTION_TYPE_CN);
			if (!StringUtils.isEmpty(invoiceHeaderDto.getOinum())
					&& !StringUtils.isEmpty(invoiceHeaderDto.getInvoiceNo())) {
				errorMessages.add("Missing Original Invoice No,Credit note no");
			}
		}

		boolean flag = false;

		List<UQCMapping> uqcMappings = (List<UQCMapping>) uqcMappingRepository.findAll();

		List<ItemMapping> itemMappings = (List<ItemMapping>) itemMappingRepository.findAll();

		if (invoiceHeaderDto.getItems() != null && !invoiceHeaderDto.getItems().isEmpty()) {

			for (InvoiceLinesDto item : invoiceHeaderDto.getItems()) {
				List<String> lineErrorMessages = new ArrayList<>();

				if (item.getRate() == null) {
					lineErrorMessages.add("Missing VAT/Tax Rate  ");
				} else {

				}
				if (item.getTaxAmount() == null) {
					lineErrorMessages.add("Missing VAT/Tax Amount ");
				}
				if (StringUtils.isEmpty(item.getCurrency())) {
					lineErrorMessages.add("Missing Currency ");
				} else if (item.getCurrency().length() > 3) {
					lineErrorMessages.add("Currency length should be 3");
				}
				if (StringUtils.isEmpty(item.getUqc())) {
					lineErrorMessages.add("Missing UOM ");
				}
				if (StringUtils.isEmpty(item.getQty())) {
					lineErrorMessages.add("Missing Qty ");
				}
				if (item.getItemRate() == null) {
					lineErrorMessages.add("Missing Item Rate ");
				}
				if (StringUtils.isEmpty(item.getSupplierItemCode())) {
					lineErrorMessages.add("Missing Supplier Item code ");
				}	if (StringUtils.isEmpty(item.getSupplierItemDesc())) {
					lineErrorMessages.add("Missing Supplier Item Description ");
				}
				if (item.getLineValue() == null) {
					lineErrorMessages.add("Missing Line amount ");
				}
				if (invoiceHeaderDto.getTransactionType()
						.equalsIgnoreCase(MesserApAutomationConstants.TRANSACTION_TYPE_PI)) {
					if (StringUtils.isEmpty(item.getPoNumber())) {
						lineErrorMessages.add(" Missing PO Number ");
					} else if (validateAlphanumericWithlength(item.getPoNumber(), 1, 9)) {
						lineErrorMessages.add("PO Number should be Alphanumeric and string of length 9 characters only ");
					}
				}
				if (!lineErrorMessages.isEmpty()) {
					flag = true;
				}

				if (invoiceHeaderDto.getInvoiceAmountNt() != null && item.getTaxAmount() != null) {
					item.setTaxBaseamount(invoiceHeaderDto.getInvoiceAmountNt() - item.getTaxAmount());
				}

				item.setErrorDesc(String.join(",", lineErrorMessages));

				Optional<UQCMapping> uqcMapping = uqcMappings.stream()
						.filter(uqc -> uqc.getUqcMaster().getUqcCode().equals(item.getSupplierUOMCode())).findAny();

				Optional<ItemMapping> itemMapping = itemMappings.stream()
						.filter(i -> i.getItemMaster().getItemCode().equals(item.getSupplierItemCode())
								|| i.getItemMaster().getItemDesc().equals(item.getSupplierItemDesc()))
						.findAny();

				if (uqcMapping.isPresent()) {
					item.setUqc(uqcMapping.get().getUqcMaster().getUqcCode());
				}
				if (itemMapping.isPresent()) {
					item.setItemCode(itemMapping.get().getItemMaster().getItemCode());
					item.setItemDesc(itemMapping.get().getItemMaster().getItemDesc());
				}

				item.setNoteType(MesserApAutomationConstants.NOTE_TYPE_D);

			}
		}

		if (errorMessages.isEmpty() && !flag) {
			invoiceHeaderDto.setWorkFlowStatus(WorkFlowStatus.SAVED.value());
			invoiceHeaderDto.setErrorDesc("");
			return true;
		} else {
			invoiceHeaderDto.setWorkFlowStatus(WorkFlowStatus.PARTIAL_EXTRACTED.value());
			invoiceHeaderDto.setErrorDesc( String.join(",", errorMessages));
			return false;
		}

	}

	private boolean validateAlphanumericWithlength(String value, int min, int max) {
		return Pattern.compile("^[a-zA-Z0-9]" + "{+" + min + "," + max + "}+$").matcher(value).matches();

	}


}
