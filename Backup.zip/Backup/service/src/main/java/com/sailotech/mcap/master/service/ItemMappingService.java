package com.sailotech.mcap.master.service;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.sailotech.mcap.dto.ItemMappingDto;
import com.sailotech.mcap.exception.DataValidationException;

public interface ItemMappingService {

	Integer saveItemMapping(ItemMappingDto itemMappingDto) throws DataValidationException;

	void deleteItemMapping(Integer itemMappingId);

	Map<String, Object> getAllItemMappingByCompanyId(Integer companyId, HttpServletRequest request);

	String getItemMapping(Integer tenantId);

}
