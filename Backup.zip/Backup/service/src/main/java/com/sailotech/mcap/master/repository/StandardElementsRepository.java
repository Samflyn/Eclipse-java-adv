package com.sailotech.mcap.master.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.sailotech.mcap.entity.StandardElements;

@Repository
public interface StandardElementsRepository extends CrudRepository<StandardElements, Integer>{

}
