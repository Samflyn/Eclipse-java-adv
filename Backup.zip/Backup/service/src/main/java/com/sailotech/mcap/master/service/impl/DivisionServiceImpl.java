package com.sailotech.mcap.master.service.impl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sailotech.mcap.dto.DivisionDto;
import com.sailotech.mcap.entity.Division;
import com.sailotech.mcap.exception.MesserApAutomationException;
import com.sailotech.mcap.master.repository.DivisionRepository;
import com.sailotech.mcap.master.service.DivisionService;
import com.sailotech.mcap.util.MesserApAutomationConstants;
import com.sailotech.mcap.util.MesserApAutomationUtil;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class DivisionServiceImpl implements DivisionService {

	@Autowired
	private MesserApAutomationUtil mcapUtil;

	@Autowired
	private DivisionRepository divisionRepository;

	@Override
	public void save(DivisionDto divisionDto) throws MesserApAutomationException {
		try {

			Division division = mcapUtil.copyBeanProperties(divisionDto, Division.class);
			if (division.getId() != null)
				division.setUpdate();
			else
				division.setSave();
			divisionRepository.save(division);

		} catch (Exception e) {
			if (e instanceof SQLException) {

				log.info("Failed while creating {}", e.getCause());
				throw new MesserApAutomationException(MesserApAutomationConstants.DATABASE_EXP,
						MesserApAutomationConstants.DATABASE_EXECPTION_MSG);
			} else if (e instanceof IllegalArgumentException) {
				log.info("Failed while convertng data {}", e.getMessage());
				throw new MesserApAutomationException(MesserApAutomationConstants.UNDEFIEND_EXP,
						MesserApAutomationConstants.UNDEFIEND_MSG);
			}

		}
	}

	@Override
	public List<DivisionDto> getAllDivisions() {
		List<Division> divisions = (List<Division>) divisionRepository.findAll();
		List<DivisionDto> divisionDto = new ArrayList<>();
		for (Division division : divisions) {
			DivisionDto dto = new DivisionDto();
			BeanUtils.copyProperties(division, dto);
			divisionDto.add(dto);
		}
		return divisionDto;
	}

	@Override
	public String deleteByDivisionId(Integer id) {
		divisionRepository.deleteById(id);
		Map<String, String> dataMap = new HashMap<>();
		dataMap.put(MesserApAutomationConstants.MESSAGE, "Deleted successfully");
		dataMap.put(MesserApAutomationConstants.STATUS, MesserApAutomationConstants.SUCCESS_STATUS);
		return mcapUtil.convertPojoToJson(dataMap);
	}

}
