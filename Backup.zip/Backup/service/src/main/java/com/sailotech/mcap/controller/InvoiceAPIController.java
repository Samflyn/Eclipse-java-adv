/**
 * 
 */
package com.sailotech.mcap.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sailotech.mcap.dto.EventResponse;
import com.sailotech.mcap.dto.WorkFlowStatus;
import com.sailotech.mcap.exception.MesserApAutomationException;
import com.sailotech.mcap.service.InvoiceProcessService;
import com.sailotech.mcap.util.MesserApAutomationUtil;

/**
 * @author dhanunjaya.potteti
 *
 */
@RestController
@RequestMapping("/api/invoice")
public class InvoiceAPIController {

	private static final Logger LOGGER = LoggerFactory.getLogger(InvoiceProcessController.class);

	@Autowired
	MesserApAutomationUtil mcApUtil;

	@Autowired
	InvoiceProcessService invoiceProcessService;
	
	@PutMapping(value = "/registration")
	public EventResponse erpInvoiceBooking(@RequestParam Integer headerId) throws MesserApAutomationException {
		LOGGER.info("Invoice Booking in ERP System headerID# {} ", headerId);
		EventResponse eventRes = invoiceProcessService.invoiceRegistration(headerId, WorkFlowStatus.SAVED.value());
		if (eventRes.isStatus()) {
			// update workflow status
			//invoiceProcessService.updateWorkFlowStatus(headerId, WorkFlowStatus.REGISTERED.value());
			return eventRes;

		} else {
			// return to client with reponse message
			return eventRes;
		}

	}
	
	@PutMapping(value = "/verification")
	public EventResponse comapareInvoice(@RequestParam Integer headerId) throws MesserApAutomationException {
		LOGGER.info("Invoice comparision with ERP System headerID# {} ", headerId);

		EventResponse eventRes = invoiceProcessService.compareInvoice(headerId, WorkFlowStatus.GRN_AVAILABLE.value());
		if (eventRes.isStatus()) {
			// update workflow status
			//invoiceProcessService.updateWorkFlowStatus(headerId, WorkFlowStatus.REGISTERED.value());
			return eventRes;

		} else {
			// return to client with reponse message
			return eventRes;
		}

	}
}
