package com.sailotech.mcap.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.web.servlet.ModelAndView;

import com.sailotech.mcap.api.model.POInvoiceRegistrationRes;
import com.sailotech.mcap.api.model.POResponse;
import com.sailotech.mcap.config.PropertiesConfig;
import com.sailotech.mcap.dto.EventResponse;
import com.sailotech.mcap.dto.InvoiceHeaderDto;
import com.sailotech.mcap.dto.WorkFlowStatus;
import com.sailotech.mcap.entity.Company;
import com.sailotech.mcap.entity.InvoiceHeader;
import com.sailotech.mcap.entity.InvoiceLines;
import com.sailotech.mcap.entity.SupplierMaster;
import com.sailotech.mcap.entity.User;
import com.sailotech.mcap.exception.DataValidationException;
import com.sailotech.mcap.exception.MesserApAutomationException;
import com.sailotech.mcap.master.repository.CompanyRepository;
import com.sailotech.mcap.master.repository.SupplierMasterRepository;
import com.sailotech.mcap.repository.InvoiceHeaderRepository;
import com.sailotech.mcap.repository.UserRepository;
import com.sailotech.mcap.service.InvoiceProcessService;
import com.sailotech.mcap.service.MesserClient;
import com.sailotech.mcap.util.AngularDataTableParamModel;
import com.sailotech.mcap.util.AngularDataTablesParamUtility;
import com.sailotech.mcap.util.InvoiceExcelReport;
import com.sailotech.mcap.util.MesserApAutomationConstants;
import com.sailotech.mcap.util.MesserApAutomationUtil;
import com.sailotech.mcap.util.MesserSortIndexEnum;
import com.sailotech.mcap.util.ProcessedDatatableSearchSpecification;

@Service
@Transactional(rollbackFor = Exception.class)
public class InvoiceProcessServiceImpl implements InvoiceProcessService {

	private static final Logger LOGGER = LoggerFactory.getLogger(InvoiceProcessServiceImpl.class);

	@Autowired
	private InvoiceHeaderRepository invoiceHeaderRepo;

	@Autowired
	MesserApAutomationUtil messerUtil;

	@Autowired
	UserRepository userRepository;

	@Autowired
	MesserApAutomationConstants mcapConstants;

	@Autowired
	ModelMapper mapper;

	@Autowired
	MesserClient messerClient;

	@Autowired
	private AngularDataTablesParamUtility angularDataTablesParamUtility;

	@Autowired
	private ProcessedDatatableSearchSpecification processedDatatableSearchSpecification;

	@Autowired
	PropertiesConfig properties;

	@Autowired
	CompanyRepository companyRepository;

	@Autowired
	SupplierMasterRepository supplierMasterRepository;

	public InvoiceHeaderDto saveInvoice(InvoiceHeaderDto invoiceHeaderDto) {

		InvoiceHeader invoiceHeader = messerUtil.convertInvoiceHeaderDtoToDao(invoiceHeaderDto);
		invoiceHeader.setWorkFlowStatus(WorkFlowStatus.SAVED.value());

		invoiceHeaderDto.setErrorDesc("");

		if (invoiceHeader.getHeaderId() != null) {
			invoiceHeader.setUpdate();

		} else {
			invoiceHeader.setSave();
			invoiceHeader.setUserId(MesserApAutomationUtil.getUserId());
			// invoice is created from automation service
			invoiceHeader.setChannelType(MesserApAutomationConstants.CHANNEL_TYPE_PORTAL);

		}
		InvoiceHeader invoiceHeaderResp = invoiceHeaderRepo.save(invoiceHeader);
  
		return messerUtil.convertInvoiceHeaderDaoToDto(invoiceHeaderResp);
	}

	@Override
	public EventResponse invoiceRegistration(Integer headerId, Integer workFlowStatus)
			throws MesserApAutomationException {
		InvoiceHeader invoiceHeaderResp = null;
		POInvoiceRegistrationRes regResponse = null;
		Optional<InvoiceHeader> invoiceHeaderObj = null;
		InvoiceHeader header=null;
		Company company = null;
		HttpHeaders headers = null;

		invoiceHeaderObj = invoiceHeaderRepo.findByHeaderIdAndWorkFlowStatus(headerId, workFlowStatus);
		if (invoiceHeaderObj.isPresent()) {
			invoiceHeaderResp = invoiceHeaderObj.get();

			Optional<Company> companyObj = companyRepository.findById(invoiceHeaderResp.getCompanyId());
			if (companyObj.isPresent()) {
				company = companyObj.get();
				headers = prepareHttpHeaders(company.getCompanyCode(), company.getUserId(), company.getPassword());

			}
			if (invoiceHeaderResp.getTransactionType().equals(MesserApAutomationConstants.TRANSACTION_TYPE_PI)) {
				EventResponse eventResponse = saveItemPostionDetails(invoiceHeaderResp, headers);
				if (!eventResponse.isStatus()) {
					return eventResponse;
				} else {
					invoiceHeaderObj = invoiceHeaderRepo.findByHeaderIdAndWorkFlowStatus(headerId, workFlowStatus);
					invoiceHeaderResp = invoiceHeaderObj.get();
				}
			}

			// LN invoice booking Integraion logic
			InvoiceHeaderDto headerDto = messerUtil.convertInvoiceHeaderDaoToDto(invoiceHeaderResp);
			// preparing request

			// headerDto.getItems().forEach(item
			// ->{item.setTaxBaseamount(headerDto.getInvoiceAmountNt().subtract(item.getTaxAmount(),
			// new MathContext(2)));});
			headerDto.setPostingDate(new Date());
			headerDto.setSourceCompany(company.getCompanyCode());

			
		
			EventResponse response = messerClient.post(properties.getLnService() + properties.getCreatePInvocie(),

					headers, headerDto);

			if (response.isStatus()) {

				// if response have GRN available & Recived invoice should moved to ready to

				regResponse = mapper.map(response.getData(), POInvoiceRegistrationRes.class);
				if (regResponse.getInvoiceStatus().equals(MesserApAutomationConstants.REGISTERED_SUCCESS_STATUS)) {
					invoiceHeaderResp.setLnStatus(regResponse.getInvoiceStatus());
					invoiceHeaderResp.setInvoiceId(regResponse.getInvoiceId());
					invoiceHeaderResp.setFinancialBatch(regResponse.getFinancialBatch());
					if (headerDto.getTransactionType().equals(MesserApAutomationConstants.TRANSACTION_TYPE_PI)) {
						invoiceHeaderResp.setWorkFlowStatus(WorkFlowStatus.REGISTERED.value());
					} else if (headerDto.getTransactionType().equals(MesserApAutomationConstants.TRANSACTION_TYPE_CI)) {
						invoiceHeaderResp.setWorkFlowStatus(WorkFlowStatus.PD_APPROVAL_PENDING.value());
					}
					 header=invoiceHeaderRepo.save(invoiceHeaderResp);
					response.setMessage("Invoice successfully registered with Invoice Id: " + regResponse.getInvoiceId()
							+ " and status: " + regResponse.getInvoiceStatus());
					response.setData(messerUtil.convertInvoiceHeaderDaoToDto(header));
				}else
				{
					invoiceHeaderResp.setWorkFlowStatus(WorkFlowStatus.REGISTERATION_FAIL.value());
					invoiceHeaderResp.setErrorDesc(response.getMessage());
					 header=invoiceHeaderRepo.save(invoiceHeaderResp);
					response.setData(messerUtil.convertInvoiceHeaderDaoToDto(header));
				}
			}
			return response;

		} else {
			return messerUtil.prepareErrorResponse("MC-002", "Invoice Details may got updated by another user");
		}

	}

	public EventResponse saveItemPostionDetails(InvoiceHeader invoiceHeaderResp, HttpHeaders headers) {

		boolean itemsStatus = true;
		InvoiceHeader header=null;
		List<String> poNumbers = invoiceHeaderResp.getItems().stream().map(item -> item.getPoNumber()).distinct()
				.collect(Collectors.toList());
		LOGGER.info("Unique PO Numbers list#{}", poNumbers);
		HashMap<String, List<POResponse>> hm = new HashMap<>();
		for (String ponNumber : poNumbers) {

			EventResponse apiResponse = messerClient
					.get(properties.getLnService() + properties.getPoDetailsUrl() + ponNumber, headers);

			if (apiResponse.isStatus()) {
				List<POResponse> responseList = mapper.map(apiResponse.getData(), new TypeToken<List<POResponse>>() {
				}.getType());

				if (!responseList.isEmpty()) {
					hm.put(ponNumber, responseList);
				}
			}
		}

		if (!hm.isEmpty()) {
			for (String poNumber : hm.keySet()) {
				for (InvoiceLines item : invoiceHeaderResp.getItems()) {

					if (hm.containsKey(item.getPoNumber())) {
						List<POResponse> responseList = hm.get(item.getPoNumber());
						for (POResponse poResponse : responseList) {
							if (poResponse.getItemCode().equalsIgnoreCase(item.getItemCode())) {
								item.setSequence(poResponse.getSequence());
								item.setPositionNumber(poResponse.getPositionNumber());
								item.setErrorDesc("");
							} else if (poResponse.getItemCodeDesc().equalsIgnoreCase(item.getItemDesc())) {
								item.setSequence(poResponse.getSequence());
								item.setPositionNumber(poResponse.getPositionNumber());
								item.setErrorDesc("");
							} else {
								item.setErrorDesc("Item code & descriptions are not available");
								itemsStatus = false;
							}
						}
					}
				}
			}

			 header=invoiceHeaderRepo.save(invoiceHeaderResp);
			if (itemsStatus) {
				return messerUtil.prepareSuccessResponse("MCSR-000", "Postion Numbers updation completed",messerUtil.convertInvoiceHeaderDaoToDto(header));
			} else {
				invoiceHeaderResp.setErrorDesc("Registraion failed due to few Item code & descriptions are not available please check  Item details for More information");
				 header=invoiceHeaderRepo.save(invoiceHeaderResp);
				return messerUtil.prepareErrorResponse("MCSR-001",
						"Registraion failed due to few Item code & descriptions are not available please check  Item details for More information",messerUtil.convertInvoiceHeaderDaoToDto(header));
			}
		} else {
			invoiceHeaderResp.setErrorDesc("purchase order details are not availabe");
			header=invoiceHeaderRepo.save(invoiceHeaderResp);
			return messerUtil.prepareErrorResponse("MCSR-002", "purchase order details are not availabe",messerUtil.convertInvoiceHeaderDaoToDto(header));
		}

	}

	@Override
	public void updateWorkFlowStatus(Integer headerId, Integer workFlowStatus) throws MesserApAutomationException {
		Optional<InvoiceHeader> invoiceHeader = invoiceHeaderRepo.findById(headerId);
		if (invoiceHeader.isPresent()) {
			InvoiceHeader header = invoiceHeader.get();
			header.setWorkFlowStatus(workFlowStatus);
			invoiceHeaderRepo.save(header);

		} else {
			throw new MesserApAutomationException(mcapConstants.ERROR_CD, mcapConstants.ERROR_MSG);
		}

	}

	@Override
	public Map<String, Object> getInvoicesByTxnAndStatus(Integer companyId, String transactionType,
			Integer workflowStatus, HttpServletRequest request) throws MesserApAutomationException {
		Map<String, Object> mapOfHeaders = new HashMap<>();
		AngularDataTableParamModel param = angularDataTablesParamUtility.getParam(request);
		Long totalCount = null;
		List<InvoiceHeader> invoiceHeaderList = new ArrayList<>();
		Integer[] data = { workflowStatus };
		invoiceHeaderList = getAllInvoiceSpecification(companyId, transactionType, param, Arrays.asList(data));

		totalCount = invoiceHeaderRepo.countByCompanyIdAndTransactionTypeAndWorkFlowStatusIn(companyId, transactionType,
				Arrays.asList(data));
		List<InvoiceHeaderDto> invoiceHeaderDtoList = new ArrayList<>();
		for (InvoiceHeader header : invoiceHeaderList) {
			InvoiceHeaderDto invoiceHeaderDto = new InvoiceHeaderDto();
			invoiceHeaderDto = messerUtil.convertInvoiceHeaderDaoToDto(header);
			invoiceHeaderDtoList.add(invoiceHeaderDto);
		}
		mapOfHeaders.put("recordsTotal", totalCount);
		if (param.getsSearch() != null && !param.getsSearch().isEmpty()) {
			mapOfHeaders.put("recordsFiltered", invoiceHeaderDtoList.size());
		} else {
			mapOfHeaders.put("recordsFiltered", totalCount);
		}
		mapOfHeaders.put("data", invoiceHeaderDtoList);
		return mapOfHeaders;
	}

	public List<InvoiceHeader> getAllInvoiceSpecification(Integer companyId, String transactionType,
			AngularDataTableParamModel param, List<Integer> workFlowList) {
		List<InvoiceHeader> invoiceHeaders = new ArrayList<>();
		if (param.getiDisplayLength() == -1) {
			param.setiDisplayLength(Integer.MAX_VALUE);
		}
		int page = param.getiDisplayStart() / param.getiDisplayLength();
		try {
			invoiceHeaders = invoiceHeaderRepo
					.findAll(
							processedDatatableSearchSpecification.getAllInvoices(companyId, transactionType,
									param.getsSearch(), workFlowList),
							PageRequest.of(page, param.getiDisplayLength(),
									sortByProperty(param.getiSortColumnIndex(), param.getsSortDirection())))
					.getContent();
		} catch (Exception e) {
			LOGGER.info("In Exception getAllInvoiceSpecification{} ", e.getMessage());
		}
		return invoiceHeaders;
	}

	private Sort sortByProperty(int index, String direction) {
		Direction dir;
		if (StringUtils.pathEquals(direction, "asc")) {
			dir = Direction.ASC;
		} else {
			dir = Direction.DESC;
		}
		List<String> sortVariable = sortVariable(index);
		if ("headerId".equalsIgnoreCase(sortVariable.get(0))) {
			dir = Direction.DESC;
		}
		return Sort.by(dir, sortVariable.get(0));
	}

	private List<String> sortVariable(int index) {
		List<String> sortedColumns = new ArrayList<>();
		sortedColumns.add(MesserSortIndexEnum.SVMPDataColumns.INVOICE_DATE.getColumnName(index));
		return sortedColumns;
	}

	@Override
	public InvoiceHeaderDto getInvoice(Integer headerId) throws MesserApAutomationException {
		Optional<InvoiceHeader> invoiceHeader = invoiceHeaderRepo.findById(headerId);
		if (invoiceHeader.isPresent()) {
			return messerUtil.convertInvoiceHeaderDaoToDto(invoiceHeader.get());
		} else {
			throw new MesserApAutomationException(mcapConstants.ERROR_CD, mcapConstants.ERROR_MSG);
		}

	}

	// @Scheduled(fixedDelayString = "${scheduler.grn_pending.fixed.delay}")
	public void processPendingInvoices() {

		Optional<List<InvoiceHeader>> inoviceHeaderlist = invoiceHeaderRepo
				.findByCompanyIdAndWorkFlowStatus(MesserApAutomationUtil.getCompanyId(), WorkFlowStatus.GRN_PENDING);

		if (inoviceHeaderlist.isPresent()) {

			for (InvoiceHeader header : inoviceHeaderlist.get()) {
				// LN integration logic to move if success GRN_AVAILABLE Queue
				header.setWorkFlowStatus(WorkFlowStatus.GRN_AVAILABLE.value());
				// if fail
				header.setWorkFlowStatus(WorkFlowStatus.GRN_PENDING.value());
			}
			invoiceHeaderRepo.saveAll(inoviceHeaderlist.get());
		}

	}

	@Override
	public EventResponse compareInvoice(Integer headerId, Integer value) {
		Optional<InvoiceHeader> inoviceHeader = invoiceHeaderRepo.findById(headerId);
		if (inoviceHeader.isPresent()) {
			InvoiceHeader header = inoviceHeader.get();

			// LN integration logic to move

		}
		return null;
	}

	@Override
	public void deleteByHeaderId(Integer headerId) {
		invoiceHeaderRepo.deleteById(headerId);
	}

	private HttpHeaders prepareHttpHeaders(String companyCode, String userId, String password) {
		HttpHeaders headers = new HttpHeaders();
		headers.set("Content-Type", "application/json");
		headers.set("company", companyCode);
		headers.set("username", userId);
		headers.set("password", password);
		headers.set("Authorization", String.format("Basic %s", Base64.getEncoder().encodeToString(
				String.format("%s:%s", properties.getLnUserName(), properties.getLnUserPwd()).getBytes())));
		return headers;
	}

	@Override
	public List<InvoiceHeaderDto> getInvoiceReports(String fromDate, String toDate, String transactionType,
			String invoiceNo, Integer workFlowStatus, String poNumber, HttpServletRequest request)
			throws MesserApAutomationException {

		AngularDataTableParamModel param = angularDataTablesParamUtility.getParam(request);
		if (param.getiDisplayLength() == -1) {
			param.setiDisplayLength(Integer.MAX_VALUE);
		}
		int page = 1;// param.getiDisplayStart() / param.getiDisplayLength();
		try {
			Specification<InvoiceHeader> filterByFpandInvoiceDtaes = processedDatatableSearchSpecification
					.filterByTransactionTypeAndInvoiceDates(fromDate, toDate, transactionType, invoiceNo,
							workFlowStatus);
			LOGGER.debug("Specification for Invoice reports" + filterByFpandInvoiceDtaes);
			List<InvoiceHeaderDto> invoiceHeaderDtoList = new ArrayList<>();
			List<InvoiceHeader> InvoieHeaderList = invoiceHeaderRepo
					.findAll(filterByFpandInvoiceDtaes, PageRequest.of(page, param.getiDisplayLength()
					// ,
					// sortByProperty(param.getiSortColumnIndex(), param.getsSortDirection())
					)).getContent();
			if (InvoieHeaderList.isEmpty()) {
				throw new MesserApAutomationException("MEC", "There is no data available");
			}
			InvoieHeaderList.forEach(header -> {
				InvoiceHeaderDto invoiceHeaderDto = new InvoiceHeaderDto();
				invoiceHeaderDto = messerUtil.convertInvoiceHeaderDaoToDto(header);
				invoiceHeaderDtoList.add(invoiceHeaderDto);
			});

			return invoiceHeaderDtoList;
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.info("In Exception getInvoiceReports{} ", e.getMessage());
			throw new MesserApAutomationException("", "");
		}

	}

	@Override
	public void saveBulkInvoice(List<InvoiceHeaderDto> invoiceHeaderDtoList) {
		Company company = companyRepository.findByCompanyName("MESSER CUTTING SYSTEMS");
		try {

			if (invoiceHeaderDtoList != null && !invoiceHeaderDtoList.isEmpty()) {
				invoiceHeaderDtoList.forEach(invoiceHeaderDto -> {
					boolean validationflg=messerUtil.validateInvoice(invoiceHeaderDto);
					InvoiceHeader invoiceHeader = messerUtil.convertInvoiceHeaderDtoToDao(invoiceHeaderDto);
					if (!StringUtils.isEmpty(invoiceHeaderDto.getCostAccountMgr())) {
						String costAccountMgr = invoiceHeaderDto.getCostAccountMgr().trim();
						User user = userRepository.findByFullName(costAccountMgr.toLowerCase());
						if (user != null) {
							invoiceHeader.setCostAccountMgr(user.getUserId());
						}
					}

					if (!StringUtils.isEmpty(invoiceHeaderDto.getSupplierName())) {
						SupplierMaster supplierMaster = supplierMasterRepository
								.findBySupplierName(invoiceHeaderDto.getSupplierName());
						if (supplierMaster != null) {
							invoiceHeader.setSupplierName(supplierMaster.getSupplierName());
							invoiceHeader.setSupplierIdentifier(supplierMaster.getSupplierCode());
							invoiceHeader.setSupplierAddress(supplierMaster.getSupplierAddress());
							invoiceHeader.setSupplierTxnType(supplierMaster.getTransactionType());
							invoiceHeader.setIbanNo(supplierMaster.getIbanNo());
						}
					}

					invoiceHeader.setCreatedOn(Calendar.getInstance().getTime());
					invoiceHeader.setChannelType(MesserApAutomationConstants.CHANNEL_TYPE_OCR);
					invoiceHeader.setCompanyId(company.getCompanyId());
					invoiceHeader.setCompanyName(company.getCompanyName());
					invoiceHeader.setCompanyAddress(company.getRegistredAddress());
					InvoiceHeader headerObj=invoiceHeaderRepo.save(invoiceHeader);
					if(validationflg&&headerObj!=null)
					{
						try {
							invoiceRegistration(headerObj.getHeaderId(), WorkFlowStatus.SAVED.value());
						} catch (MesserApAutomationException e) {
							LOGGER.info("Exception: while invoice booking{}",e.getMessage());
							//e.printStackTrace();
						}
					}
				});
			}

			LOGGER.info("Invoice successfully pushed to portal");

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	// Export DAta
	@Override
	public ModelAndView exportCustomerInvoiceReport(String fromDate, String toDate, HttpServletRequest request,
			HttpServletResponse response, String fp, String invNo, Integer status) throws DataValidationException {
		List<InvoiceHeader> invoiceHeaders = getInvoiceReport(fromDate, toDate, fp, invNo, status);
		if (invoiceHeaders.isEmpty()) {
			throw new DataValidationException("SVMP_DATA_VALIDATION_ERROR", "No data found for selected invoice dates");
		} else {
			Map<String, Object> model = new HashMap<>();
			model.put("results", invoiceHeaders);
			return new ModelAndView(new InvoiceExcelReport(), model);
		}
	}

	public List<InvoiceHeader> getInvoiceReport(String fromDate, String todate, String tType, String invNo,
			Integer status) {

		List<InvoiceHeader> invoiceHeaders = null;
		List<Integer> tenanatId = new ArrayList<>();

		/*
		 * invoiceHeaders = invoiceHeaderRepo.
		 * ByTransactionTypeAndWorkFlowStatusAndInvoiceDateBetweenAndInvoiceNo(tType,
		 * status, processedDatatableSearchSpecification.convertFpToDate(fromDate),
		 * processedDatatableSearchSpecification.convertFpToDate(todate), invNo);
		 */
		invoiceHeaders = (List<InvoiceHeader>) invoiceHeaderRepo.findAll(processedDatatableSearchSpecification
				.filterByTransactionTypeAndInvoiceDates(fromDate, todate, tType, invNo, status));

		return invoiceHeaders;
	}

	@Override
	public String getCustomerInvoiceReport(String fromDate, String toDate, String transactionType, String invNo,
			Integer status) {
		List<InvoiceHeader> invoiceHeaders = getInvoiceReport(fromDate, toDate, transactionType, invNo, status);

		return messerUtil.convertPojoToJson(invoiceHeaders);
	}

}
