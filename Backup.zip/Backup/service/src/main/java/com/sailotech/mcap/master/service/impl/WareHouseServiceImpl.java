package com.sailotech.mcap.master.service.impl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sailotech.mcap.dto.WareHouseDto;
import com.sailotech.mcap.entity.WareHouse;
import com.sailotech.mcap.exception.MesserApAutomationException;
import com.sailotech.mcap.master.repository.WareHouseRepository;
import com.sailotech.mcap.master.service.WareHouseService;
import com.sailotech.mcap.util.MesserApAutomationConstants;
import com.sailotech.mcap.util.MesserApAutomationUtil;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class WareHouseServiceImpl implements WareHouseService {

	@Autowired
	private MesserApAutomationUtil mcapUtil;

	@Autowired
	private WareHouseRepository wareHouseRepository;

	@Override
	public void save(WareHouseDto wareHouseDto) throws MesserApAutomationException {

		try {

			WareHouse wareHouse = mcapUtil.copyBeanProperties(wareHouseDto, WareHouse.class);
			if (wareHouse.getId() != null)
				wareHouse.setUpdate();
			else
				wareHouse.setSave();
			wareHouseRepository.save(wareHouse);

		} catch (Exception e) {
			if (e instanceof SQLException) {

				log.info("Failed while creating {}", e.getCause());
				throw new MesserApAutomationException(MesserApAutomationConstants.DATABASE_EXP,
						MesserApAutomationConstants.DATABASE_EXECPTION_MSG);
			} else if (e instanceof IllegalArgumentException) {
				log.info("Failed while convertng data {}", e.getMessage());
				throw new MesserApAutomationException(MesserApAutomationConstants.UNDEFIEND_EXP,
						MesserApAutomationConstants.UNDEFIEND_MSG);
			}

		}

	}

	@Override
	public List<WareHouseDto> getAllWareHouse() {
		List<WareHouse> wareHouses = (List<WareHouse>) wareHouseRepository.findAll();
		List<WareHouseDto> wareHouseDto = new ArrayList<>();
		for (WareHouse wareHouse : wareHouses) {
			WareHouseDto dto = new WareHouseDto();
			BeanUtils.copyProperties(wareHouse, dto);
			wareHouseDto.add(dto);
		}
		return wareHouseDto;
	}

	@Override
	public String deleteByWareHouseId(Integer id) {
		wareHouseRepository.deleteById(id);
		Map<String, String> dataMap = new HashMap<>();
		dataMap.put(MesserApAutomationConstants.MESSAGE, "Deleted successfully");
		dataMap.put(MesserApAutomationConstants.STATUS, MesserApAutomationConstants.SUCCESS_STATUS);
		return mcapUtil.convertPojoToJson(dataMap);
	}

}
