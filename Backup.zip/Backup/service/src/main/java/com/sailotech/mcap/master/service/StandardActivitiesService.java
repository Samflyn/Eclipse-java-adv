package com.sailotech.mcap.master.service;

import com.sailotech.mcap.dto.StandardActivitiesDto;

public interface StandardActivitiesService {
	public String save(StandardActivitiesDto standardActivitiesDto);

	public String getAll();
	
	public String delete(Integer id);

}
