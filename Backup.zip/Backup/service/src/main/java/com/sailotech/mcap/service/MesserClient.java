/**
 * 
 */
package com.sailotech.mcap.service;

import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;

import com.sailotech.mcap.dto.EventResponse;

/**
 * @author dhanunjaya.potteti
 *
 */
@Service
public interface MesserClient {
	//@Retryable(value = { Exception.class }, maxAttempts = 3, backoff = @Backoff(delay = 1000))
	EventResponse post(String serviceName, HttpHeaders prepareHttpHeaders, Object requestObj);
	EventResponse get(String serviceName, HttpHeaders prepareHttpHeaders);

}
