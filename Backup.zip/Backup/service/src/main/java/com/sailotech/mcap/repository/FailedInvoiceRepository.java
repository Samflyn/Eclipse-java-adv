package com.sailotech.mcap.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.sailotech.mcap.entity.FailedInvoices;

@Repository
public interface FailedInvoiceRepository extends CrudRepository<FailedInvoices, Integer> {

}
