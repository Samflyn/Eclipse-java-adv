package com.sailotech.mcap.master.service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.sailotech.mcap.dto.ItemMasterDto;
import com.sailotech.mcap.exception.DataValidationException;
import com.sailotech.mcap.exception.MesserApAutomationException;

public interface ItemMasterService {

	public String getItemMaster();

	public String deletePartner(Integer itemId);

	List<ItemMasterDto> getAllItemsByCompanyId(Integer companyId);

	Integer saveItemMaster(ItemMasterDto itemMasterDto) throws DataValidationException;

	Map<String, Object> getAllItemsByCompanyId(Integer companyId, HttpServletRequest request)
			throws MesserApAutomationException;

}
