package com.sailotech.mcap.dto;

import java.util.Arrays;
import java.util.Optional;

/**
 * @author nagendra.babu
 */
public enum WorkFlowStatus {

	PARTIAL_EXTRACTED(1),REGISTERATION_FAIL(1), SAVED(2), REGISTERED(3), GRN_PENDING(4), GRN_AVAILABLE(5), MATCHED(6), NOT_MATCHED(7),
	PD_APPROVAL_PENDING(8), PD_APPROVED(9), CAM_NOT_AVAILABLE(10), CAM_APPROVAL_PENDING(11), CAM_APPROVED(12),
	LN_APPROVED(13), PAYMENT(14);

	private Integer value;

	WorkFlowStatus(Integer value) {
		this.value = value;
	}

	public Integer value() {
		return value;
	}

	public static String getNameByValue(Integer value) {
		Optional<WorkFlowStatus> workflowStatus = Arrays.stream(WorkFlowStatus.values())
				.filter(e -> e.value.equals(value)).findAny();
		if (workflowStatus.isPresent()) {
			return workflowStatus.get().name();
		}
		return null;
	}

	public Integer getValueByName(String name) {
		return WorkFlowStatus.valueOf(name).value();
	}
}
