package com.sailotech.mcap.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.sailotech.mcap.dto.WorkFlowStatus;
import com.sailotech.mcap.entity.InvoiceHeader;

@Repository
public interface InvoiceHeaderRepository
		extends CrudRepository<InvoiceHeader, Integer>, JpaSpecificationExecutor<InvoiceHeader> {

	Optional<InvoiceHeader> findByHeaderIdAndWorkFlowStatus(Integer headerId, int workflowStatus);

	Optional<List<InvoiceHeader>> findByTransactionTypeAndWorkFlowStatus(String transactionType,
			Integer workflowStatus);

	Page<InvoiceHeader> findByTransactionTypeAndWorkFlowStatus(String transactionType, Integer workflowStatus,
			Pageable paging);

	Long countByCompanyIdAndTransactionTypeAndWorkFlowStatusIn(Integer companyId, String transactionType,
			List<Integer> asList);

	Optional<List<InvoiceHeader>> findByWorkFlowStatus(WorkFlowStatus grnPending);

	Optional<List<InvoiceHeader>> findByCompanyIdAndWorkFlowStatus(Integer companyId, WorkFlowStatus grnPending);

/*	List<InvoiceHeader> ByTransactionTypeAndWorkFlowStatusAndInvoiceDateBetweenAndInvoiceNo(String tType,
			Integer status, Date convertFpToDate, Date convertFpToDate2, String invNo);*/

}
