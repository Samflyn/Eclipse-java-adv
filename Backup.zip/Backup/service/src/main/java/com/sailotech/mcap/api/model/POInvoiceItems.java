/**
 * 
 */
package com.sailotech.mcap.api.model;

import java.io.Serializable;
import java.util.List;

import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.sailotech.mcap.dto.DimensionTypeMappingDto;

import lombok.Data;

/**
 * @author dhanunjaya.potteti
 *
 */
@Component
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class POInvoiceItems implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 4110780824077050975L;
	@JsonProperty("lineValue")
	private String lineValue;
	@JsonProperty("noteType")
	private String noteType;
	@JsonProperty("poNumber")
	private String poNumber;
	@JsonProperty("positionNumber")
	private String positionNumber;
	@JsonProperty("sequence")
	private String sequence;
	@JsonProperty("itemCode")
	private String itemCode;
	@JsonProperty("qty")
	private String qty;
	@JsonProperty("uqc")
	private String uqc;
	@JsonProperty("taxCode")
	private String taxCode;
	@JsonProperty("taxBaseAmount")
	private String taxBaseAmount;
	@JsonProperty("taxAmount")
	private String taxAmount;
	@JsonProperty("dimensions")
	
	private List<DimensionTypeMappingDto> dimensionsTypeMappings;

	
}
