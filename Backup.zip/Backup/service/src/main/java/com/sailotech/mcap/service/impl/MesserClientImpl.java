/**
 * 
 */
package com.sailotech.mcap.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sailotech.mcap.config.PropertiesConfig;
import com.sailotech.mcap.dto.EventResponse;
import com.sailotech.mcap.service.MesserClient;

/**
 * @author dhanunjaya.potteti
 *
 */
@Service
public class MesserClientImpl implements MesserClient {
	private static final Logger logger = LoggerFactory.getLogger(MesserClientImpl.class);

	@Autowired
	PropertiesConfig properties;
	
	@Autowired
	RestTemplate restTemplate;
	/*
	 * It will invoke external service with Request body & Return APIResponse
	 * 
	 * @Request:serviceName, it have specific service value
	 * 
	 * @Request:headers, it have specific company  details
	 * 
	 * @Request:requestObj , it post request Body
	 * 
	 * @Return: externalServiceResponse, this response coming from external service
	 */
	@Override
	public EventResponse post(String serviceName,HttpHeaders headers, Object requestObj) {
		ObjectMapper objMapper=null;
		EventResponse externalServiceResponse = null;
		try {
			objMapper=new ObjectMapper();
		logger.info("External Service url{}# Request {}#", serviceName,objMapper.writeValueAsString(requestObj));
	
	
		
			ResponseEntity<EventResponse> response = restTemplate.exchange(serviceName, HttpMethod.POST,
					new HttpEntity<>(requestObj, headers), EventResponse.class);
			if (response.getStatusCode() == HttpStatus.OK) {
				logger.debug("Event API post() service successfully done");
				logger.info("External Service Response {}#", response.getBody());
				return response.getBody();
			}
		} catch (HttpStatusCodeException e) {
			try {
				return objMapper.readValue(e.getResponseBodyAsString(), EventResponse.class);
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} 
			logger.error("External Service Bad Response {}#", e.getResponseBodyAsString());
			
		
		} catch (Exception e) {
			logger.error("External Service Internal error {}#", e.getMessage());
			
		}
		return externalServiceResponse;
	}
	
	/*
	 * It will invoke external service & Return APIResponse
	 * 
	 * @Request:serviceName, it have specific service value
	 * 
	 *@Request:headers, it have specific company  details
	 * 
	 * @Return: externalServiceResponse, this response coming from external service
	 */
	@Override
	public EventResponse get(String serviceName,HttpHeaders headers) {
		logger.info("External serviceName# {}", serviceName);
		EventResponse externalServiceResponse = null;
		RestTemplate restTemplate = new RestTemplate();
		ObjectMapper objMapper=new ObjectMapper();
		try {
			ResponseEntity<EventResponse> response = restTemplate.exchange(serviceName, HttpMethod.GET,
					new HttpEntity<>(headers), EventResponse.class);
			if (response.getStatusCode() == HttpStatus.OK) {
				logger.debug("Event API get() service successfully done");
				logger.info("External Service Response# {}", response.getBody());
				return response.getBody();
			}
		} catch (HttpStatusCodeException e) {
			try {
				return objMapper.readValue(e.getResponseBodyAsString(), EventResponse.class);
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} 
			logger.error("External Service Bad Response {}#", e.getResponseBodyAsString());
			
		
		} catch (Exception e) {
			logger.error("External Service Internal error {}#", e.getMessage());
			
		}
		return externalServiceResponse;
	}
	

	
	
}
