package com.sailotech.mcap.master.service.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.sailotech.mcap.dto.LedgerAccountConfigurationDto;
import com.sailotech.mcap.entity.DimensionTypeMaster;
import com.sailotech.mcap.entity.LedgerAccount;
import com.sailotech.mcap.exception.MesserApAutomationException;
import com.sailotech.mcap.master.repository.LedgerAccountRepository;
import com.sailotech.mcap.master.service.LedgerAccountService;
import com.sailotech.mcap.util.MesserApAutomationConstants;
import com.sailotech.mcap.util.MesserApAutomationUtil;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class LedgerAccountServiceImpl implements LedgerAccountService {

	@Autowired
	LedgerAccountRepository ledgerAccountRepository;

	@Autowired
	MesserApAutomationUtil messerApAutomationUtil;

	@Override
	public String getLedgerAccountByCompanyId(Integer companyId) {
		List<LedgerAccount> ledgerAccounts = ledgerAccountRepository.findByCompanyId(companyId);
		return messerApAutomationUtil.convertPojoToJson(ledgerAccounts);
	}

	@Override
	public String getAllLedgerAccounts() throws MesserApAutomationException {
		List<LedgerAccount> ledgerAccount = (List<LedgerAccount>) ledgerAccountRepository.findAll();
		return messerApAutomationUtil.convertPojoToJson(ledgerAccount);
	}

	@Override
	public String saveLedgerAccount(LedgerAccountConfigurationDto ledgerAccountConfigurationDto) {
		Integer loggedInUser = messerApAutomationUtil.getUserId();
		LedgerAccount ledgerAccount = new LedgerAccount();
		BeanUtils.copyProperties(ledgerAccountConfigurationDto, ledgerAccount);
		if (!StringUtils.isEmpty(ledgerAccount)) {
			ledgerAccount.setLastUpdatedBy(loggedInUser);
			ledgerAccount.setLastUpdatedOn(Calendar.getInstance().getTime());
		} else {
			ledgerAccount.setCompanyId(messerApAutomationUtil.getCompanyId());
			ledgerAccount.setCreatedBy(loggedInUser);
			ledgerAccount.setCreatedOn(Calendar.getInstance().getTime());
		}
		ledgerAccountRepository.save(ledgerAccount);
		return messerApAutomationUtil.convertPojoToJson("Ledger Account saved successfully");
	}

	@Override
	@Transactional
	public String deleteLedgerAccount(String ledgerAccount) {
		ledgerAccountRepository.deleteByLedgerAccount(ledgerAccount);
		Map<String, String> dataMap = new HashMap<>();
		dataMap.put(MesserApAutomationConstants.MESSAGE, "Ledger Account deleted successfully");
		dataMap.put(MesserApAutomationConstants.STATUS, MesserApAutomationConstants.SUCCESS_STATUS);
		return messerApAutomationUtil.convertPojoToJson(dataMap);
	}

	@Override
	public String deleteLedgerAccountMapping(String dto) {
		/*
		 * Optional<LedgerAccount> account =
		 * ledgerAccountRepository.findByLedgerAccount(dto); if(account.isPresent()) {
		 * LedgerAccount ledgerAccount = account.get();
		 * ledgerAccount.setLedgerDimensions(new ArrayList<DimensionTypeMaster>());
		 * ledgerAccount.setLastUpdatedBy(messerApAutomationUtil.getUserId());
		 * ledgerAccount.setLastUpdatedOn(Calendar.getInstance().getTime());
		 * ledgerAccountRepository.save(ledgerAccount); }
		 */
		Map<String, String> dataMap = new HashMap<>();
		dataMap.put(MesserApAutomationConstants.MESSAGE, "Ledger Account Mapping deleted successfully");
		dataMap.put(MesserApAutomationConstants.STATUS, MesserApAutomationConstants.SUCCESS_STATUS);
		return messerApAutomationUtil.convertPojoToJson(dataMap);
	}

}
