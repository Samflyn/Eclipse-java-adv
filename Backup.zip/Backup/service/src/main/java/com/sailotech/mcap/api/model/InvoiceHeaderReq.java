package com.sailotech.mcap.api.model;

import java.util.List;

import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

/**
 * @author dhanunjaya.potteti
 *
 */
@Component
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class InvoiceHeaderReq {
	@JsonProperty("invoiceNo")
	private String invoiceNo;
	@JsonProperty("creditNote")
	private String creditNote;
	@JsonProperty("poNumber")
	private String poNumber;
	@JsonProperty("serviceDate")
	private String serviceDate;
	@JsonProperty("invoiceDate")
	private String invoiceDate;
	@JsonProperty("deliveryDate")
	private String deliveryDate;
	@JsonProperty("invoiceAmountGross")
	private String invoiceAmountGross;
	@JsonProperty("invoiceAmountNT")
	private String invoiceAmountNT;
	@JsonProperty("ibanNo")
	private String ibanNo;
	@JsonProperty("accountNo")
	private String accountNo;
	@JsonProperty("companyName")
	private String companyName;
	@JsonProperty("companyAddress")
	private String companyAddress;
	@JsonProperty("supplierName")
	private String supplierName;
	@JsonProperty("supplierAddress")
	private String supplierAddress;
	@JsonProperty("supplierIdentifier")
	private String supplierIdentifier;
	@JsonProperty("vehiclePlateNo")
	private String vehiclePlateNo;
	@JsonProperty("costCenterCode")
	private String costCenterCode;
	@JsonProperty("costAccountMgr")
	private String costAccountMgr;
	@JsonProperty("vatID")
	private String vatID;
	@JsonProperty("transactionType")
	private String transactionType;
	@JsonProperty("filePath")
	private String filePath;
	@JsonProperty("typeOfInvoice")
	private String typeOfInvoice;
	@JsonProperty("items")
	private List<ItemReq> items;
	
}
