package com.sailotech.mcap.master.service;

import org.springframework.stereotype.Service;

import com.sailotech.mcap.dto.DimensionTypeMasterDto;

@Service
public interface DimensionService {
	
	public String saveDimension(DimensionTypeMasterDto dimensionTypeMasterDto);

	public String getAllDimensions();

	public String deleteDimension(Integer dimensionType);
}
