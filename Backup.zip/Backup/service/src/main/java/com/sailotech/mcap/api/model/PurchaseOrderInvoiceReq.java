/**
 * 
 */
package com.sailotech.mcap.api.model;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author dhanunjaya.potteti
 *
 */
public class PurchaseOrderInvoiceReq implements Serializable{
	@JsonProperty("sourceCompany")
	private String sourceCompany;
	@JsonProperty("postingDate")
	private String postingDate;
	private String supplierTxnType;
	private String supplierName;
	@JsonProperty("invoiceNo")
	private String invoiceNo;
	@JsonProperty("invoiceDate")
	private String invoiceDate;
	@JsonProperty("invoiceAmountNt")
	private String invoiceAmountNt;
	@JsonProperty("currency")
	private String currency;
	@JsonProperty("noteType")
	private String noteType;
	@JsonProperty("items")
	private List<PurchaseOrderInvoiceItemReq> items;

	public String getSourceCompany() {
		return sourceCompany;
	}

	public void setSourceCompany(String sourceCompany) {
		this.sourceCompany = sourceCompany;
	}

	public String getPostingDate() {
		return postingDate;
	}

	public void setPostingDate(String postingDate) {
		this.postingDate = postingDate;
	}

	public String getSupplierTxnType() {
		return supplierTxnType;
	}

	public void setSupplierTxnType(String supplierTxnType) {
		this.supplierTxnType = supplierTxnType;
	}

	public String getSupplierName() {
		return supplierName;
	}

	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}

	public String getInvoiceNo() {
		return invoiceNo;
	}

	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}

	public String getInvoiceDate() {
		return invoiceDate;
	}

	public void setInvoiceDate(String invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	public String getInvoiceAmountNt() {
		return invoiceAmountNt;
	}

	public void setInvoiceAmountNt(String invoiceAmountNt) {
		this.invoiceAmountNt = invoiceAmountNt;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getNoteType() {
		return noteType;
	}

	public void setNoteType(String noteType) {
		this.noteType = noteType;
	}

}
