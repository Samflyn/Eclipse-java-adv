/**
 * 
 */
package com.sailotech.mcap.api.model;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author dhanunjaya.potteti
 *
 */
public class PurchaseOrderInvoiceItemReq {
	@JsonProperty("sourceCompany")
	private String lineValue;
	@JsonProperty("sourceCompany")
	private String noteType;
	@JsonProperty("sourceCompany")
	private String poNumber;
	@JsonProperty("sourceCompany")
	private String positionNumber;
	@JsonProperty("sourceCompany")
	private String sequence;
	@JsonProperty("sourceCompany")
	private String itemCode;
	@JsonProperty("sourceCompany")
	private String qty;
	@JsonProperty("sourceCompany")
	private String uqc;
	private String taxCode;
	private String taxBaseAmount;
	private String taxAmount;
	public String getLineValue() {
		return lineValue;
	}
	public void setLineValue(String lineValue) {
		this.lineValue = lineValue;
	}
	public String getNoteType() {
		return noteType;
	}
	public void setNoteType(String noteType) {
		this.noteType = noteType;
	}
	public String getPoNumber() {
		return poNumber;
	}
	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}
	public String getPositionNumber() {
		return positionNumber;
	}
	public void setPositionNumber(String positionNumber) {
		this.positionNumber = positionNumber;
	}
	public String getSequence() {
		return sequence;
	}
	public void setSequence(String sequence) {
		this.sequence = sequence;
	}
	public String getItemCode() {
		return itemCode;
	}
	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}
	public String getQty() {
		return qty;
	}
	public void setQty(String qty) {
		this.qty = qty;
	}
	public String getUqc() {
		return uqc;
	}
	public void setUqc(String uqc) {
		this.uqc = uqc;
	}
	public String getTaxCode() {
		return taxCode;
	}
	public void setTaxCode(String taxCode) {
		this.taxCode = taxCode;
	}
	public String getTaxBaseAmount() {
		return taxBaseAmount;
	}
	public void setTaxBaseAmount(String taxBaseAmount) {
		this.taxBaseAmount = taxBaseAmount;
	}
	public String getTaxAmount() {
		return taxAmount;
	}
	public void setTaxAmount(String taxAmount) {
		this.taxAmount = taxAmount;
	}
	
	
}
