package com.sailotech.mcap.master.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sailotech.mcap.dto.EventResponse;
import com.sailotech.mcap.dto.UserDto;
import com.sailotech.mcap.exception.DataValidationException;
import com.sailotech.mcap.exception.MesserApAutomationException;
import com.sailotech.mcap.master.service.UserService;
import com.sailotech.mcap.util.MesserApAutomationConstants;
import com.sailotech.mcap.util.MesserApAutomationUtil;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/user")
@Slf4j
public class UserController {

	@Autowired
	private UserService userService;

	@Autowired
	private MesserApAutomationUtil mcapUtil;

	@PostMapping(value = "/create")
	public EventResponse create(@RequestBody UserDto userDto)
			throws DataValidationException, MesserApAutomationException {
		log.info("create User{} ");
		String message = "";

		userService.saveUser(userDto);
		if (userDto.getUserId() != null) {
			message = userDto.getUsername() + " Updated successfully";
		} else {
			message = userDto.getUsername() + " Ceated successfully";
		}
		return mcapUtil.prepareSuccessResponse(MesserApAutomationConstants.SUCCESS_CD, message);
	}

	@GetMapping("/getAll")
	public List<UserDto> getAll(@RequestParam(value = "userId", required = false) Integer userId) {
		return userService.getAllUsers(userId);
	}

	@DeleteMapping("/delete/{userId}")
	public EventResponse delete(@PathVariable("userId") Integer userId) throws MesserApAutomationException {
		userService.deleteByUserId(userId);
		log.info("Delete User{}", " User deleted sucessfully");
		String message = "User Deleted successfully";
		return mcapUtil.prepareSuccessResponse(MesserApAutomationConstants.SUCCESS_CD, message);
	}

	/*
	 * @GetMapping("/validateEmailId") public EventResponse(@RequestParam(value =
	 * "userId", required = false) Integer userId) { return
	 * userService.getAllUsers(userId); }
	 */

	@GetMapping("/getCAMUsers")
	public List<UserDto> getCAMUsers() {
		return userService.getUsersByRole("CAM");
	}
	
	@GetMapping("/getUserByDept")
	public EventResponse getUSerByDept(@RequestParam(value = "deptId", required = true) Integer deptId) throws MesserApAutomationException {
		
		//return 
		List<UserDto> usersBydept = userService.getUserBydept(deptId);
		
		if(usersBydept.isEmpty())
			return mcapUtil.prepareSuccessResponse(MesserApAutomationConstants.SUCCESS_CD, "No users are available ");
		else 
			return mcapUtil.prepareSuccessResponse(MesserApAutomationConstants.SUCCESS_CD, "UsersBy DepartMent"+deptId ,mcapUtil.convertPojoToJson(usersBydept));
			
	}
	
	//resetPassword
	
	@PostMapping("/resetPassword/{userId}")
	public EventResponse resetPassword(@PathVariable("userId") Integer userId) throws MesserApAutomationException {
		userService.resetPassword(userId);
		log.info("ResetPassword User{}", " Updated Password sucessfully");
		String message = "Updated Password successfully";
		return mcapUtil.prepareSuccessResponse(MesserApAutomationConstants.SUCCESS_CD, message);
	}

}
