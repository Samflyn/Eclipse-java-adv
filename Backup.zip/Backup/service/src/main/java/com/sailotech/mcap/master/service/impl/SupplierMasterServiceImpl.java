package com.sailotech.mcap.master.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sailotech.mcap.dto.StandardElementsDto;
import com.sailotech.mcap.dto.SupplierMasterDto;
import com.sailotech.mcap.entity.StandardElements;
import com.sailotech.mcap.entity.SupplierMaster;
import com.sailotech.mcap.master.repository.SupplierMasterRepository;
import com.sailotech.mcap.master.service.SupplierMasterService;
import com.sailotech.mcap.util.MesserApAutomationConstants;
import com.sailotech.mcap.util.MesserApAutomationUtil;

@Service
public class SupplierMasterServiceImpl implements SupplierMasterService {

	@Autowired
	SupplierMasterRepository supplierMasterRepository;

	@Autowired
	MesserApAutomationUtil messerApAutomationUtil;

	@Override
	public String getAllSuppliers() {

		List<SupplierMaster> supplierMasters = (List<SupplierMaster>) supplierMasterRepository.findAll();
		List<SupplierMasterDto> supplierMasterDto = new ArrayList<>();
		for (SupplierMaster supplierMaster : supplierMasters) {
			supplierMasterDto.add(messerApAutomationUtil.convertsupplierMasterDaoToDto(supplierMaster));
		}
		return messerApAutomationUtil.convertPojoToJson(supplierMasterDto);
	}

	@Override
	public String deleteBySupplierId(Integer id) {
		supplierMasterRepository.deleteById(id);
		Map<String, String> dataMap = new HashMap<>();
		dataMap.put(MesserApAutomationConstants.MESSAGE, "Supplier deleted successfully");
		dataMap.put(MesserApAutomationConstants.STATUS, MesserApAutomationConstants.SUCCESS_STATUS);
		return messerApAutomationUtil.convertPojoToJson(dataMap);
	}

	@Override
	public String save(SupplierMasterDto supplierMasterDto) {
		// return null;
		SupplierMaster supplierMaster = messerApAutomationUtil.convertsupplierMasterDtoToDao(supplierMasterDto);
		Map<String, String> dataMap = new HashMap<>();

		if (supplierMaster.getSupplierId() != null) {
			supplierMaster.setUpdate();
		} else {
			supplierMaster.setSave();
			
		}
		SupplierMaster save = supplierMasterRepository.save(supplierMaster);

		dataMap.put(MesserApAutomationConstants.MESSAGE, " Created successfully");
		dataMap.put(MesserApAutomationConstants.STATUS, MesserApAutomationConstants.SUCCESS_STATUS);
		dataMap.put("supplierMasterDto",
				messerApAutomationUtil.convertPojoToJson(messerApAutomationUtil.convertsupplierMasterDaoToDto(save)));
		return messerApAutomationUtil.convertPojoToJson(dataMap);
	}

}
