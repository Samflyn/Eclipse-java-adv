package com.sailotech.mcap.master.service;

import java.util.List;

import com.sailotech.mcap.dto.CostCenterDto;
import com.sailotech.mcap.exception.MesserApAutomationException;

public interface CostCenterService {

	public List<CostCenterDto> getAllCostCenterDetails();

	public String deleteCostCenter(Integer id);

	void save(CostCenterDto costCenterDto) throws MesserApAutomationException;

}
