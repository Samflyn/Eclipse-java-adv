/**
 * 
 */
package com.sailotech.mcap.api.model;

import java.util.List;

import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

/**
 * @author dhanunjaya.potteti
 *
 */
@Component
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class ItemReq {
	@JsonProperty("poNumber")
	private String poNumber;
	@JsonProperty("itemCode")
	private String itemCode;

	@JsonProperty("itemDesc")
	private String itemDesc;
	@JsonProperty("uqc")
	private String uqc;
	@JsonProperty("qty")
	private String qty;
	@JsonProperty("taxAmount")
	private String taxAmount;
	@JsonProperty("itemRate")
	private String itemRate;
	@JsonProperty("rate")
	private String rate;
	@JsonProperty("lineValue")
	private String lineValue;

}
