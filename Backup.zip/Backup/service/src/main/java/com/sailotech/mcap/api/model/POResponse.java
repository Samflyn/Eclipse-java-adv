/**
 * 
 */
package com.sailotech.mcap.api.model;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author dhanunjaya.potteti
 *
 */
@Component
@Data
@EqualsAndHashCode(callSuper = false)
@JsonInclude(Include.NON_NULL)
public class POResponse {
	  private String itemCode;
	  private String itemCodeDesc;
	  private String ponumber;
	  private String positionNumber;
	  private String sequence;


	
	}