package com.sailotech.mcap.util;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.sailotech.mcap.entity.InvoiceHeader;
import com.sailotech.mcap.entity.ItemMapping;
import com.sailotech.mcap.entity.ItemMaster;

@Component
public class ProcessedDatatableSearchSpecification {

	public Specification<InvoiceHeader> findByUserIdAndWorkFlowStatus(Integer companyId, String searchString,
			String invoiceType) {
		return new Specification<InvoiceHeader>() {
			private static final long serialVersionUID = -4473304391599688502L;

			@Override
			public Predicate toPredicate(Root<InvoiceHeader> root, CriteriaQuery<?> cq, CriteriaBuilder cb) {
				List<Predicate> predicates = new ArrayList<>();
				cq.orderBy(cb.asc(root.get("headerId")));
				if (!StringUtils.isEmpty(searchString)) {
					predicates.add(cb.like(root.get("invoiceNo").as(String.class), searchString.toLowerCase() + "%"));
					predicates.add(cb.like(root.get("invoiceDate").as(String.class), searchString.toLowerCase() + "%"));
					predicates.add(cb.like(root.get("poNumber").as(String.class), searchString.toLowerCase() + "%"));
					return cb.and(cb.equal(root.get("companyId"), companyId),
							cb.or(predicates.toArray(new Predicate[] {})));

				} else {
					return cb.and(cb.equal(root.get("companyId"), companyId), cb
							.or(cb.notEqual(root.get("invoiceType"), invoiceType), cb.isNull(root.get("invoiceType"))));
				}

			}
		};
	}

	public Specification<InvoiceHeader> findByUserIdAndWorkFlowStatusAndInvoiceType(Integer userId, String searchString,
			String invoiceType, Integer status) {
		return new Specification<InvoiceHeader>() {

			private static final long serialVersionUID = -4473304391599688502L;

			@Override
			public Predicate toPredicate(Root<InvoiceHeader> root, CriteriaQuery<?> cq, CriteriaBuilder cb) {
				List<Predicate> predicates = new ArrayList<>();
				cq.orderBy(cb.asc(root.get("headerId")));

				if (!StringUtils.isEmpty(searchString)) {
					predicates.add(cb.like(cb.lower(root.get("registeredId")), searchString.toLowerCase() + "%"));
					predicates.add(cb.like(cb.lower(root.get("registeredName")), searchString.toLowerCase() + "%"));
					predicates.add(cb.like(cb.lower(root.get("bpRegisteredId")).as(String.class),
							searchString.toLowerCase() + "%"));
					predicates.add(cb.like(cb.lower(root.get("bpName")), searchString.toLowerCase() + "%"));
					predicates.add(cb.like(cb.lower(root.get("invoiceNo")).as(String.class),
							searchString.toLowerCase() + "%"));
					predicates.add(cb.like(root.get("invoiceDate").as(String.class), searchString.toLowerCase() + "%"));
					return cb.and(cb.equal(root.get("userId"), userId), cb.equal(root.get("invoiceType"), invoiceType),
							cb.equal(root.get("workFlowStatus"), status),
							cb.or(predicates.toArray(new Predicate[] {})));
				} else {
					return cb.and(cb.equal(root.get("userId"), userId), cb.equal(root.get("invoiceType"), invoiceType),
							cb.equal(root.get("workFlowStatus"), status));
				}

			}
		};
	}

	public Specification<InvoiceHeader> filterByTransactionTypeAndInvoiceDates(String fromDate, String todate,
			String transactionType, String invoiceNo, Integer workFlowStatus) {
		return new Specification<InvoiceHeader>() {

			private static final long serialVersionUID = -4473304391599688502L;

			@Override
			public Predicate toPredicate(Root<InvoiceHeader> root, CriteriaQuery<?> cq, CriteriaBuilder cb) {
				List<Predicate> predicates = new ArrayList<>();
				if (null != fromDate && null != todate) {

					predicates.add(
							cb.between(root.get("invoiceDate"), convertFpToDate(fromDate), convertFpToDate(todate)));
				}
				if (!StringUtils.isEmpty(transactionType)) {
					predicates.add(cb.equal(root.get("transactionType"), transactionType));
				}
				if (workFlowStatus != null) {
					predicates.add(cb.equal(root.get("workFlowStatus"), workFlowStatus));
				}
				if (!StringUtils.isEmpty(invoiceNo)) {
					predicates.add(cb.equal(root.get("invoiceNo"), invoiceNo));
				}

				return cb.and(cb.and(predicates.toArray(new Predicate[] {})));
			}
		};
	}

	/*
	 * Specification<InvoiceHeader> hasAuthor(String fromDate, String todate, String
	 * transactionType, String invoiceNo,Integer workFlowStatus) { return
	 * (invoiceHeader, cq, cb) -> cb.and(cb.and(),
	 * cb.and(cb.equal(invoiceHeader.get("companyId"), companyId)),
	 * cb.and(cb.equal(invoiceHeader.get("transactionType"), transactionType)));
	 * //cb.equal(InvoiceHeader.get("author"), author); }
	 */

	public Specification<InvoiceHeader> getAllInvoices(Integer companyId, String transactionType, String searchString,
			List<Integer> workFlowList) {
		return new Specification<InvoiceHeader>() {
			private static final long serialVersionUID = -4473304391599688502L;

			@Override
			public Predicate toPredicate(Root<InvoiceHeader> root, CriteriaQuery<?> cq, CriteriaBuilder cb) {
				List<Predicate> predicates = new ArrayList<>();
				cq.orderBy(cb.asc(root.get("headerId")));

				if (!StringUtils.isEmpty(searchString)) {
					predicates.add(cb.like(cb.lower(root.get("invoiceNo")), searchString.toLowerCase() + "%"));
					predicates.add(cb.like(root.get("invoiceDate").as(String.class), searchString.toLowerCase() + "%"));
					predicates.add(cb.like(root.get("poNumber"), searchString.toLowerCase() + "%"));
					if (companyId != null) {
						return cb.and(cb.and(cb.in(root.get("workFlowStatus")).value(workFlowList)),
								cb.and(cb.equal(root.get("companyId"), companyId)),
								cb.and(cb.equal(root.get("transactionType"), transactionType)),
								cb.or(predicates.toArray(new Predicate[] {})));
					} else {
						return cb.and(cb.and(cb.in(root.get("workFlowStatus")).value(workFlowList)),
								cb.and(cb.equal(root.get("companyId"), companyId)),
								cb.and(cb.equal(root.get("transactionType"), transactionType)),
								cb.or(predicates.toArray(new Predicate[] {})));
					}

				} else {
					if (companyId != null) {
						return cb.and(cb.and(cb.in(root.get("workFlowStatus")).value(workFlowList)),
								cb.and(cb.equal(root.get("companyId"), companyId)),
								cb.and(cb.equal(root.get("transactionType"), transactionType)));
					} else {
						return cb.and(cb.and(cb.in(root.get("workFlowStatus")).value(workFlowList)),
								cb.and(cb.equal(root.get("companyId"), companyId)),
								cb.and(cb.equal(root.get("transactionType"), transactionType)));
					}

				}

			}
		};
	}

	public Date convertFpToDate(String fp) {
		SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
		try {
			return format.parse(fp);
		} catch (Exception e) {
//LOGGER.error(e.getMessage(), e);
		}
		return null;
	}

	public Specification<ItemMaster> getItemMasterSpecification(Integer companyId, String searchString) {
		return new Specification<ItemMaster>() {
			/**
			 * 
			 */
			private static final long serialVersionUID = -7537966988613493751L;

			@Override
			public Predicate toPredicate(Root<ItemMaster> root, CriteriaQuery<?> cq, CriteriaBuilder cb) {
				List<Predicate> predicates = new ArrayList<>();
				cq.orderBy(cb.asc(root.get("itemId")));

				if (!StringUtils.isEmpty(searchString)) {
					predicates.add(cb.like(cb.lower(root.get("itemCode")), searchString.toLowerCase() + "%"));
					predicates.add(cb.like(cb.lower(root.get("itemDesc")), searchString.toLowerCase() + "%"));
					if (companyId != null) {
						return cb.and(cb.and(cb.in(root.get("companyId")).value(companyId)),
								cb.or(predicates.toArray(new Predicate[] {})));
					} else
						return cb.or(predicates.toArray(new Predicate[] {}));
				}
				return cb.and(predicates.toArray(new Predicate[] {}));
			}
		};
	}

	public Specification<ItemMapping> getItemMappingSpecification(Integer companyId, String searchString) {
		return new Specification<ItemMapping>() {
			/**
			 * 
			 */
			private static final long serialVersionUID = -7537966988613493751L;

			@Override
			public Predicate toPredicate(Root<ItemMapping> root, CriteriaQuery<?> cq, CriteriaBuilder cb) {
				List<Predicate> predicates = new ArrayList<>();
				cq.orderBy(cb.asc(root.get("itemMappingId")));

				if (!StringUtils.isEmpty(searchString)) {
					predicates.add(cb.like(cb.lower(root.get("itemMappingCode")), searchString.toLowerCase() + "%"));
					predicates.add(cb.like(cb.lower(root.get("itemMappingDesc")), searchString.toLowerCase() + "%"));
					if (companyId != null) {
						return cb.and(cb.and(cb.in(root.get("companyId")).value(companyId)),
								cb.or(predicates.toArray(new Predicate[] {})));
					} else
						return cb.or(predicates.toArray(new Predicate[] {}));
				}
				return cb.and(predicates.toArray(new Predicate[] {}));
			}
		};
	}
}
