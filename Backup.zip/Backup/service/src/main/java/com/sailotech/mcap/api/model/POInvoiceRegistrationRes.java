/**
 * 
 */
package com.sailotech.mcap.api.model;

import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

/**
 * @author dhanunjaya.potteti
 *
 */
@Component
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class POInvoiceRegistrationRes {

	@JsonProperty("invoiceId")
	private String invoiceId;
	@JsonProperty("financialBatch")
	private String financialBatch;
	@JsonProperty("sourceCompany")
	private String sourceCompany;
	@JsonProperty("supplierTxnType")
	private String supplierTxnType;
	@JsonProperty("invoiceStatus")
	private String invoiceStatus;

}
