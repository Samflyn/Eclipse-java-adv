package com.sailotech.mcap.master.service.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.sailotech.mcap.dto.ItemMasterDto;
import com.sailotech.mcap.entity.ItemMaster;
import com.sailotech.mcap.exception.DataValidationException;
import com.sailotech.mcap.exception.MesserApAutomationException;
import com.sailotech.mcap.master.repository.ItemMappingRepository;
import com.sailotech.mcap.master.repository.ItemMasterRepository;
import com.sailotech.mcap.master.service.ItemMasterService;
import com.sailotech.mcap.util.AngularDataTableParamModel;
import com.sailotech.mcap.util.AngularDataTablesParamUtility;
import com.sailotech.mcap.util.MesserApAutomationUtil;
import com.sailotech.mcap.util.MesserSortIndexEnum;
import com.sailotech.mcap.util.ProcessedDatatableSearchSpecification;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ItemMasterServiceImpl implements ItemMasterService {

	@Autowired
	ItemMasterRepository itemMasterRepository;

	@Autowired
	MesserApAutomationUtil messerApAutomationUtil;

	@Autowired
	ItemMappingRepository itemmapping;

	@Autowired
	private AngularDataTablesParamUtility angularDataTablesParamUtility;

	@Autowired
	private ProcessedDatatableSearchSpecification processedDatatableSearchSpecification;

	@Override
	public Integer saveItemMaster(ItemMasterDto itemMasterDto) throws DataValidationException {
		Integer loggedInUser = MesserApAutomationUtil.getUserId();
		if (itemMasterDto.getItemId() != null) {
			itemMasterDto.setLastUpdatedBy(loggedInUser);
			itemMasterDto.setLastUpdatedOn(Calendar.getInstance().getTime());
		} else {
			itemMasterDto.setCreatedBy(loggedInUser);
			itemMasterDto.setCreatedOn(Calendar.getInstance().getTime());
		}
		itemMasterDto.setCompanyId(messerApAutomationUtil.getLoggedInUserCompanyId());
		ItemMaster itemMaster = itemMasterRepository
				.save(messerApAutomationUtil.copyBeanProperties(itemMasterDto, ItemMaster.class));
		return itemMaster.getItemId();
	}

	@Override
	public String getItemMaster() {
		Iterable<ItemMaster> itemMasterList = itemMasterRepository.findAll();
		return messerApAutomationUtil.convertPojoToJson(itemMasterList);

	}

	@Override
	public String deletePartner(Integer itemId) {
		if (itemmapping.findByItemMasterExists(itemId)) {
			return "Item Mapping done for this item,Cannot delete";
		} else {
			itemMasterRepository.deleteById(itemId);
			return "Item Deleted Successfully";
		}
	}

	@Override
	public Map<String, Object> getAllItemsByCompanyId(Integer companyId, HttpServletRequest request)
			throws MesserApAutomationException {
		Map<String, Object> mapOfHeaders = new HashMap<>();
		AngularDataTableParamModel param = angularDataTablesParamUtility.getParam(request);
		Long totalCount = null;
		List<ItemMaster> itemsList = new ArrayList<>();

		itemsList = getItemsBySpecification(companyId, param);

		totalCount = itemMasterRepository.countByCompanyId(companyId);
		List<ItemMasterDto> itemMasterDtos = new ArrayList<>();
		for (ItemMaster itemMaster : itemsList) {
			ItemMasterDto itemMasterDto = messerApAutomationUtil.copyBeanProperties(itemMaster, ItemMasterDto.class);
			itemMasterDtos.add(itemMasterDto);
		}
		mapOfHeaders.put("recordsTotal", totalCount);
		if (param.getsSearch() != null && !param.getsSearch().isEmpty()) {
			mapOfHeaders.put("recordsFiltered", itemMasterDtos.size());
		} else {
			mapOfHeaders.put("recordsFiltered", totalCount);
		}
		mapOfHeaders.put("data", itemMasterDtos);
		return mapOfHeaders;
	}

	@Override
	public List<ItemMasterDto> getAllItemsByCompanyId(Integer companyId) {
		List<ItemMaster> itemsList = itemMasterRepository.findByCompanyId(companyId);
		List<ItemMasterDto> itemMasterDtos = new ArrayList<>();
		for (ItemMaster itemMaster : itemsList) {
			ItemMasterDto itemMasterDto = messerApAutomationUtil.copyBeanProperties(itemMaster, ItemMasterDto.class);
			itemMasterDtos.add(itemMasterDto);
		}
		return itemMasterDtos;
	}

	public List<ItemMaster> getItemsBySpecification(Integer companyId, AngularDataTableParamModel param) {
		List<ItemMaster> itemMasters = new ArrayList<>();
		if (param.getiDisplayLength() == -1) {
			param.setiDisplayLength(Integer.MAX_VALUE);
		}
		int page = param.getiDisplayStart() / param.getiDisplayLength();
		try {

			return itemMasterRepository.findAll(
					processedDatatableSearchSpecification.getItemMasterSpecification(companyId, param.getsSearch()),
					PageRequest.of(page, param.getiDisplayLength())).getContent();

		} catch (Exception e) {
			e.printStackTrace();
			log.info("In Exception getAllItems by Specification ", e.getMessage());
		}
		return null;
	}

	/*
	 * private Sort sortByProperty(int index, String direction) { Direction dir; if
	 * (StringUtils.pathEquals(direction, "asc")) { dir = Direction.ASC; } else {
	 * dir = Direction.DESC; } List<String> sortVariable = sortVariable(index); if
	 * ("itemId".equalsIgnoreCase(sortVariable.get(0))) { dir = Direction.DESC; }
	 * return Sort.by(dir, sortVariable.get(0)); }
	 * 
	 * private List<String> sortVariable(int index) { List<String> sortedColumns =
	 * new ArrayList<>();
	 * sortedColumns.add(MesserSortIndexEnum.SVMPDataColumns.INVOICE_DATE.
	 * getColumnName(index)); return sortedColumns; }
	 */
}
