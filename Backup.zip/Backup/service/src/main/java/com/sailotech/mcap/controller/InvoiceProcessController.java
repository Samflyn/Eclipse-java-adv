package com.sailotech.mcap.controller;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.sailotech.mcap.dto.EventResponse;
import com.sailotech.mcap.dto.InvoiceHeaderDto;
import com.sailotech.mcap.dto.WorkFlowStatus;
import com.sailotech.mcap.entity.FailedInvoices;
import com.sailotech.mcap.exception.DataValidationException;
import com.sailotech.mcap.exception.MesserApAutomationException;
import com.sailotech.mcap.repository.FailedInvoiceRepository;
import com.sailotech.mcap.service.InvoiceProcessService;
import com.sailotech.mcap.util.MesserApAutomationConstants;
import com.sailotech.mcap.util.MesserApAutomationUtil;

@RestController
public class InvoiceProcessController {

	private static final Logger LOGGER = LoggerFactory.getLogger(InvoiceProcessController.class);

	@Autowired
	MesserApAutomationUtil mcApUtil;

	@Autowired
	InvoiceProcessService invoiceProcessService;

	@Autowired
	FailedInvoiceRepository failedInvoiceRepository;

	@Value("${invoice.upload.root.dir}")
	private String invoiceUploadRootDir;

	@PostMapping(value = "/create")
	public EventResponse saveInvoice(@RequestBody InvoiceHeaderDto invoiceHeaderDto)
			throws MesserApAutomationException {
		LOGGER.info("Entered into InvoiceProcessController saveInvoice {} ", invoiceHeaderDto);
		InvoiceHeaderDto headerDto = invoiceProcessService.saveInvoice(invoiceHeaderDto);
		if (headerDto != null)
			return invoiceProcessService.invoiceRegistration(headerDto.getHeaderId(), WorkFlowStatus.SAVED.value());
		else
			return mcApUtil.prepareErrorResponse(MesserApAutomationConstants.ERROR_CD,
					MesserApAutomationConstants.ERROR_MSG);


	}

	@GetMapping(value = "/getAllInvoices")
	public Map<String, Object> getInvoicesByTxnAndStatus(@RequestParam("transactionType") String transactionType,
			@RequestParam("workflowStatus") Integer workflowStatus, HttpServletRequest request)
			throws MesserApAutomationException {
		LOGGER.info("fetching all invoices based on  workflowstatus#{} transactionType# {} ", workflowStatus,
				transactionType);
		return invoiceProcessService.getInvoicesByTxnAndStatus(MesserApAutomationUtil.getCompanyId(), transactionType,
				workflowStatus, request);
	}

	@GetMapping(value = "/getInvoice")
	public EventResponse getInvoice(@RequestParam Integer headerId) throws MesserApAutomationException, IOException {
		LOGGER.info("Invoice Booking in ERP System headerID# {} ", headerId);
		InvoiceHeaderDto headerDto = invoiceProcessService.getInvoice(headerId);
		if (null != headerDto) {
			return mcApUtil.prepareSuccessResponse(MesserApAutomationConstants.SUCCESS_CD,
					MesserApAutomationConstants.SUCCESS_MSG, headerDto);
		}
		return mcApUtil.prepareErrorResponse(MesserApAutomationConstants.ERROR_CD,
				MesserApAutomationConstants.ERROR_MSG);
	}

	@PostMapping("/uploadOCR")
	public EventResponse processInvoiceOcr(@RequestParam("file") MultipartFile ocrInvoiceFile,
			@RequestParam("transactionType") String transactionType, HttpServletRequest request)
			throws IOException, MesserApAutomationException {
		String userFilePath = invoiceUploadRootDir.concat("/");
		Path customerPath = Paths.get(userFilePath.concat(MesserApAutomationConstants.TEMP));
		if (!customerPath.toFile().exists()) {
			boolean sucess = customerPath.toFile().mkdirs();
			LOGGER.info("invoice upload file directory created  {}", sucess);
		} else {
			LOGGER.info("invoice upload file directory already exists so skiping the process of creation {}",
					userFilePath);
		}

		long fileSizeinKb = (ocrInvoiceFile.getSize()) / 1024;
		String filePath = userFilePath.concat(MesserApAutomationConstants.TEMP).concat("/")
				.concat(ocrInvoiceFile.getOriginalFilename());

		ocrInvoiceFile.transferTo(new File(filePath));

		// Invoke OCR API get invoice response

		InvoiceHeaderDto invoiceHeaderDto = invoiceProcessService.getInvoice(70);
		invoiceHeaderDto.setFileSize(fileSizeinKb);
		invoiceHeaderDto.setFilePath(userFilePath
				.concat(MesserApAutomationConstants.ARCHIVE.concat("/").concat(ocrInvoiceFile.getOriginalFilename())));
		invoiceHeaderDto = invoiceProcessService.saveInvoice(invoiceHeaderDto);

		// Move file to Archive once successfully processed
		Path arcPath = Paths.get(userFilePath.concat(MesserApAutomationConstants.ARCHIVE));
		moveProcessedFiles(customerPath, arcPath, ocrInvoiceFile.getOriginalFilename(), filePath);
		return mcApUtil.prepareSuccessResponse(MesserApAutomationConstants.SUCCESS_CD, "Invoice saved successfully",
				invoiceHeaderDto);

	}

	@DeleteMapping(value = "/deleteInvoice/{headerId}")
	public EventResponse deleteInvoice(@PathVariable("headerId") Integer headerId) {
		LOGGER.info("Entered into InvoiceProcessController deleteInvoice with headerId  {} ", headerId);
		invoiceProcessService.deleteByHeaderId(headerId);
		return mcApUtil.prepareSuccessResponse(MesserApAutomationConstants.SUCCESS_CD, "Invoice deleted successfully");
	}

	@GetMapping(value = "/getInvoiceBytes", produces = "application/pdf")
	public ResponseEntity<byte[]> getInvoiceBytes(@RequestParam("filepath") String filePath) {
		try {
			Path path = Paths.get(filePath);
			byte[] contents = Files.readAllBytes(path);
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.parseMediaType("application/pdf"));
			String filename = path.getFileName().toString();
			headers.setContentDispositionFormData(filename, filename);
			return new ResponseEntity<>(contents, headers, HttpStatus.OK);
		} catch (Exception e) {
			LOGGER.error("File Not Found", e);
		}
		return null;

	}

	@GetMapping(value = "/getAllFailedInvoices")
	public List<FailedInvoices> getAllFailedInvoices() {
		return (List<FailedInvoices>) failedInvoiceRepository.findAll();
	}

	public void moveProcessedFiles(Path sourcePath, Path destPath, String fileName, String filePath) {
		try {
			Path sourceFile = Paths.get(filePath);
			if (sourceFile.toFile().exists()) {
				if (!destPath.toFile().exists()) {
					boolean succes = destPath.toFile().mkdirs();
					LOGGER.info("Destination file directory created{} ", succes);
				} else {
					LOGGER.info("Destination file directory already exists so skiping the process of creation {} ",
							destPath);
				}

				Path temp = Files.move(sourcePath.resolve(fileName), destPath.resolve(fileName),
						StandardCopyOption.REPLACE_EXISTING);
				if (temp != null) {
					LOGGER.info("File moved successfully to Arc folder {} ", temp);
				}
			}
		} catch (Exception e) {
			LOGGER.error("moveProcessedFiles {}", e);
		}
	}

	// InvoieReports
	/*
	 * @GetMapping(value = "/getInvoiceReports") public EventResponse
	 * getInvoiceReport(@RequestParam("fromdate") String fromdate,
	 * 
	 * @RequestParam("todate") String todate, @RequestParam("transactionType")
	 * String transactionType,
	 * 
	 * @RequestParam("invoiceNo") String invoiceNo, @RequestParam("workFlowStatus")
	 * Integer workFlowStatus, HttpServletRequest request) throws
	 * MesserApAutomationException { LOGGER.info("get invoice reports ,{}");
	 * List<InvoiceHeaderDto> invoiceHeaderDtoList =
	 * invoiceProcessService.getInvoiceReports(fromdate, todate, transactionType,
	 * invoiceNo, workFlowStatus, request); return
	 * mcApUtil.prepareSuccessResponse(MesserApAutomationConstants.SUCCESS_CD,
	 * "Retrived Data Sucessfully", invoiceHeaderDtoList);
	 * 
	 * }
	 */

	@GetMapping(value = "/getInvoiceReport")
	@ResponseBody
	public String getCustomerInvoiceReport(@RequestParam(value = "fromdate", required = false) String fromDate,
			@RequestParam(value = "todate", required = false) String toDate,
			@RequestParam(value = "transactionType", required = false) String transactionType,
			@RequestParam(value = "invNo", required = false) String invNo,
			@RequestParam(value = "status", required = false) Integer status,
			@RequestParam(value = "poNumber", required = false) String poNumber, HttpServletRequest request,
			HttpServletResponse response) {

		LOGGER.info("Entered into InvoiceProcessController getCustomerInvoiceReport  with fromDate  and toDate {} ",
				fromDate);
		return invoiceProcessService.getCustomerInvoiceReport(fromDate, toDate, transactionType, invNo, status);
	}

	@GetMapping(value = "/exportInvoiceReport")
	@ResponseBody
	public ModelAndView exportCustomerInvoiceReport(@RequestParam(value = "fromdate", required = false) String fromDate,
			@RequestParam(value = "todate", required = false) String toDate,
			@RequestParam(value = "transactionType", required = false) String transactionType,
			@RequestParam(value = "invNo", required = false) String invNo,
			@RequestParam(value = "status", required = false) Integer status, HttpServletRequest request,
			HttpServletResponse response) throws DataValidationException {

		LOGGER.info("Entered into InvoiceProcessController getCustomerInvoiceReport  with fromDate {} ", fromDate);
		return invoiceProcessService.exportCustomerInvoiceReport(fromDate, toDate, request, response, transactionType,
				invNo, status);
	}

}
