package com.sailotech.mcap.util;



public class MesserSortIndexEnum {
	public enum SVMPDataColumns {
		REGISTERED_ID(1,"registeredId"),
		REGISTERED_NAME(2,"registeredName"),
	    BP_REGISTERED_ID(3,"bpRegisteredId"),
        INVOICE_NO(4, "bpName"),
		INVOICE_DATE(5,"invoiceNo"),
        PO_NO(6, "invoiceDate"),
		REFERENCE_NUMBER(7,"referenceNo");

        private final Integer index;
        private final String columnName;

        SVMPDataColumns(Integer index, String columnName) {
            this.index = index;
            this.columnName = columnName;
        }

        public String getColumnName() {
            return columnName;
        }
        
        public String getColumnName(Integer index) {
            String columnToSort = "";
            if(index!=0){
            for (SVMPDataColumns dataColumns : SVMPDataColumns.values()) {
                if (index.equals(dataColumns.getIndex())) {
                    columnToSort = dataColumns.getColumnName();
                    break;
                }
            }
            }else{
            	columnToSort="headerId";
            }
            return columnToSort;
        }

        public Integer getIndex() {
            return index;
        }
    }
	public enum SVMPFiledetails {
		SNO(1,"SNO"),
	    FileName(2,"fileName"),
	    FileSize(2,"fileSize"),
	    UploadedBy(3,"uploadedBy"),
        UploadedOn(4, "uploadedOn"),
		SUPPLYTYPE(5,"supplyType"),
		ReasonToFail(6,"reason"),
         STATUS(7,"status");
        private final Integer index;
        private final String columnName;
        SVMPFiledetails(Integer index, String columnName) {
            this.index = index;
            this.columnName = columnName;
        }
        public String getColumnName() {
            return columnName;
        }
        public String getColumnName(Integer index) {
            String columnToSort = "";
            if(index!=0){
            for (SVMPFiledetails svmpheaders : SVMPFiledetails.values()) {
                if (index.equals(svmpheaders.getIndex())) {
                    columnToSort = svmpheaders.getColumnName();
                    break;
                }
            }
            }else{
            	columnToSort="id";
            }
            return columnToSort;
        }
        public Integer getIndex() {
            return index;
        }
    }
	
	
	
}
